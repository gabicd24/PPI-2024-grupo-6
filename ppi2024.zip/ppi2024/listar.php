<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>

<?php
// listar.php
include 'conexao.php';

// Função para gerar a tabela
function gerarTabela($conn, $query, $titulo, $colunas) {
    echo "<h2>$titulo</h2>";
    $result = $conn->query($query);

    if (!$result) {
        die("Erro na consulta: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        echo "<table border='1'><tr>";
        foreach ($colunas as $coluna) {
            echo "<th>$coluna</th>";
        }
        echo "</tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            foreach ($colunas as $coluna) {
                // Normalizar o nome da coluna para acessar o array de resultados
                $colunaLower = strtolower(str_replace(' ', '_', $coluna));
                // Verifica se a chave existe antes de acessar
                $valor = isset($row[$colunaLower]) ? htmlspecialchars($row[$colunaLower]) : 'N/A';
                echo "<td>$valor</td>";
            }
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "Nenhum registro encontrado.";
    }
}

// Consulta para listar alunos com nome da turma
$queryAlunos = "SELECT a.id, a.nome, a.email, a.cpf, a.matricula, COALESCE(t.nome, 'Não Atribuído') AS turma
                FROM alunos a
                LEFT JOIN turmas t ON a.turma_id = t.id";

$tituloAlunos = "Lista de Alunos";
$colunasAlunos = ['ID', 'Nome', 'Email', 'CPF', 'Matricula', 'Turma'];

// Gerar a tabela de alunos
gerarTabela($conn, $queryAlunos, $tituloAlunos, $colunasAlunos);

// Consulta para listar turmas com líder e regente
$queryTurmas = "SELECT id, nome, 
                        COALESCE(lider, 'Não Atribuído') AS lider, 
                        COALESCE(regente, 'Não Atribuído') AS regente
                FROM turmas";

$tituloTurmas = "Lista de Turmas";
$colunasTurmas = ['ID', 'Nome', 'Líder', 'Regente'];

// Gerar a tabela de turmas
gerarTabela($conn, $queryTurmas, $tituloTurmas, $colunasTurmas);

// Consulta para listar professores e suas disciplinas
$queryProfessores = "SELECT p.id, p.nome, p.email, p.cpf, p.foto,
                             GROUP_CONCAT(DISTINCT CONCAT(d.nome, ' - (', t.nome, ')') SEPARATOR ', ') AS disciplinas
                      FROM professores p
                      LEFT JOIN professor_disciplinas pd ON p.id = pd.professor_id
                      LEFT JOIN disciplinas d ON pd.disciplina_id = d.id
                      LEFT JOIN turmas t ON d.turma_id = t.id
                      GROUP BY p.id, p.nome, p.email, p.cpf, p.foto";

$tituloProfessores = "Lista de Professores";
$colunasProfessores = ['ID', 'Nome', 'Email', 'CPF', 'Foto', 'Disciplinas'];

// Gerar a tabela de professores
gerarTabela($conn, $queryProfessores, $tituloProfessores, $colunasProfessores);

// Consulta para listar disciplinas com o nome da turma
$queryDisciplinas = "SELECT d.id, d.nome AS disciplina, 
                             COALESCE(t.nome, 'Não Atribuído') AS turma
                      FROM disciplinas d
                      LEFT JOIN turmas t ON d.turma_id = t.id";

$tituloDisciplinas = "Lista de Disciplinas";
$colunasDisciplinas = ['ID', 'Disciplina', 'Turma'];

// Gerar a tabela de disciplinas
gerarTabela($conn, $queryDisciplinas, $tituloDisciplinas, $colunasDisciplinas);

// Fechar conexão
$conn->close();
?>
