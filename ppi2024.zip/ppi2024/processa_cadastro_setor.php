<?php
session_start(); // Iniciar a sessão para armazenar mensagens

// Configurações do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    $_SESSION['error'] = "Falha na conexão: " . $conn->connect_error;
    header("Location: admin.php");
    exit();
}

// Processa o formulário
$nome = $_POST['nome'] ?? '';
$email = $_POST['email'] ?? '';
$tipo_setor = $_POST['tipo'] ?? '';
$senha = $_POST['senha'] ?? '';

// Verifica se todos os campos obrigatórios foram preenchidos
if (empty($nome) || empty($tipo_setor) || empty($senha) || empty($email)) {
    $_SESSION['error'] = "Nome, tipo de setor, email e senha são obrigatórios.";
    header("Location: admin.php");
    exit();
}

// Verifica se o email já existe
$stmt_check_email = $conn->prepare("SELECT id FROM usuarios WHERE email = ?");
$stmt_check_email->bind_param("s", $email);
$stmt_check_email->execute();
$stmt_check_email->store_result();
if ($stmt_check_email->num_rows > 0) {
    $_SESSION['error'] = "Email já cadastrado.";
    $stmt_check_email->close();
    header("Location: admin.php");
    exit();
}
$stmt_check_email->close();

// Hash da senha
$senha_hash = password_hash($senha, PASSWORD_BCRYPT);

// Processa a foto
$fotoPath = '';
if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
    // Nome da foto no formato setor(email).extensao
    $fotoExt = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
    $fotoNome = 'setor' . $email . '.' . $fotoExt; // Substitua 'email' por um identificador único se preferir
    $fotoTmp = $_FILES['foto']['tmp_name'];
    $fotoDir = 'setorimagens'; // Caminho do diretório
    $fotoPath = $fotoDir . '/' . $fotoNome; // Caminho completo para salvar a foto

    // Verifica se a pasta existe, se não, cria a pasta
    if (!is_dir($fotoDir)) {
        if (!mkdir($fotoDir, 0755, true)) {
            $_SESSION['error'] = "Erro ao criar o diretório para as fotos.";
            header("Location: admin.php");
            exit();
        }
    }

    // Tenta mover o arquivo para o diretório especificado
    if (!move_uploaded_file($fotoTmp, $fotoPath)) {
        $_SESSION['error'] = "Erro ao fazer upload da foto. Verifique as permissões da pasta.";
        header("Location: admin.php");
        exit();
    }
} elseif (isset($_FILES['foto']) && $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE) {
    // Verifica se ocorreu um erro de upload
    $uploadError = $_FILES['foto']['error'];
    $_SESSION['error'] = "Erro ao fazer upload da foto. Código do erro: $uploadError.";
    header("Location: admin.php");
    exit();
}

// Insere o setor
$stmt_setor = $conn->prepare("INSERT INTO setores (nome, email, tipo, senha, foto) VALUES (?, ?, ?, ?, ?)");
if ($stmt_setor === false) {
    $_SESSION['error'] = "Erro na preparação da declaração SQL para setores: " . $conn->error;
    header("Location: admin.php");
    exit();
}
$stmt_setor->bind_param("sssss", $nome, $email, $tipo_setor, $senha_hash, $fotoPath);
if ($stmt_setor->execute()) {
    // Insere na tabela usuarios
    $tipo_usuario = 'setor'; // Tipo fixo para setores
    $stmt_usuario = $conn->prepare("INSERT INTO usuarios (username, email, password_hash, tipo) VALUES (?, ?, ?, ?)");
    if ($stmt_usuario === false) {
        $_SESSION['error'] = "Erro na preparação da declaração SQL para a tabela de usuários: " . $conn->error;
        header("Location: admin.php");
        exit();
    }
    $stmt_usuario->bind_param("ssss", $nome, $email, $senha_hash, $tipo_usuario);
    if ($stmt_usuario->execute()) {
        $_SESSION['success'] = "Cadastro realizado.";
    } else {
        $_SESSION['error'] = "Erro ao registrar o setor como usuário: " . $stmt_usuario->error;
    }
    $stmt_usuario->close();
} else {
    $_SESSION['error'] = "Erro ao cadastrar o setor: " . $stmt_setor->error;
}

$stmt_setor->close();
$conn->close();

// Redireciona para a página admin.php
header("Location: admin.php");
exit();
?>
