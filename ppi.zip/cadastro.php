<html>
    
    <head>


    
    </head>

    <body>

    <label>Nome de usuário: </label>
    <input type="text" name="nome" />
    <br><br>
    <label>Senha: </label>
    <input type="password" name="senha"/>

    </body>

</html>
