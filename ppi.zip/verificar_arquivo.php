<?php
// Inicia a sessão e verifica se o usuário está autenticado
session_start();
if (!isset($_SESSION['loggedin'])) {
    die('Sessão expirada. Faça login novamente.');
}

// Conecta ao banco de dados
$host = 'localhost';
$user = 'root';
$pass = '';
$db = 'sisgna';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Recupera os parâmetros de turma e disciplina
    $turmaId = $_GET['turma_id'];
    $disciplinaId = $_GET['disciplina_id'];

    // Consulta para verificar se já existe um arquivo enviado para a recuperação paralela
    $stmt = $pdo->prepare("SELECT arquivo FROM recparalela WHERE turma_id = ? AND disciplina_id = ?");
    $stmt->execute([$turmaId, $disciplinaId]);
    $resultado = $stmt->fetch(PDO::FETCH_ASSOC);

    // Verifica se o arquivo foi encontrado
    if ($resultado && $resultado['arquivo']) {
        // Se o arquivo existe, envia os dados como JSON
        echo json_encode([
            'arquivo' => $resultado['arquivo'],
            'nome_arquivo' => basename($resultado['arquivo'])  // Retorna apenas o nome do arquivo
        ]);
    } else {
        echo json_encode([
            'arquivo' => null,
            'nome_arquivo' => ''
        ]);
    }

} catch (PDOException $e) {
    echo json_encode([
        'erro' => 'Erro ao acessar o banco de dados: ' . $e->getMessage()
    ]);
}
?>
