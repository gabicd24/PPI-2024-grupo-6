<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verifica se o ID da turma foi passado na URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Busca os dados da turma pelo ID
    $query = "SELECT * FROM turmas WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $turma = $result->fetch_assoc();
    } else {
        echo "Turma não encontrada.";
        exit();
    }
} else {
    echo "ID de turma não especificado.";
    exit();
}

// Verifica se o formulário foi enviado para salvar a edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $lider = $_POST['lider'];
    $regente = $_POST['regente'];

    $query = "UPDATE turmas SET nome = ?, lider = ?, regente = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssi", $nome, $lider, $regente, $id);

    if ($stmt->execute()) {
        // Redireciona de volta para a página de listagem após a atualização
        header("Location: listar.php?lista=turmas");
        exit();
    } else {
        echo "Erro ao atualizar a turma: " . $stmt->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Turma</title>
    <!-- Link para o Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Link para o seu arquivo CSS -->
    <link rel="stylesheet" href="css/styles.css"> <!-- Aqui importamos o CSS da pasta css -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <a href="admin.php" class="btn-home">
            <i class="fas fa-home"></i>
        </a>
        <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>
        <div id="dropdownMenu" class="dropdown-content" style="display: none;">
            <button onclick="showForm('aluno')">Cadastrar Aluno</button>
            <button onclick="showForm('turma')">Cadastrar Turma</button>
            <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
            <button onclick="showForm('professor')">Cadastrar Professor</button>
            <button onclick="showForm('setor')">Cadastrar Setor</button>
            <button onclick="showForm('curso')">Cadastrar Curso</button>
            <button onclick="showForm('add_admin')">Cadastrar Admin</button>
        </div>
        <button onclick="location.href='turmas.php'">Turmas</button>
        <button onclick="location.href='listar.php'">Listar</button>
        <button onclick="location.href='notificar.php'">Notificar</button>
        <button onclick="location.href='slides.php'">Slides</button>
        <button onclick="location.href='setoradmin.php'">Setor</button>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h2 class="text-center mb-4">Editar Turma</h2>
        
        <form action="" method="post">
            <!-- Nome da Turma -->
            <div class="form-group">
                <label for="nome">Nome da Turma:</label>
                <input type="text" id="nome" name="nome" class="form-control" value="<?php echo htmlspecialchars($turma['nome']); ?>" required>
            </div>
            
            <!-- Líder -->
            <div class="form-group">
                <label for="lider">Líder:</label>
                <input type="text" id="lider" name="lider" class="form-control" value="<?php echo htmlspecialchars($turma['lider']); ?>" required>
            </div>
            
            <!-- Regente -->
            <div class="form-group">
                <label for="regente">Regente:</label>
                <input type="text" id="regente" name="regente" class="form-control" value="<?php echo htmlspecialchars($turma['regente']); ?>" required>
            </div>

            <!-- Botões de Ação -->
            <div class="form-group text-center">
                <button type="submit" class="btn btn-success">Salvar Alterações</button>
                <a href="listar.php?lista=turmas" class="btn btn-secondary ml-2">Cancelar</a>
            </div>
        </form>
    </div>

    <!-- Link para o Bootstrap JS (se necessário) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
