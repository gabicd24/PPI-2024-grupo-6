<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verifica se o ID da turma foi passado na URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Busca os dados da turma pelo ID
    $query = "SELECT * FROM turmas WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $turma = $result->fetch_assoc();
    } else {
        echo "Turma não encontrada.";
        exit();
    }
} else {
    echo "ID de turma não especificado.";
    exit();
}

// Verifica se o formulário foi enviado para salvar a edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $lider = $_POST['lider'];
    $regente = $_POST['regente'];

    $query = "UPDATE turmas SET nome = ?, lider = ?, regente = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssi", $nome, $lider, $regente, $id);

    if ($stmt->execute()) {
        // Redireciona de volta para a página de listagem após a atualização
        header("Location: listar.php?mensagem=Turma atualizada com sucesso");
        exit();
    } else {
        echo "Erro ao atualizar a turma: " . $stmt->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Turma</title>
</head>
<body>
    <h2>Editar Turma</h2>
    <form action="" method="post">
        <label for="nome">Nome da Turma:</label><br>
        <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($turma['nome']); ?>" required><br><br>
        
        <label for="lider">Líder:</label><br>
        <input type="text" id="lider" name="lider" value="<?php echo htmlspecialchars($turma['lider']); ?>" required><br><br>
        
        <label for="regente">Regente:</label><br>
        <input type="text" id="regente" name="regente" value="<?php echo htmlspecialchars($turma['regente']); ?>" required><br><br>
        
        <input type="submit" value="Salvar">
        <button type="button" onclick="window.location.href='listar.php'">Cancelar</button>
    </form>
</body>
</html>
