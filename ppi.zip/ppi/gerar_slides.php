<?php
// Incluir a biblioteca FPDF
require('fpdf/fpdf.php');

// Iniciar a sessão
session_start();

// Incluir a conexão com o banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Obter o id da turma e tipo de nota (alterado para pegar o parâmetro 'id_turma')
$id_turma = isset($_GET['id_turma']) ? intval($_GET['id_turma']) : 0;
$notasSelecionadas = isset($_GET['notas']) ? $_GET['notas'] : [];

// Verificar se o id da turma é válido
if ($id_turma <= 0) {
    die("ID da turma inválido.");
}

// Verificar se foram selecionadas notas para filtro
if (empty($notasSelecionadas)) {
    die("Nenhuma nota foi selecionada.");
}

// Construir a consulta para pegar os alunos e suas notas com base nas seleções de notas
$queryAlunos = "
    SELECT a.id AS aluno_id, a.nome AS aluno_nome, a.matricula AS matricula, d.nome AS disciplina, 
           n.nota_parcial_1, n.semestre_1, n.nota_parcial_2, n.semestre_2, 
           n.numero_faltas, n.obs_parcial_1, n.obs_1_semestre, n.obs_parcial_2, n.obs_2_semestre
    FROM alunos a
    LEFT JOIN notas n ON a.id = n.aluno_id
    LEFT JOIN disciplinas d ON n.disciplina_id = d.id
    WHERE a.turma_id = ? 
";

$stmt = $conn->prepare($queryAlunos);
if (!$stmt) {
    die("Erro ao preparar a consulta: " . $conn->error);
}
$stmt->bind_param('i', $id_turma);
$stmt->execute();
$resultAlunos = $stmt->get_result();

// Obter o nome da turma
$queryTurma = "SELECT nome FROM turmas WHERE id = ?";
$stmt = $conn->prepare($queryTurma);
if (!$stmt) {
    die("Erro ao preparar a consulta: " . $conn->error);
}
$stmt->bind_param('i', $id_turma);
$stmt->execute();
$stmt->bind_result($nome_turma);
$stmt->fetch();

// Verificar se há alunos
if ($resultAlunos->num_rows > 0) {
    // Agrupar as notas por aluno
    $alunos = [];
    while ($aluno = $resultAlunos->fetch_assoc()) {
        $alunos[$aluno['aluno_id']]['nome'] = $aluno['aluno_nome'];
        $alunos[$aluno['aluno_id']]['matricula'] = $aluno['matricula'];
        $alunos[$aluno['aluno_id']]['disciplinas'][] = [
            'disciplina'      => $aluno['disciplina'],
            'nota_parcial_1'  => $aluno['nota_parcial_1'],
            'semestre_1'      => $aluno['semestre_1'],
            'nota_parcial_2'  => $aluno['nota_parcial_2'],
            'semestre_2'      => $aluno['semestre_2'],
            'numero_faltas'   => $aluno['numero_faltas'],
            'obs_parcial_1'   => $aluno['obs_parcial_1'] ?? '',  
            'obs_1_semestre'  => $aluno['obs_1_semestre'],
            'obs_parcial_2'   => $aluno['obs_parcial_2'],
            'obs_2_semestre'  => $aluno['obs_2_semestre']
        ];
    }
} else {
    die("Nenhum aluno encontrado para esta turma.");
}

// Ordenar os alunos por nome (ordem alfabética)
usort($alunos, function($a, $b) {
    return strcmp($a['nome'], $b['nome']);
});

// Fechar a conexão
$stmt->close();
$conn->close();

// Criar o PDF
$pdf = new FPDF();
$pdf->SetAutoPageBreak(true, 10); // Ativar quebra automática de página
$pdf->SetFont('Arial', 'B', 16);

// Gerar slides para alunos com notas selecionadas
foreach ($alunos as $aluno) {
    // Verificar se o aluno tem alguma nota abaixo de 7 nas notas selecionadas
    $notaInferior7 = false;
    foreach ($aluno['disciplinas'] as $disciplina) {
        // Verificar as notas de acordo com a seleção
        foreach ($notasSelecionadas as $nota) {
            if ($nota == 'nota_parcial_1' && $disciplina['nota_parcial_1'] < 7) {
                $notaInferior7 = true;
                break 2;
            }
            if ($nota == 'nota_parcial_2' && $disciplina['nota_parcial_2'] < 7) {
                $notaInferior7 = true;
                break 2;
            }
            if ($nota == 'semestre_1' && $disciplina['semestre_1'] < 7) {
                $notaInferior7 = true;
                break 2;
            }
            if ($nota == 'semestre_2' && $disciplina['semestre_2'] < 7) {
                $notaInferior7 = true;
                break 2;
            }
        }
    }

    if ($notaInferior7) {
        // Adicionar uma página de slide para este aluno na orientação horizontal (landscape)
        $pdf->AddPage('L');

        // Foto do aluno no canto superior direito
        $fotoPath = 'http://localhost/ppi/alunosfotos/aluno' . $aluno['matricula'];
        $extensaoImagem = (file_exists($fotoPath . '.jpg')) ? '.jpg' : '.png'; // Verifica se é jpg ou png
        $fotoPath .= $extensaoImagem; // Define o caminho completo

        // Adicionar a imagem do aluno no canto superior direito
        $pdf->Image($fotoPath, 230, 10, 40); // Ajuste a posição (230, 10) para o canto superior direito

        // Ajustar a posição Y para baixo após a imagem
        $pdf->Ln(50); // Mover para baixo, ajustando conforme necessário

        // Informações do aluno
        $pdf->SetFont('Arial', 'B', 16);
        $pdf->Cell(270, 10, "Aluno: " . utf8_decode($aluno['nome']), 0, 1, 'C');
        $pdf->SetFont('Arial', '', 12);

        // Gerar tabela com as notas selecionadas e número de faltas
        $pdf->Cell(60, 10, "Disciplina", 1, 0, 'C');
        
        // Exibir apenas as cédulas selecionadas
        if (in_array('nota_parcial_1', $notasSelecionadas)) {
            $pdf->Cell(45, 10, "Nota Parcial 1", 1, 0, 'C');
        }
        if (in_array('nota_parcial_2', $notasSelecionadas)) {
            $pdf->Cell(45, 10, "Nota Parcial 2", 1, 0, 'C');
        }
        if (in_array('semestre_1', $notasSelecionadas)) {
            $pdf->Cell(45, 10, "Semestre 1", 1, 0, 'C');
        }
        if (in_array('semestre_2', $notasSelecionadas)) {
            $pdf->Cell(45, 10, "Semestre 2", 1, 0, 'C');
        }

        // Adicionar a coluna "Número de Faltas"
        $pdf->Cell(45, 10, "Faltas", 1, 1, 'C');

        // Adicionar as notas do aluno com base na seleção
        foreach ($aluno['disciplinas'] as $disciplina) {
            $pdf->Cell(60, 10, utf8_decode($disciplina['disciplina']), 1, 0, 'L');
            
            // Exibir as notas conforme selecionado
            if (in_array('nota_parcial_1', $notasSelecionadas)) {
                $pdf->Cell(45, 10, $disciplina['nota_parcial_1'], 1, 0, 'C');
            }
            if (in_array('nota_parcial_2', $notasSelecionadas)) {
                $pdf->Cell(45, 10, $disciplina['nota_parcial_2'], 1, 0, 'C');
            }
            if (in_array('semestre_1', $notasSelecionadas)) {
                $pdf->Cell(45, 10, $disciplina['semestre_1'], 1, 0, 'C');
            }
            if (in_array('semestre_2', $notasSelecionadas)) {
                $pdf->Cell(45, 10, $disciplina['semestre_2'], 1, 0, 'C');
            }

            // Exibir o número de faltas
            $pdf->Cell(45, 10, $disciplina['numero_faltas'], 1, 1, 'C');
        }

        // Adicionar observações
        if (!empty($aluno['obs_parcial_1'])) {
            $pdf->Ln(5); 
            $pdf->SetFont('Arial', 'I', 10);
            $pdf->Cell(270, 10, "Observação Parcial 1: " . utf8_decode($aluno['obs_parcial_1']), 0, 1, 'L');
        }
        if (!empty($aluno['obs_parcial_2'])) {
            $pdf->Ln(5); 
            $pdf->SetFont('Arial', 'I', 10);
            $pdf->Cell(270, 10, "Observação Parcial 2: " . utf8_decode($aluno['obs_parcial_2']), 0, 1, 'L');
        }

        $pdf->Ln(10); // Espaço extra após as observações
    }
}

// Gerar o arquivo PDF
$pdf->Output();
?>
