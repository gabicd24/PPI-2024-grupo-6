<?php
session_start(); // Iniciar a sessão para armazenar mensagens

// Verificar se o usuário está autenticado e se o papel é 'admin'
if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Configurações do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    $_SESSION['error'] = "Falha na conexão: " . $conn->connect_error;
    header('Location: admin.php');
    exit();
}

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form_type']) && $_POST['form_type'] === 'admin') {
    $nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $senha = isset($_POST['senha']) ? trim($_POST['senha']) : '';
    
    if (empty($nome) || empty($email) || empty($senha)) {
        $_SESSION['error'] = "Nome, e-mail e senha são obrigatórios.";
        header('Location: admin.php');
        exit();
    }

    // Verificar se o email já está registrado
    $stmt = $conn->prepare("SELECT COUNT(*) FROM usuarios WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($count);
    $stmt->fetch();
    $stmt->close();
    
    if ($count > 0) {
        $_SESSION['error'] = "O e-mail já está registrado.";
        header('Location: admin.php');
        exit();
    }
    
    // Processar a foto
    $fotoPath = '';
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $fotoTmpName = $_FILES['foto']['tmp_name'];
        $fotoName = basename($_FILES['foto']['name']);
        $fotoPath = 'adminsfotos/' . $fotoName;
        
        // Verificar se o diretório de destino existe, caso contrário, criá-lo
        if (!is_dir(dirname($fotoPath))) {
            if (!mkdir(dirname($fotoPath), 0755, true)) {
                $_SESSION['error'] = "Erro ao criar o diretório para a foto.";
                header('Location: admin.php');
                exit();
            }
        }
        
        // Mover o arquivo
        if (!move_uploaded_file($fotoTmpName, $fotoPath)) {
            $_SESSION['error'] = "Erro ao fazer o upload da foto.";
            header('Location: admin.php');
            exit();
        }
    }
    
    // Inserir o admin no banco de dados
    $senhaHash = password_hash($senha, PASSWORD_BCRYPT);
    $stmt = $conn->prepare("INSERT INTO usuarios (username, email, password_hash, tipo, foto) VALUES (?, ?, ?, 'admin', ?)");
    $stmt->bind_param("ssss", $nome, $email, $senhaHash, $fotoPath);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Admin adicionado com sucesso.";
    } else {
        $_SESSION['error'] = "Erro ao adicionar admin: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();

    header('Location: admin.php');
    exit();
} else {
    $_SESSION['error'] = "Erro ao processar o formulário.";
    header('Location: admin.php');
    exit();
}
?>
