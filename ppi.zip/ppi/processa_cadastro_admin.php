<?php
// Inicia a sessão
session_start();

// Verificar se o usuário está autenticado e se o papel é 'admin'
if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Configurações do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo "Erro na conexão: " . $e->getMessage();
    exit();
}

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form_type']) && $_POST['form_type'] === 'admin') {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
    
    // Validação básica
    if (empty($nome) || empty($email) || empty($senha)) {
        header('Location: admin.php?message=error_empty_fields');
        exit();
    }

    // Verificar se o email já está registrado
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->fetchColumn() > 0) {
        header('Location: admin.php?message=email_exists');
        exit();
    }
    
    // Processar a foto
    $fotoPath = '';
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $fotoTmpName = $_FILES['foto']['tmp_name'];
        $fotoName = basename($_FILES['foto']['name']);
        $fotoPath = 'imagens/admins/' . $fotoName;
        
        // Verificar se o diretório de destino existe, caso contrário, criá-lo
        if (!is_dir(dirname($fotoPath))) {
            mkdir(dirname($fotoPath), 0755, true);
        }
        
        // Mover o arquivo
        if (!move_uploaded_file($fotoTmpName, $fotoPath)) {
            header('Location: admin.php?message=error_upload');
            exit();
        }
    }
    
    // Inserir o admin no banco de dados
    try {
        $stmt = $pdo->prepare("INSERT INTO usuarios (username, email, password_hash, tipo, foto) VALUES (?, ?, ?, 'admin', ?)");
        $stmt->execute([$nome, $email, $senha, $fotoPath]);
        
        // Redirecionar de volta para a página admin com uma mensagem de sucesso
        header('Location: admin.php?message=admin_added');
        exit();
    } catch (PDOException $e) {
        echo "Erro ao cadastrar admin: " . $e->getMessage();
        exit();
    }
} else {
    // Redirecionar para a página admin com uma mensagem de erro se o formulário não for enviado corretamente
    header('Location: admin.php?message=error');
    exit();
}
