<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// editar_admin.php
include 'conexao.php';

// Verificar se o ID do administrador foi fornecido
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Consulta para obter os dados do administrador
    $query = "SELECT id, username, email, tipo FROM usuarios WHERE id = $id AND tipo = 'admin'";
    $result = $conn->query($query);
    
    if ($result->num_rows == 1) {
        $admin = $result->fetch_assoc();
    } else {
        echo "Administrador não encontrado.";
        exit;
    }
} else {
    echo "ID do administrador não fornecido.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Administrador</title>
    <!-- Link do Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e9ecef;
            margin: 0;
            display: flex;
            height: 100vh;
            overflow: hidden;
        }

        .sidebar {
            width: 250px;
            background-color: #28a745;
            color: white;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            position: fixed; /* Para manter a barra lateral fixa */
            top: 0;
            bottom: 0;
            left: 0;
            flex-shrink: 0;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }

        .sidebar .btn-home {
            display: inline-block;
            color: white;
            font-size: 32px;
            margin-bottom: -2px; /* Ajuste o espaçamento aqui */
        }

        .sidebar button {
            width: 100%;
            text-align: left;
            color: white;
            background: none;
            border: none;
            font-size: 16px;
            padding: 10px;
            cursor: pointer;
            transition: background 0.3s ease;
            margin-bottom: 0px; /* Adiciona espaçamento entre os botões */
        }

        .sidebar button:hover {
            background-color: #218838;
        }

        .dropdown-content {
            margin-top: 10px;
        }

        .dropdown-content button {
            display: block;
            background-color: #218838;
            color: white;
            border: none;
            padding: 10px;
            width: 100%;
            text-align: left;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .dropdown-content button:hover {
            background-color: #1e7e34;
        }

        .main-content {
            flex: 1;
            padding: 20px;
            background-color: white;
            overflow-y: auto;
            margin-left: 270px; /* Adiciona margem para não sobrepor a barra lateral */
            height: 100vh;
            overflow-y: scroll;
        }

        .header {
            display: flex;
            align-items: center;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .logo {
            height: 120px;
            object-fit: cover;
            margin-right: 20px;
            flex-shrink: 0;
        }

        .logout-button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            transition: background 0.3s ease;
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .logout-button:hover {
            background-color: #218838;
        }

        .form-container {
            grid-template-columns: 1fr;
            gap: 15px;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px white;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <a href="admin.php" class="btn-home">
            <i class="fas fa-home"></i>
        </a>

        <!-- Se você quiser adicionar uma logo, descomente e ajuste -->
        <!-- <img src="logo.png" class="logo" alt="Logo"> -->

        <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>
        <div id="dropdownMenu" class="dropdown-content" style="display: none;">
            <button onclick="showForm('aluno')">Cadastrar Aluno</button>
            <button onclick="showForm('turma')">Cadastrar Turma</button>
            <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
            <button onclick="showForm('professor')">Cadastrar Professor</button>
            <button onclick="showForm('setor')">Cadastrar Setor</button>
            <button onclick="showForm('curso')">Cadastrar Curso</button>
            <button onclick="showForm('add_admin')">Cadastrar Admin</button>
            
        </div>

        <button onclick="location.href='turmas.php'">Turmas</button>
        <button onclick="location.href='listar.php'">Listar</button>
        <button onclick="location.href='notificar.php'">Notificar</button>
        <button onclick="location.href='slides.php'">Slides</button>
        <button onclick="location.href='gerar_boletim.php'">Boletim</button>
        <button onclick="location.href='setoradmin.php'">Setor</button>
    </div>

    <div class="main-content">
        <h1>Editar Administrador</h1>

        <form action="processa_edicao_admin.php" method="post">
            <input type="hidden" name="id" value="<?php echo $admin['id']; ?>">

            <div class="mb-3">
                <label for="username" class="form-label">Username:</label>
                <input type="text" id="username" name="username" class="form-control" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email:</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($admin['email']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="tipo" class="form-label">Tipo:</label>
                <input type="text" id="tipo" name="tipo" class="form-control" value="<?php echo htmlspecialchars($admin['tipo']); ?>" readonly>
            </div>

            <button type="submit" class="btn btn-success">Salvar Alterações</button>
        </form>

        <a href="listar.php?lista=administradores" class="btn btn-secondary mt-3">Voltar para a lista de administradores</a>
    </div>

    <!-- Link do Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
