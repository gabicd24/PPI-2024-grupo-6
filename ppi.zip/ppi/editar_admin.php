<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);


// editar_admin.php
include 'conexao.php';

// Verificar se o ID do administrador foi fornecido
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Consulta para obter os dados do administrador
    $query = "SELECT id, username, email, tipo FROM usuarios WHERE id = $id AND tipo = 'admin'";
    $result = $conn->query($query);
    
    if ($result->num_rows == 1) {
        $admin = $result->fetch_assoc();
    } else {
        echo "Administrador não encontrado.";
        exit;
    }
} else {
    echo "ID do administrador não fornecido.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Administrador</title>
</head>
<body>
    <h1>Editar Administrador</h1>
    <form action="processa_edicao_admin.php" method="post">
        <input type="hidden" name="id" value="<?php echo $admin['id']; ?>">
        
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($admin['email']); ?>" required>
        
        <label for="tipo">Tipo:</label>
        <input type="text" id="tipo" name="tipo" value="<?php echo htmlspecialchars($admin['tipo']); ?>" readonly>
        
        <button type="submit">Salvar Alterações</button>
    </form>
    <a href="listar.php?lista=administradores">Voltar para a lista de administradores</a>
</body>
</html>
