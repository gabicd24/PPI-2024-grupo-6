<?php
// Inicia a sessão
session_start();

// Verifica se o usuário está autenticado e se o tipo é 'professor'
if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'professor') {
    header('Location: login.php');
    exit();
}

// Verifica se o ID do usuário está presente na sessão
if (!isset($_SESSION['id'])) {
    die("Erro: ID do usuário não encontrado.");
}

// Configuração do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Tentar conectar ao banco de dados
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Função para lidar com o upload de arquivos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['arquivo'])) {
    $arquivo = $_FILES['arquivo'];
    $usuarioId = $_SESSION['id'];
    $semestre = $_POST['semestre'];  // Obtendo semestre do formulário
    $ano = $_POST['ano'];            // Obtendo ano do formulário
    $tipoArquivo = $_POST['tipo_arquivo']; // Tipo do arquivo (plano_trabalho ou relatorioatv)
    
    // Verificando se semestre, ano e tipo de arquivo foram selecionados
    if (!$semestre || !$ano || !$tipoArquivo) {
        $mensagem = 'Por favor, selecione o semestre, o ano e o tipo de arquivo.';
    } else {
        // Definir o diretório de upload
        $diretorio = 'uploads/arquivos_professores/';
        if (!is_dir($diretorio)) {
            mkdir($diretorio, 0777, true);
        }

        // Definir o caminho do arquivo
        $caminhoArquivo = $diretorio . basename($arquivo['name']);

        // Verificar se o arquivo é um PDF ou DOCX
        $tipoArquivoMime = mime_content_type($arquivo['tmp_name']);
        if ($tipoArquivoMime === 'application/pdf' || $tipoArquivoMime === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
            // Mover o arquivo para o diretório de upload
            if (move_uploaded_file($arquivo['tmp_name'], $caminhoArquivo)) {
                // Verificar se o professor já tem um arquivo enviado para o semestre e ano
                $stmt = $pdo->prepare("SELECT id FROM arquivos WHERE professor_id = ? AND semestre = ? AND ano = ?");
                $stmt->execute([$usuarioId, $semestre, $ano]);
                $existeArquivo = $stmt->fetch();

                // Se o arquivo já existir, atualizamos
                if ($existeArquivo) {
                    if ($tipoArquivo === 'plano_trabalho') {
                        $updateStmt = $pdo->prepare("UPDATE arquivos SET plano_trabalho = ?, data_upload = NOW() WHERE professor_id = ? AND semestre = ? AND ano = ?");
                        $updateStmt->execute([$caminhoArquivo, $usuarioId, $semestre, $ano]);
                    } elseif ($tipoArquivo === 'relatorioatv') {
                        $updateStmt = $pdo->prepare("UPDATE arquivos SET relatorioatv = ?, data_upload = NOW() WHERE professor_id = ? AND semestre = ? AND ano = ?");
                        $updateStmt->execute([$caminhoArquivo, $usuarioId, $semestre, $ano]);
                    }
                } else {
                    // Caso contrário, inserimos o novo arquivo
                    if ($tipoArquivo === 'plano_trabalho') {
                        $insertStmt = $pdo->prepare("INSERT INTO arquivos (professor_id, plano_trabalho, semestre, ano, data_upload) VALUES (?, ?, ?, ?, NOW())");
                        $insertStmt->execute([$usuarioId, $caminhoArquivo, $semestre, $ano]);
                    } elseif ($tipoArquivo === 'relatorioatv') {
                        $insertStmt = $pdo->prepare("INSERT INTO arquivos (professor_id, relatorioatv, semestre, ano, data_upload) VALUES (?, ?, ?, ?, NOW())");
                        $insertStmt->execute([$usuarioId, $caminhoArquivo, $semestre, $ano]);
                    }
                }

                // Redirecionar para evitar o reenvio do formulário ao atualizar a página
                header("Location: meus_arquivos.php");
                exit();
            } else {
                $mensagem = 'Erro ao enviar o arquivo.';
            }
        } else {
            $mensagem = 'Por favor, envie um arquivo PDF ou DOCX.';
        }
    }
}

try {
    // Recuperar o ID do professor da sessão
    $usuarioId = $_SESSION['id'];

    // Recuperar os arquivos enviados pelo professor, organizados por ano e semestre (ordem decrescente)
    $stmt = $pdo->prepare("SELECT a.id, a.plano_trabalho, a.relatorioatv, a.semestre, a.ano, a.data_upload 
                           FROM arquivos a 
                           WHERE a.professor_id = ? 
                           ORDER BY a.ano DESC, a.semestre DESC");
    $stmt->execute([$usuarioId]);
    $arquivos = $stmt->fetchAll();

} catch (PDOException $e) {
    die("Erro ao consultar banco de dados: " . $e->getMessage());
}
?>


<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Arquivos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Adicionando mais espaço entre as colunas */
        .container {
            margin-top: 50px;
        }
        .row {
            margin-right: 30px; /* Aumentando o espaço entre as colunas */
        }
        /* Estilo para garantir que o ano e semestre fiquem no canto inferior direito */
        .card-footer {
            font-size: 0.85rem;
            margin-top: 10px; /* Adiciona um pequeno espaço entre o botão e o rodapé */
        }
        .card {
            padding: 20px; /* Garante que o conteúdo do card fique organizado */
        }

        .col-md-6.left-column {
            border-right: 2px solid #ddd;  /* Linha de separação (cinza claro) */
            height: 99vh; /* Linha ocupa toda a altura da janela de visualização */
            position: relative; /* Garantir que a altura seja aplicada corretamente */
            padding-left: 30px;  /* Aumenta o espaço à esquerda */
            padding-right: 30px; /* Aumenta o espaço à direita */
        }

        .row {
            margin-left: 15px;  /* Adiciona espaçamento extra entre as colunas */
            margin-right: 15px;
        }

        /* Ajustando a exibição no card */
        .card-body {
            display: flex;
            justify-content: space-between; /* Alinha o conteúdo */
            align-items: center; /* Alinha verticalmente */
        }

        .file-info {
            flex-grow: 1; /* Permite que o texto do arquivo ocupe o espaço disponível */
        }

        .file-meta {
            text-align: right; /* Alinha o semestre e o ano à direita */
            font-size: 0.85rem;
            margin-left: 10px; /* Distância entre o botão e o semestre/ano */
            flex-shrink: 0; /* Garante que o conteúdo à direita não seja comprimido */
        }

        .btn-success {
            margin-bottom: 10px; /* Distância entre o botão e as informações de ano/semestre */
        }

    </style>
</head>
<body class="bg-light">

    <!-- Header com logo e título -->
    <div class="header" style="display: flex; align-items: center; padding: 20px; background-color: #ffffff; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
        <img src="iffarpng.png" alt="Logo da Empresa" class="logo" style="height: 120px; object-fit: cover; margin-right: 20px; flex-shrink: 0;">
        <h3>Bem-vindo ao Painel dos Professores</h3>
        <form method="POST" action="logout.php" style="margin: 0; margin-left: auto;">
            <button type="submit" name="logout" class="logout-button" style="background-color: #dc3545; color: white; border: none; padding: 10px 15px; cursor: pointer;">Sair</button>
        </form>
    </div>

    <div class="container mt-5">
        <div class="row g-4">
            <!-- Coluna Esquerda: Envio de Arquivo -->
            <div class="col-md-6 left-column">
                <div class="col-12 mb-4">
                <a href="professor.php" class="btn btn-success">Voltar</a>
                </div>
                <h2>Enviar Novo Arquivo</h2>
                <form method="POST" enctype="multipart/form-data">
                    <div class="mb-3">
                        <label for="arquivo" class="form-label">Escolha o arquivo (PDF ou DOCX):</label>
                        <input type="file" class="form-control" name="arquivo" id="arquivo" required>
                    </div>
                    <div class="mb-3">
                        <label for="semestre" class="form-label">Semestre:</label>
                        <select class="form-control" name="semestre" id="semestre" required>
                            <option value="">Selecione o semestre</option>
                            <option value="1">1º Semestre</option>
                            <option value="2">2º Semestre</option>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="ano" class="form-label">Ano:</label>
                        <input type="number" class="form-control" name="ano" id="ano" required>
                    </div>
                    <div class="mb-3">
                        <label for="tipo_arquivo" class="form-label">Tipo de Arquivo:</label>
                        <select class="form-control" name="tipo_arquivo" id="tipo_arquivo" required>
                            <option value="">Selecione o tipo de arquivo</option>
                            <option value="plano_trabalho">Plano de Trabalho</option>
                            <option value="relatorioatv">Relatório de Atividades</option>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Enviar Arquivo</button>
                </form>

                <?php if (isset($mensagem)): ?>
                    <div class="alert alert-danger mt-3"><?php echo $mensagem; ?></div>
                <?php endif; ?>
            </div>

            <!-- Coluna Direita: Visualização de Arquivos -->
            <div class="col-md-6">
                <h2>Arquivos Enviados</h2>

                <!-- Exibir Arquivos Organizados por Ano e Semestre -->
                <div class="row">
                    <div class="col-12">
                        <h4 class="mt-4">Planos de Trabalhos</h4>

                        <?php foreach ($arquivos as $arquivo): ?>
                            <?php if ($arquivo['plano_trabalho']): ?>
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <div class="file-info">
                                            <p><strong>Plano de Trabalho:</strong> <?php echo htmlspecialchars(basename($arquivo['plano_trabalho'])); ?></p>
                                        </div>
                                        <div class="file-meta">
                                            <a href="<?php echo $arquivo['plano_trabalho']; ?>" class="btn btn-success" download>Baixar</a>
                                            <div>
                                                <span>Semestre: <?php echo $arquivo['semestre']; ?>º</span> | 
                                                <span>Ano: <?php echo $arquivo['ano']; ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    </div>

                    <div class="col-12">
                        <h4 class="mt-4">Relatórios de Atividades</h4>

                        <?php foreach ($arquivos as $arquivo): ?>
                            <?php if ($arquivo['relatorioatv']): ?>
                                <div class="card mb-3">
                                    <div class="card-body d-flex justify-content-between">
                                        <!-- Informações do arquivo -->
                                        <div class="file-info">
                                            <p><strong>Relatório de Atividades:</strong> <?php echo htmlspecialchars(basename($arquivo['relatorioatv'])); ?></p>
                                        </div>
                                        
                                        <!-- Botão de download e informações do semestre e ano -->
                                        <div class="file-meta text-end">
                                            <a href="<?php echo $arquivo['relatorioatv']; ?>" class="btn btn-success" download>Baixar</a>
                                            <div>
                                                <span>Semestre: <?php echo $arquivo['semestre']; ?>º</span> | 
                                                <span>Ano: <?php echo $arquivo['ano']; ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>


