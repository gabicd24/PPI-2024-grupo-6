<?php
// Inicia a sessão
session_start();

// Verificar se o usuário está autenticado e se o papel é 'admin'
if (!isset($_SESSION['loggedin']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Configurações do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['form_type']) && $_POST['form_type'] === 'admin') {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
    
    // Processar a foto
    $fotoPath = '';
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $fotoTmpName = $_FILES['foto']['tmp_name'];
        $fotoName = basename($_FILES['foto']['name']);
        $fotoPath = 'imagens/admins/' . $fotoName;
        move_uploaded_file($fotoTmpName, $fotoPath);
    }
    
    // Inserir o admin no banco de dados
    $stmt = $pdo->prepare("INSERT INTO usuarios (username, email, password_hash, role, foto) VALUES (?, ?, ?, 'admin', ?)");
    $stmt->execute([$nome, $email, $senha, $fotoPath]);
    
    // Redirecionar de volta para a página admin com uma mensagem de sucesso
    header('Location: admin.php?message=admin_added');
    exit();
} else {
    // Redirecionar para a página admin com uma mensagem de erro se o formulário não for enviado corretamente
    header('Location: admin.php?message=error');
    exit();
}
