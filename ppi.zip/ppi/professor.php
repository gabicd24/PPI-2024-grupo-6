<?php
// Inicia a sessão
session_start();

// Verifica se o usuário está autenticado e se o tipo é 'professor'
if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'professor') {
    header('Location: login.php');
    exit();
}

// Verifica se o ID do usuário está presente na sessão
if (!isset($_SESSION['id'])) {
    die("Erro: ID do usuário não encontrado.");
}

// Configuração do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

try {
    // Conectar ao banco de dados
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Recuperar o ID do professor da sessão
    $usuarioId = $_SESSION['id'];

    // Recuperar notificações não lidas
    $stmt = $pdo->prepare("SELECT * FROM notificacoes WHERE usuario_id = ? AND status = 'não lida' ORDER BY data_criacao DESC");
    $stmt->execute([$usuarioId]);
    $notificacoes = $stmt->fetchAll();

    // Marcar a notificação como lida
    if (isset($_GET['marcar_lida'])) {
        $notificacao_id = $_GET['marcar_lida'];

        // Atualiza a notificação para o status 'lida'
        $updateStmt = $pdo->prepare("UPDATE notificacoes SET status = 'lida', data_leitura = NOW() WHERE id = ?");
        $updateStmt->execute([$notificacao_id]);

        // Redireciona para a página do professor após marcar a notificação como lida
        header("Location: professor.php");
        exit();
    }

    // Recuperar as turmas e disciplinas que o professor ministra
    $stmtTurmas = $pdo->prepare("SELECT t.id AS turma_id, t.nome AS turma_nome, d.id AS disciplina_id, d.nome AS disciplina_nome
        FROM professor_disciplinas pd
        JOIN disciplinas d ON pd.disciplina_id = d.id
        JOIN turmas t ON d.turma_id = t.id
        WHERE pd.professor_id = ? 
        ORDER BY t.nome");
    $stmtTurmas->execute([$usuarioId]);
    $turmas = $stmtTurmas->fetchAll();

    // Função para lidar com o upload do arquivo
    // Função para lidar com o upload do arquivo
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['arquivo'])) {
    $arquivo = $_FILES['arquivo'];
    $turmaId = $_POST['turma_id'];
    $disciplinaId = $_POST['disciplina_id']; // Captura o ID da disciplina

    // Definir o diretório de upload
    $diretorio = 'uploads/recparalela/';
    if (!is_dir($diretorio)) {
        mkdir($diretorio, 0777, true);
    }

    // Definir o caminho do arquivo
    $caminhoArquivo = $diretorio . basename($arquivo['name']);

    // Verificar se o arquivo é um PDF ou DOCX
    $tipoArquivo = mime_content_type($arquivo['tmp_name']);
    if ($tipoArquivo === 'application/pdf' || $tipoArquivo === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document') {
        // Mover o arquivo para o diretório de upload
        if (move_uploaded_file($arquivo['tmp_name'], $caminhoArquivo)) {
            // Atualiza o arquivo na tabela recparalela, substituindo o arquivo anterior
            $stmt = $pdo->prepare("
                INSERT INTO recparalela (turma_id, disciplina_id, professor_id, arquivo)
                VALUES (?, ?, ?, ?)
                ON DUPLICATE KEY UPDATE arquivo = ?");
            $stmt->execute([$turmaId, $disciplinaId, $usuarioId, $caminhoArquivo, $caminhoArquivo]);

            // Redireciona após o envio do arquivo para evitar reenvios
            header("Location: professor.php");
            exit();
        } else {
            $mensagem = 'Erro ao enviar o arquivo.';
        }
    } else {
        $mensagem = 'Por favor, envie um arquivo PDF ou DOCX.';
    }
}


} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página do Professor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .header {
            display: flex;
            align-items: center;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .logo {
            height: 120px;
            object-fit: cover;
            margin-right: 20px;
            flex-shrink: 0;
        }
        .header h1 {
            font-size: 28px;
            margin: 0;
        }
        .main-content {
            flex: 1;
            padding: 20px;
            background-color: white;
            overflow-y: auto;
            position: relative;
        }
        .logout-button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
        }
        .logout-button:hover {
            background-color: #c82333;
        }
        .btn-recparalela {
            position: absolute;
            bottom: 10px;
            right: 10px;
        }
    </style>
</head>
<body class="bg-light">
    
    <!-- Header com logo e título -->
    <div class="header">
        <img src="iffarpng.png" alt="Logo da Empresa" class="logo">
        <h1>Bem-vindo ao Painel dos Professores</h1>
        <form method="POST" action="logout.php" style="margin: 0; margin-left: auto;">
            <button type="submit" name="logout" class="logout-button">Sair</button>
        </form>
    </div>

    <div class="container mt-5 main-content">
         <!-- Adicionando o botão "Meus Arquivos" -->
            <a href="meus_arquivos.php" class="btn btn-info mb-3">Meus Arquivos</a>

        
        <h2 class="text-success mt-4">Notificações</h2>

        <?php if (count($notificacoes) > 0): ?>
            <?php foreach ($notificacoes as $notificacao): ?>
                <div class="card mb-3 <?php echo ($notificacao['status'] === 'lida') ? 'bg-secondary' : 'bg-white'; ?>">
                    <div class="card-body">
                        <h5 class="card-title">Mensagem:</h5>
                        <p class="card-text"><?php echo htmlspecialchars($notificacao['mensagem']); ?></p>
                        <p class="card-text"><strong>Data de Criação:</strong> <?php echo $notificacao['data_criacao']; ?></p>

                        <?php if ($notificacao['status'] === 'não lida'): ?>
                            <a href="professor.php?marcar_lida=<?php echo $notificacao['id']; ?>" class="btn btn-primary">Marcar como lida</a>
                        <?php else: ?>
                            <p class="text-muted mt-2"><em>Notificação já lida</em></p>
                        <?php endif; ?>
                    </div>
                </div>
        <?php endforeach; ?>
        <?php else: ?>
            <p>Você não tem notificações não lidas no momento.</p>
        <?php endif; ?>

        <h2 class="text-success mt-4">Turmas e Disciplinas</h2>
        
        <div class="row">
            <?php if (count($turmas) > 0): ?>
                <?php $count = 0; ?>
                <?php foreach ($turmas as $turma): ?>
                    <div class="col-md-4 mb-4 mx-9"> <!-- Cada turma ocupa 4 colunas, então teremos 3 por linha -->
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Turma: <?php echo htmlspecialchars($turma['turma_nome']); ?></h5>
                                <p class="card-text">Disciplina: <?php echo htmlspecialchars($turma['disciplina_nome']); ?></p>
                                <a href="pagina_turma.php?turma_id=<?php echo $turma['turma_id']; ?>&disciplina_id=<?php echo $turma['disciplina_id']; ?>" class="btn btn-success">Acessar Turma</a>

                                <button class="btn btn-warning btn-recparalela mt-2" data-bs-toggle="modal" data-bs-target="#modalRecParalela" data-turma-id="<?php echo $turma['turma_id']; ?>" data-disciplina-id="<?php echo $turma['disciplina_id']; ?>">Recuperação Paralela</button>
                            </div>
                        </div>
                    </div>
                    <?php $count++; ?>
                <?php endforeach; ?>
            <?php else: ?>
                <p>Você não está ministrando nenhuma turma no momento.</p>
            <?php endif; ?>
        </div>




    </div>

    <!-- Modal de Recuperação Paralela -->
    <div class="modal fade" id="modalRecParalela" tabindex="-1" aria-labelledby="modalRecParalelaLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalRecParalelaLabel">Recuperação Paralela</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body" id="modal-content-body">
                    <!-- O conteúdo será preenchido via JS -->
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>

    <script>
        var modal = document.getElementById('modalRecParalela');
        modal.addEventListener('show.bs.modal', function (event) {
            var button = event.relatedTarget;
            var turmaId = button.getAttribute('data-turma-id');
            var disciplinaId = button.getAttribute('data-disciplina-id');
            var modalContent = document.getElementById('modal-content-body');

            fetch('verificar_arquivo.php?turma_id=' + turmaId + '&disciplina_id=' + disciplinaId)
                .then(response => response.json())
                .then(data => {
                    if (data.arquivo) {
                        modalContent.innerHTML = `
                            <p><strong>Arquivo Enviado:</strong> ${data.nome_arquivo}</p>
                            <a href="${data.arquivo}" class="btn btn-info" download>Baixar Arquivo</a>
                            <hr>
                            <form method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="arquivo" class="form-label">Escolha um novo arquivo (PDF ou DOCX):</label>
                                    <input type="file" class="form-control" name="arquivo" id="arquivo" required>
                                </div>
                                <input type="hidden" name="turma_id" value="${turmaId}">
                                <input type="hidden" name="disciplina_id" value="${disciplinaId}">
                                <button type="submit" class="btn btn-primary">Enviar Novo Arquivo</button>
                            </form>
                        `;
                    } else {
                        modalContent.innerHTML = `
                            <form method="POST" enctype="multipart/form-data">
                                <div class="mb-3">
                                    <label for="arquivo" class="form-label">Escolha o arquivo para enviar (PDF ou DOCX):</label>
                                    <input type="file" class="form-control" name="arquivo" id="arquivo" required>
                                </div>
                                <input type="hidden" name="turma_id" value="${turmaId}">
                                <input type="hidden" name="disciplina_id" value="${disciplinaId}">
                                <button type="submit" class="btn btn-primary">Enviar Arquivo</button>
                            </form>
                        `;
                    }
                })
                .catch(error => {
                    console.error('Erro na requisição:', error);
                });

        });
    </script>
</body>
</html>
