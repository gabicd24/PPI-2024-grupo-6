<?php
// Inicia a sessão
session_start();

// Verifica se o usuário está autenticado e se o tipo é 'professor'
if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'professor') {
    // Se não estiver autenticado ou não for do tipo professor, redireciona para a página de login
    header('Location: login.php');
    exit();
}

// Verifica se o ID do usuário está presente na sessão
if (!isset($_SESSION['id'])) {
    die("Erro: ID do usuário não encontrado.");
}

// Configuração do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

try {
    // Conectar ao banco de dados
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Recuperar o ID do professor da sessão
    $usuarioId = $_SESSION['id'];

    // Recuperar notificações não lidas
    $stmt = $pdo->prepare("SELECT * FROM notificacoes WHERE usuario_id = ? AND status = 'não lida' ORDER BY data_criacao DESC");
    $stmt->execute([$usuarioId]);
    $notificacoes = $stmt->fetchAll();

    // Marcar a notificação como lida
    if (isset($_GET['marcar_lida'])) {
        $notificacao_id = $_GET['marcar_lida'];

        // Atualiza a notificação para o status 'lida'
        $updateStmt = $pdo->prepare("UPDATE notificacoes SET status = 'lida', data_leitura = NOW() WHERE id = ?");
        $updateStmt->execute([$notificacao_id]);

        // Redireciona para a página do professor após marcar a notificação como lida
        header("Location: professor.php");
        exit();
    }

    // Recuperar as turmas e disciplinas que o professor ministra
    $stmtTurmas = $pdo->prepare("
        SELECT t.id AS turma_id, t.nome AS turma_nome, d.id AS disciplina_id, d.nome AS disciplina_nome
        FROM professor_disciplinas pd
        JOIN disciplinas d ON pd.disciplina_id = d.id
        JOIN turmas t ON d.turma_id = t.id
        WHERE pd.professor_id = ?  -- Filtra pela ID do professor
        ORDER BY t.nome
    ");
    $stmtTurmas->execute([$usuarioId]);
    $turmas = $stmtTurmas->fetchAll();

} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página do Professor</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .header {
            display: flex;
            align-items: center;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .logo {
            height: 120px;
            object-fit: cover;
            margin-right: 20px;
            flex-shrink: 0;
        }
        .header h1 {
            font-size: 28px;
            margin: 0;
        }
        .main-content {
            flex: 1;
            padding: 20px;
            background-color: white;
            overflow-y: auto;
            position: relative;
        }
        .logout-button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
        }
        .logout-button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body class="bg-light">
    
    <!-- Header com logo e título -->
    <div class="header">
        <img src="iffarpng.png" alt="Logo da Empresa" class="logo">
        <h1>Bem-vindo ao Painel dos Professores</h1>
        <form method="POST" action="logout.php" style="margin: 0; margin-left: auto;">
            <button type="submit" name="logout" class="logout-button">Sair</button>
        </form>
    </div>

    <div class="container mt-5 main-content">
        <h2 class="text-success mt-4">Notificações</h2>

        <?php if (count($notificacoes) > 0): ?>
            <!-- Exibe notificações não lidas -->
            <?php foreach ($notificacoes as $notificacao): ?>
                <div class="card mb-3 <?php echo ($notificacao['status'] === 'lida') ? 'bg-secondary' : 'bg-white'; ?>">
                    <div class="card-body">
                        <h5 class="card-title">Mensagem:</h5>
                        <p class="card-text"><?php echo htmlspecialchars($notificacao['mensagem']); ?></p>
                        <p class="card-text"><strong>Data de Criação:</strong> <?php echo $notificacao['data_criacao']; ?></p>

                        <?php if ($notificacao['status'] === 'não lida'): ?>
                            <a href="professor.php?marcar_lida=<?php echo $notificacao['id']; ?>" class="btn btn-primary">Marcar como lida</a>
                        <?php else: ?>
                            <p class="text-muted mt-2"><em>Notificação já lida</em></p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Você não tem notificações não lidas no momento.</p>
        <?php endif; ?>

        <h2 class="text-success mt-4">Turmas e Disciplinas</h2>
        
        <?php if (count($turmas) > 0): ?>
            <!-- Exibe as turmas e disciplinas -->
            <?php foreach ($turmas as $turma): ?>
                <div class="card mb-3">
                    <div class="card-body">
                        <h5 class="card-title">Turma: <?php echo htmlspecialchars($turma['turma_nome']); ?></h5>
                        <p class="card-text">Disciplina: <?php echo htmlspecialchars($turma['disciplina_nome']); ?></p>
                        <a href="pagina_turma.php?turma_id=<?php echo $turma['turma_id']; ?>&disciplina_id=<?php echo $turma['disciplina_id']; ?>" class="btn btn-success">Acessar Turma</a>

                    </div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Você não está ministrando nenhuma turma no momento.</p>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS (opcional) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
