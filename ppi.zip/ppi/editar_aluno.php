<?php

// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
session_start();
include 'conexao.php'; // Incluindo a conexão com o banco de dados

$id = isset($_GET['id']) ? intval($_GET['id']) : 0; // Validação do ID

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Processar a edição
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';
    $cpf = $_POST['cpf'] ?? '';
    $matricula = $_POST['matricula'] ?? '';
    $turma_id = $_POST['turma_id'] ?? '';

    // Atualizar o aluno no banco de dados
    $stmt = $conn->prepare("UPDATE alunos SET nome = ?, email = ?, cpf = ?, matricula = ?, turma_id = ? WHERE id = ?");
    $stmt->bind_param("ssssii", $nome, $email, $cpf, $matricula, $turma_id, $id);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Aluno atualizado com sucesso.";
    } else {
        $_SESSION['error'] = "Erro ao atualizar aluno: " . $stmt->error;
    }

    $stmt->close();
    header("Location: listar.php");
    exit();
}

// Buscar os dados do aluno para edição
$query = "SELECT * FROM alunos WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Aluno não encontrado.";
    header("Location: listar.php");
    exit();
}

$aluno = $result->fetch_assoc();
$stmt->close();

// Opcional: buscar turmas para selecionar
$turmas = $conn->query("SELECT id, nome FROM turmas");

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Aluno</title>
</head>
<body>
    <h2>Editar Aluno</h2>

    <?php
    // Exibir mensagens de erro e sucesso
    if (isset($_SESSION['error'])) {
        echo "<p style='color:red;'>".$_SESSION['error']."</p>";
        unset($_SESSION['error']);
    }
    if (isset($_SESSION['success'])) {
        echo "<p style='color:green;'>".$_SESSION['success']."</p>";
        unset($_SESSION['success']);
    }
    ?>

    <form method="POST">
        <label>Nome:</label>
        <input type="text" name="nome" value="<?php echo htmlspecialchars($aluno['nome']); ?>" required><br>
        <label>Email:</label>
        <input type="email" name="email" value="<?php echo htmlspecialchars($aluno['email']); ?>" required><br>
        <label>CPF:</label>
        <input type="text" name="cpf" value="<?php echo htmlspecialchars($aluno['cpf']); ?>" required><br>
        <label>Matricula:</label>
        <input type="text" name="matricula" value="<?php echo htmlspecialchars($aluno['matricula']); ?>" required><br>
        <label>Turma:</label>
        <select name="turma_id" required>
            <?php while ($turma = $turmas->fetch_assoc()): ?>
                <option value="<?php echo $turma['id']; ?>" <?php echo $turma['id'] == $aluno['turma_id'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($turma['nome']); ?>
                </option>
            <?php endwhile; ?>
        </select><br>
        <button type="submit">Atualizar Aluno</button>
    </form>
    <a href="listar.php">Cancelar</a>
</body>
</html>

<?php
$conn->close(); // Fechar a conexão ao final
?>
