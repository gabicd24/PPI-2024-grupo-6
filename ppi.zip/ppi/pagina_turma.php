<?php
session_start();

// Verifica se o usuário está autenticado e é do tipo 'professor'
if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'professor') {
    header('Location: login.php');
    exit();
}

// Verifica se os parâmetros necessários estão presentes e são válidos
if (!isset($_GET['turma_id']) || !isset($_GET['disciplina_id']) || !is_numeric($_GET['turma_id']) || !is_numeric($_GET['disciplina_id'])) {
    // Redireciona para a página do professor
    header("Location: professor.php");
    exit();
}

// Conexão com o banco de dados
$host = 'localhost';
$user = 'root'; 
$pass = ''; 
$db   = 'sisgna'; 

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Parâmetros da URL
$turma_id = intval($_GET['turma_id']);
$disciplina_id = intval($_GET['disciplina_id']);

// Garante que todos os alunos da turma tenham um registro na tabela de notas para a disciplina
$sql_alunos_sem_notas = "
    SELECT a.id AS aluno_id
    FROM alunos a
    WHERE a.turma_id = ? 
      AND NOT EXISTS (
          SELECT 1 FROM notas n WHERE n.aluno_id = a.id AND n.disciplina_id = ?
      )
";

$stmt_alunos_sem_notas = $conn->prepare($sql_alunos_sem_notas);
$stmt_alunos_sem_notas->bind_param('ii', $turma_id, $disciplina_id);
$stmt_alunos_sem_notas->execute();
$result_alunos_sem_notas = $stmt_alunos_sem_notas->get_result();

while ($row_aluno = $result_alunos_sem_notas->fetch_assoc()) {
    $aluno_id = $row_aluno['aluno_id'];

    // Obter o nome da disciplina
    $sql_disciplina = "SELECT nome FROM disciplinas WHERE id = ?";
    $stmt_disciplina = $conn->prepare($sql_disciplina);
    $stmt_disciplina->bind_param('i', $disciplina_id);
    $stmt_disciplina->execute();
    $result_disciplina = $stmt_disciplina->get_result();
    $row_disciplina = $result_disciplina->fetch_assoc();
    $disciplina_nome = $row_disciplina['nome'];

    // Insere um registro inicial para o aluno sem notas
    $sql_inserir_nota = "
    INSERT INTO notas (aluno_id, disciplina, disciplina_id, nota_parcial_1, nota_parcial_2, semestre_1, semestre_2, numero_faltas) 
    VALUES (?, ?, ?, NULL, NULL, NULL, NULL, 0)
    ";
    $stmt_inserir_nota = $conn->prepare($sql_inserir_nota);
    $stmt_inserir_nota->bind_param('isi', $aluno_id, $disciplina_nome, $disciplina_id);
    $stmt_inserir_nota->execute();
    
    echo "Nome da disciplina: " . $disciplina_nome . "<br>";
   
}

// Busca informações sobre a turma e disciplina
$sql_turma = "
    SELECT t.nome AS turma_nome, d.nome AS disciplina_nome
    FROM turmas t
    JOIN disciplinas d ON d.turma_id = t.id
    WHERE t.id = ? AND d.id = ?
";

$stmt = $conn->prepare($sql_turma);
$stmt->bind_param('ii', $turma_id, $disciplina_id);
$stmt->execute();
$result_turma = $stmt->get_result();

if ($result_turma->num_rows === 0) {
    die("Erro: Turma ou disciplina não encontrada.");
}

$row_turma = $result_turma->fetch_assoc();
$turma_nome = $row_turma['turma_nome'];
$disciplina_nome = $row_turma['disciplina_nome'];

// Exibe mensagem de sucesso, se houver
if (isset($_SESSION['mensagem_sucesso'])) {
    echo "<p style='color: green;'>" . $_SESSION['mensagem_sucesso'] . "</p>";
    unset($_SESSION['mensagem_sucesso']);
}

// Processa a atualização das notas
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['salvar_todas'])) {
        foreach ($_POST['nota_parcial_1'] as $nota_id => $nota_parcial_1) {
            // Sanitização e validação dos dados
            $nota_parcial_1 = filter_var($nota_parcial_1, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            $nota_parcial_2 = filter_var($_POST['nota_parcial_2'][$nota_id], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            $semestre_1 = filter_var($_POST['semestre_1'][$nota_id], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            $semestre_2 = filter_var($_POST['semestre_2'][$nota_id], FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION);
            $numero_faltas = filter_var($_POST['numero_faltas'][$nota_id], FILTER_SANITIZE_NUMBER_INT);
            $obs_parcial_1 = filter_var($_POST['obs_parcial_1'][$nota_id], FILTER_SANITIZE_STRING);
            $obs_1_semestre = filter_var($_POST['obs_1_semestre'][$nota_id], FILTER_SANITIZE_STRING);
            $obs_parcial_2 = filter_var($_POST['obs_parcial_2'][$nota_id], FILTER_SANITIZE_STRING);
            $obs_2_semestre = filter_var($_POST['obs_2_semestre'][$nota_id], FILTER_SANITIZE_STRING);

            // Atualiza as notas no banco de dados
            $sql = "UPDATE notas SET 
                        nota_parcial_1 = ?, 
                        nota_parcial_2 = ?, 
                        semestre_1 = ?, 
                        semestre_2 = ?, 
                        numero_faltas = ?, 
                        obs_parcial_1 = ?, 
                        obs_1_semestre = ?, 
                        obs_parcial_2 = ?, 
                        obs_2_semestre = ? 
                    WHERE id = ?";

            $stmt = $conn->prepare($sql);
            if ($stmt === false) {
                die("Erro ao preparar a query: " . $conn->error);
            }

            $stmt->bind_param("ddddissssi", 
                $nota_parcial_1, 
                $nota_parcial_2, 
                $semestre_1, 
                $semestre_2, 
                $numero_faltas, 
                $obs_parcial_1, 
                $obs_1_semestre, 
                $obs_parcial_2, 
                $obs_2_semestre, 
                $nota_id
            );

            $stmt->execute();

            if ($stmt->affected_rows === 0) {
                $_SESSION['mensagem_erro'] = "Nenhuma alteração foi feita nas notas.";
            }
        }

        $_SESSION['mensagem_sucesso'] = "Notas salvas com sucesso!";
        $referer = isset($_SERVER['HTTP_REFERER']) ? $_SERVER['HTTP_REFERER'] : 'pagina_turma.php';
        header('Location: ' . $referer); 
        exit();
    }
}

// Exibe o nome da disciplina e turma
echo "<h1 class='text-center text-black mb-4'>Disciplina: $disciplina_nome - Turma: $turma_nome</h1>";
echo '<div class="d-flex justify-content-start mb-3" style="margin-left: 50px;">'; // Ajuste o valor da margem esquerda aqui
echo '<a href="professor.php"><button type="button" class="btn btn-secondary">Voltar para a Página do Professor</button></a>';
echo '</div>';

// Exibe as notas dos alunos
$sql_notas = "
    SELECT n.id, a.nome AS aluno_nome, 
        n.nota_parcial_1, n.nota_parcial_2, 
        n.semestre_1, n.semestre_2, n.numero_faltas, 
        n.obs_parcial_1, n.obs_1_semestre, 
        n.obs_parcial_2, n.obs_2_semestre
    FROM alunos a
    INNER JOIN turmas t ON t.id = a.turma_id
    LEFT JOIN notas n ON n.aluno_id = a.id AND n.disciplina_id = ?
    WHERE t.id = ?
";

$stmt_notas = $conn->prepare($sql_notas);
$stmt_notas->bind_param('ii', $disciplina_id, $turma_id);
$stmt_notas->execute();
$result_notas = $stmt_notas->get_result();

if (!$result_notas) {
    die("Erro ao buscar as notas: " . $conn->error);
}

if ($result_notas->num_rows > 0) {
    echo '<form method="POST" action="">'; // Formulário para salvar as notas
    echo '<div class="table-responsive">';
    echo '<table class="table table-bordered table-striped">';
    echo '<thead class="thead-dark">
            <tr>
                <th>Aluno</th>
                <th>Nota Parcial 1</th>
                <th>Semestre 1</th>
                <th>Nota Parcial 2</th>
                <th>Semestre 2</th>
                <th>Faltas</th>
                <th>Média</th>
                <th>Observações Parcial 1</th>
                <th>Observações Semestre 1</th>
                <th>Observações Parcial 2</th>
                <th>Observações Semestre 2</th>
            </tr>
          </thead>
          <tbody>';
    
    while ($row = $result_notas->fetch_assoc()) {
        $nota_id = $row['id'];
        $aluno_nome = $row['aluno_nome'];
        $nota_parcial_1 = $row['nota_parcial_1'];
        $nota_parcial_2 = $row['nota_parcial_2'];
        $semestre_1 = $row['semestre_1'];
        $semestre_2 = $row['semestre_2'];
        $numero_faltas = $row['numero_faltas'];
        $obs_parcial_1 = $row['obs_parcial_1'];
        $obs_1_semestre = $row['obs_1_semestre'];
        $obs_parcial_2 = $row['obs_parcial_2'];
        $obs_2_semestre = $row['obs_2_semestre'];

        $media = ($semestre_1 * 0.40) + ($semestre_2 * 0.60);

        echo "<tr>
                <td>$aluno_nome</td>
                <td><input type='number' class='form-control' name='nota_parcial_1[$nota_id]' value='$nota_parcial_1' step='0.01' max='10.00' min='0.00'></td>
                <td><input type='number' class='form-control' name='semestre_1[$nota_id]' value='$semestre_1' step='0.01' max='10.00' min='0.00'></td>
                <td><input type='number' class='form-control' name='nota_parcial_2[$nota_id]' value='$nota_parcial_2' step='0.01' max='10.00' min='0.00'></td>
                <td><input type='number' class='form-control' name='semestre_2[$nota_id]' value='$semestre_2' step='0.01' max='10.00' min='0.00'></td>
                <td><input type='number' class='form-control' name='numero_faltas[$nota_id]' value='$numero_faltas' min='0'></td>
                <td>" . number_format($media, 2) . "</td>
                <td><input type='text' class='form-control' name='obs_parcial_1[$nota_id]' value='$obs_parcial_1'></td>
                <td><input type='text' class='form-control' name='obs_1_semestre[$nota_id]' value='$obs_1_semestre'></td>
                <td><input type='text' class='form-control' name='obs_parcial_2[$nota_id]' value='$obs_parcial_2'></td>
                <td><input type='text' class='form-control' name='obs_2_semestre[$nota_id]' value='$obs_2_semestre'></td>
              </tr>";
    }

    echo '</tbody>';
    echo '</table>';
    echo '<div class="text-center">';
    echo '<button type="submit" name="salvar_todas" class="btn btn-success">Salvar Notas</button>';
    echo '</div>';
    echo '</div>';
    echo '</form>';
} else {
    echo "<p class='text-danger'>Nenhuma nota encontrada.</p>";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>Notas dos Alunos</title>
    <!-- Link do Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Opções adicionais de CSS podem ser adicionadas aqui -->
</head>
<body>
    <!-- O conteúdo do PHP será exibido aqui -->
</body>
</html>
