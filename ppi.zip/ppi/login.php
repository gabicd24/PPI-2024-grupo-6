<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require 'conexao.php'; // Arquivo de conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Verifica se o email e a senha estão preenchidos
    if (empty($email) || empty($password)) {
        $error = "Email e senha são obrigatórios.";
    } else {
        try {
            // Prepara e executa a consulta para buscar o usuário pelo email
            $query = "SELECT * FROM usuarios WHERE email = :email";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Verifica se o usuário foi encontrado e se a senha corresponde ao hash armazenado
            if ($user && password_verify($password, $user['password_hash'])) {
                $_SESSION['loggedin'] = true;
                $_SESSION['username'] = $user['username']; // Pode ser opcional se você não usar o username no sistema
                $_SESSION['tipo'] = $user['tipo']; // Salva o papel do usuário na sessão

                // Redireciona para a página correspondente ao papel do usuário
                if ($user['tipo'] == 'admin') {
                    header("Location: admin.php");
                } elseif ($user['tipo'] == 'setor') {
                    header("Location: setor.php");
                } elseif ($user['tipo'] == 'professor') {
                    header("Location: professor.php");
                } else {
                    $error = "Tipo de usuário desconhecido.";
                }
                exit(); // Importante para garantir que o script pare aqui
            } else {
                $error = "Email ou senha inválidos.";
            }
        } catch (PDOException $e) {
            $error = 'Erro ao buscar usuário: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sisgna</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f0f0;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        h2 {
            margin-top: 0;
            font-size: 24px;
            text-align: center;
        }
        .error, .message {
            color: #fff;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 20px;
        }
        .error {
            background-color: #f44336; /* Vermelho */
        }
        .message {
            background-color: #4CAF50; /* Verde */
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="email"],
        input[type="password"] {
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        button:hover {
            background-color: #0056b3;
        }
        .links {
            text-align: center;
        }
        .links a {
            color: #007bff;
            text-decoration: none;
        }
        .links a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Login</h2>
        <?php if (isset($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        <?php if (isset($_GET['msg']) && $_GET['msg'] == 'senha_alterada'): ?>
            <div class="message">Senha alterada com sucesso! Faça login para continuar.</div>
        <?php endif; ?>
        <?php if (isset($_GET['msg']) && $_GET['msg'] == 'login_successful'): ?>
            <div class="message">Login bem-sucedido!</div>
        <?php endif; ?>
        <form method="post">
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="password">Senha:</label>
            <input type="password" id="password" name="password" required>
            <button type="submit">Entrar</button>
        </form>
        <div class="links">
            <a href="forgot_password.php">Esqueci minha senha</a>
        </div>
    </div>
</body>
</html>
