<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();
require 'conexao.php'; // Arquivo de conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    // Verifica se o email e a senha estão preenchidos
    if (empty($email) || empty($password)) {
        $error = "Email e senha são obrigatórios.";
    } else {
        try {
            // Prepara e executa a consulta para buscar o usuário pelo email
            $query = "SELECT * FROM usuarios WHERE email = :email";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            // Verifica se o usuário foi encontrado e se a senha corresponde ao hash armazenado
            if ($user && password_verify($password, $user['password_hash'])) {
                // Armazena as informações do usuário na sessão
                $_SESSION['loggedin'] = true;
                $_SESSION['id'] = $user['id'];  // Armazenando o ID do usuário
                $_SESSION['email'] = $user['email'];  // Armazenando o e-mail do usuário
                $_SESSION['username'] = $user['username'];  // Armazenando o nome de usuário
                $_SESSION['tipo'] = $user['tipo'];  // Armazenando o tipo do usuário (admin, professor, etc.)

                // Redireciona para a página correspondente ao papel do usuário
                switch ($user['tipo']) {
                    case 'admin':
                        header("Location: admin.php");
                        break;
                    case 'setor':
                        header("Location: setor.php");
                        break;
                    case 'professor':
                        header("Location: professor.php");
                        break;
                    default:
                        $error = "Tipo de usuário desconhecido.";
                        break;
                }
                exit();
            } else {
                $error = "Email ou senha inválidos.";
            }
        } catch (PDOException $e) {
            $error = 'Erro ao buscar usuário: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sisgna</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container d-flex flex-column justify-content-center align-items-center min-vh-100">
        <div class="w-100" style="max-width: 400px;">
            <div class="card shadow-lg">
                <div class="card-body">
                    <div class="text-center mb-4">
                        <h1 class="text-success">SISGNA</h1>
                        <p class="text-dark">SISTEMA DE GERENCIAMENTO DE NOTAS E ALUNOS</p>
                    </div>
                    <?php if (isset($error)): ?>
                        <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                    <?php endif; ?>
                    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'senha_alterada'): ?>
                        <div class="alert alert-success text-center">Senha alterada com sucesso! Faça login para continuar.</div>
                    <?php endif; ?>
                    <?php if (isset($_GET['msg']) && $_GET['msg'] == 'email_enviado'): ?>
                        <div class="alert alert-success text-center">E-mail de recuperação enviado com sucesso! Verifique sua caixa de entrada.</div>
                    <?php endif; ?>
                    <form method="post">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="password">Senha</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                        <button type="submit" class="btn btn-success btn-block">Entrar</button>
                    </form>
                    <div class="text-center mt-3">
                        <a href="forgot_password.php" class="text-primary" style="text-decoration: underline;">Esqueci minha senha</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
