<?php
session_start(); // Iniciar a sessão para armazenar mensagens

// Configurações do banco de dados
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'sisgna';

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die('Erro de conexão: ' . $conn->connect_error);
}

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_FILES['foto'])) {
        // Dados do aluno
        $nome = trim($_POST['nome']);
        $email = trim($_POST['email']);
        $cpf = trim($_POST['cpf']);
        $matricula = trim($_POST['matricula']);
        $turma_id = $_POST['turma_id'];

        // Verificação básica de dados
        if (empty($nome) || empty($email) || empty($cpf) || empty($matricula) || empty($turma_id)) {
            $_SESSION['error'] = 'Todos os campos devem ser preenchidos.';
            header("Location: admin.php");
            exit();
        }

        // Processo de upload da foto
        $foto = $_FILES['foto'];
        $fotoExt = pathinfo($foto['name'], PATHINFO_EXTENSION);
        $fotoNome = 'aluno' . $cpf . '.' . $fotoExt; // Nome do arquivo formatado
        $fotoDestino = 'alunosfotos/' . $fotoNome; // Caminho correto para a pasta

        // Cria o diretório se não existir
        if (!is_dir('alunosfotos')) {
            mkdir('alunosfotos', 0777, true);
        }

        // Verifica se o arquivo foi enviado corretamente
        if ($foto['error'] === UPLOAD_ERR_OK) {
            if (move_uploaded_file($foto['tmp_name'], $fotoDestino)) {
                // Insere os dados no banco de dados usando prepared statements
                $stmt = $conn->prepare("INSERT INTO alunos (nome, email, cpf, matricula, turma_id, foto) VALUES (?, ?, ?, ?, ?, ?)");
                if ($stmt === false) {
                    $_SESSION['error'] = 'Erro na preparação da consulta: ' . $conn->error;
                    header("Location: admin.php");
                    exit();
                }

                $stmt->bind_param("ssssss", $nome, $email, $cpf, $matricula, $turma_id, $fotoNome);

                if ($stmt->execute()) {
                    $_SESSION['success'] = 'Aluno cadastrado com sucesso!';
                } else {
                    $_SESSION['error'] = 'Erro ao cadastrar o aluno: ' . $stmt->error;
                }

                $stmt->close();
            } else {
                $_SESSION['error'] = 'Erro ao fazer upload da foto.';
            }
        } else {
            $_SESSION['error'] = 'Erro ao enviar a foto: ' . $foto['error'];
        }
    } elseif (isset($_POST['nome_curso'])) {
        // Dados do curso
        $nomeCurso = trim($_POST['nome_curso']);
        $descricao = trim($_POST['descricao']);

        // Verificação básica de dados
        if (empty($nomeCurso)) {
            $_SESSION['error'] = 'Nome do curso é obrigatório.';
            header("Location: admin.php");
            exit();
        }

        // Prepara a declaração SQL
        $stmt = $conn->prepare("INSERT INTO cursos (nome, descricao) VALUES (?, ?)");
        if ($stmt === false) {
            $_SESSION['error'] = 'Erro na preparação da declaração: ' . $conn->error;
            header("Location: admin.php");
            exit();
        }

        $stmt->bind_param("ss", $nomeCurso, $descricao);

        if ($stmt->execute()) {
            $_SESSION['success'] = 'Cadastro realizado.';
        } else {
            $_SESSION['error'] = 'Erro ao cadastrar o curso: ' . $stmt->error;
        }

        $stmt->close();
    } else {
        $_SESSION['error'] = 'Dados do formulário não foram enviados corretamente.';
    }

    $conn->close();
    header("Location: admin.php");
    exit();
}
?>
