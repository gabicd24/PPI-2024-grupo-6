<?php
// Conexão com o banco de dados
$conn = new mysqli('localhost', 'root', '', 'sisgna');

if ($conn->connect_error) {
    die('Erro de conexão: ' . $conn->connect_error);
}

// Verifica se o formulário foi enviado e se o arquivo foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['foto'])) {
    // Dados do aluno
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $cpf = trim($_POST['cpf']);
    $matricula = trim($_POST['matricula']);
    $turma_id = $_POST['turma_id'];

    // Verificação básica de dados
    if (empty($nome) || empty($email) || empty($cpf) || empty($matricula) || empty($turma_id)) {
        $errorMsg = 'Todos os campos devem ser preenchidos.';
        header("Location: admin.php?error=" . urlencode($errorMsg));
        exit();
    }

    // Processo de upload da foto
    $foto = $_FILES['foto'];
    $fotoNome = time() . '_' . basename($foto['name']);
    $fotoDestino = 'uploads/alunos/' . $fotoNome;

    // Cria o diretório se não existir
    if (!is_dir('uploads/alunos')) {
        mkdir('uploads/alunos', 0777, true);
    }

    // Verifica se o arquivo foi enviado corretamente
    if ($foto['error'] === UPLOAD_ERR_OK) {
        if (move_uploaded_file($foto['tmp_name'], $fotoDestino)) {
            // Insere os dados no banco de dados usando prepared statements
            $stmt = $conn->prepare("INSERT INTO alunos (nome, email, cpf, matricula, turma_id, foto) VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt === false) {
                die('Erro na preparação da consulta: ' . $conn->error);
            }

            $stmt->bind_param("ssssss", $nome, $email, $cpf, $matricula, $turma_id, $fotoNome);

            if ($stmt->execute()) {
                $successMsg = 'Aluno cadastrado com sucesso!';
                header("Location: admin.php?success=" . urlencode($successMsg));
            } else {
                $errorMsg = 'Erro ao cadastrar o aluno: ' . $stmt->error;
                header("Location: admin.php?error=" . urlencode($errorMsg));
            }

            $stmt->close();
        } else {
            $errorMsg = 'Erro ao fazer upload da foto.';
            header("Location: admin.php?error=" . urlencode($errorMsg));
        }
    } else {
        $errorMsg = 'Erro ao enviar a foto: ' . $foto['error'];
        header("Location: admin.php?error=" . urlencode($errorMsg));
    }
} else {
    $errorMsg = 'Dados do formulário não foram enviados corretamente.';
    header("Location: admin.php?error=" . urlencode($errorMsg));
}

$conn->close();
?>
