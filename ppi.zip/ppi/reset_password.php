<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
require 'conexao.php'; // Arquivo de conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'] ?? '';
    $newPassword = $_POST['password'] ?? '';

    // Verifica se o token e a nova senha estão preenchidos
    if (empty($token) || empty($newPassword)) {
        $error = "Token ou nova senha não fornecidos.";
    } else {
        try {
            // Verifica se o token é válido
            $query = "SELECT email FROM password_resets WHERE token = :token AND expires > NOW()";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':token', $token);
            $stmt->execute();
            $reset = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($reset) {
                $email = $reset['email'];

                // Atualiza a senha do usuário
                $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
                $query = "UPDATE usuarios SET password_hash = :password WHERE email = :email";
                $stmt = $pdo->prepare($query);
                $stmt->bindParam(':password', $hashedPassword);
                $stmt->bindParam(':email', $email);
                $stmt->execute();

                // Remove o token usado
                $query = "DELETE FROM password_resets WHERE token = :token";
                $stmt = $pdo->prepare($query);
                $stmt->bindParam(':token', $token);
                $stmt->execute();

                // Redireciona para a página de login com mensagem de sucesso
                header("Location: login.php?msg=senha_alterada");
                exit();
            } else {
                $error = "Token inválido ou expirado.";
            }
        } catch (PDOException $e) {
            echo 'Erro ao processar a redefinição de senha: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir Senha</title>
</head>
<body>
    <form method="post">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token'] ?? ''); ?>">
        <label>Nova Senha:</label>
        <input type="password" name="password" required>
        <button type="submit">Redefinir Senha</button>
    </form>
    <?php if (isset($error)): ?>
        <div class="error"><?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
</body>
</html>
