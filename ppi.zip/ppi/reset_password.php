<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
require 'conexao.php'; // Arquivo de conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'] ?? '';
    $newPassword = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';

    // Verifica se o token, nova senha e confirmação de senha estão preenchidos
    if (empty($token) || empty($newPassword) || empty($confirmPassword)) {
        $error = "Token, nova senha e confirmação de senha são obrigatórios.";
    } elseif ($newPassword !== $confirmPassword) {
        $error = "As senhas não coincidem.";
    } else {
        try {
            // Verifica se o token é válido
            $query = "SELECT email FROM password_resets WHERE token = :token AND expires > NOW()";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':token', $token);
            $stmt->execute();
            $reset = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($reset) {
                $email = $reset['email'];

                // Atualiza a senha do usuário
                $hashedPassword = password_hash($newPassword, PASSWORD_BCRYPT);
                $query = "UPDATE usuarios SET password_hash = :password WHERE email = :email";
                $stmt = $pdo->prepare($query);
                $stmt->bindParam(':password', $hashedPassword);
                $stmt->bindParam(':email', $email);
                $stmt->execute();

                // Remove o token usado
                $query = "DELETE FROM password_resets WHERE token = :token";
                $stmt = $pdo->prepare($query);
                $stmt->bindParam(':token', $token);
                $stmt->execute();

                // Redireciona para a página de login com mensagem de sucesso
                header("Location: login.php?msg=senha_alterada");
                exit();
            } else {
                $error = "Token inválido ou expirado.";
            }
        } catch (PDOException $e) {
            echo 'Erro ao processar a redefinição de senha: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir Senha</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        .container {
            max-width: 500px;
        }
        .error {
            color: red;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container d-flex flex-column justify-content-center align-items-center min-vh-100">
        <div class="card shadow-lg">
            <div class="card-body">
                <h3 class="card-title text-center mb-4">Redefinir Senha</h3>
                <form method="post">
                    <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token'] ?? ''); ?>">
                    <div class="form-group">
                        <label for="password">Nova Senha</label>
                        <input type="password" class="form-control" id="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Confirme a Nova Senha</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                    </div>
                    <button type="submit" class="btn btn-success btn-block">Redefinir Senha</button>
                </form>
                <?php if (isset($error)): ?>
                    <div class="alert alert-danger mt-3"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
