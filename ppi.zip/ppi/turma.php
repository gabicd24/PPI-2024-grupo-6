<?php
// Iniciar a sessão
session_start();

// Incluir a conexão com o banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Obter o id da turma
$id_turma = isset($_GET['id']) ? intval($_GET['id']) : 0;

// Obter os alunos dessa turma e suas disciplinas
$queryAlunos = "
    SELECT a.id AS aluno_id, a.nome AS aluno_nome, d.nome AS disciplina, 
           n.nota_parcial_1, n.semestre_1, n.nota_parcial_2, n.semestre_2, 
           n.numero_faltas, n.obs_parcial_1, n.obs_1_semestre, n.obs_parcial_2, n.obs_2_semestre
    FROM alunos a
    LEFT JOIN notas n ON a.id = n.aluno_id
    LEFT JOIN disciplinas d ON n.disciplina_id = d.id
    WHERE a.turma_id = ?
";

$stmt = $conn->prepare($queryAlunos);
if (!$stmt) {
    die("Erro ao preparar a consulta: " . $conn->error);
}
$stmt->bind_param('i', $id_turma);
$stmt->execute();
$resultAlunos = $stmt->get_result();

$queryTurma = "SELECT nome FROM turmas WHERE id = ?";
$stmt = $conn->prepare($queryTurma);
if (!$stmt) {
    die("Erro ao preparar a consulta: " . $conn->error);
}
$stmt->bind_param('i', $id_turma);
$stmt->execute();
$stmt->bind_result($nome_turma);
$stmt->fetch();

// Agrupar as notas por aluno
$alunos = [];
while ($aluno = $resultAlunos->fetch_assoc()) {
    $alunos[$aluno['aluno_id']]['nome'] = $aluno['aluno_nome'];
    $alunos[$aluno['aluno_id']]['disciplinas'][] = $aluno;
}

// Fechar a conexão
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Alunos da Turma</title>
    <style>
        /* Estilos gerais */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        /* Estilos da barra lateral */
        .sidebar {
            width: 210px;
            background-color: #28a745;
            color: white;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            overflow-y: auto;
        }

        .sidebar h1 {
            margin-bottom: 20px;
            text-align: center;
        }

        .btn-back {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            text-align: center;
            margin-bottom: 20px;
        }

        .btn-back:hover {
            background-color: #45a049;
        }

        /* Estilos da lista de alunos */
        .alunos-lista {
            padding: 20px;
            margin-left: 280px; /* Espaço para a barra lateral */
        }

        .aluno-card {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }

        .aluno-card h3 {
            margin-top: 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }

        table, th, td {
            border: 1px solid black;
            text-align: left;
        }

        th, td {
            padding: 10px;
        }

        th {
            background-color: #f4f4f4;
        }

        .aluno-row:hover {
            background-color: #e9f7e9;
        }
    </style>
</head>
<body>

    <!-- Barra Lateral -->
    <div class="sidebar">
    <h1> <?php echo htmlspecialchars($nome_turma); ?></h1>        <!-- Botão de Voltar -->
        <a href="turmas.php" class="btn-back">Voltar</a>
    </div>

    <!-- Exibição dos alunos da turma -->
    <div class="alunos-lista">
        <h2>Alunos e Notas</h2>

        <?php foreach ($alunos as $aluno): ?>
            <div class="aluno-card">
                <h3>Aluno: <?php echo htmlspecialchars($aluno['nome']); ?></h3>
                <table>
                    <tr>
                        <th>Disciplina</th>
                        <th>Nota Parcial 1</th>
                        <th>Semestre 1</th>
                        <th>Nota Parcial 2</th>
                        <th>Semestre 2</th>
                        <th>Faltas</th>
                        <th>Média</th>
                        <th>Observação Parcial 1</th>
                        <th>Observação Semestre 1</th>
                        <th>Observação Parcial 2</th>
                        <th>Observação Semestre 2</th>
                    </tr>

                    <?php foreach ($aluno['disciplinas'] as $disciplina): 
                        // Calcular a média
                        $semestre_1 = floatval($disciplina['semestre_1']);
                        $semestre_2 = floatval($disciplina['semestre_2']);
                        $media = ($semestre_1 * 0.40) + ($semestre_2 * 0.60);
                    ?>
                        <tr class="aluno-row">
                            <td><?php echo htmlspecialchars($disciplina['disciplina']); ?></td>
                            <td><?php echo htmlspecialchars($disciplina['nota_parcial_1']); ?></td>
                            <td><?php echo htmlspecialchars($disciplina['semestre_1']); ?></td>
                            <td><?php echo htmlspecialchars($disciplina['nota_parcial_2']); ?></td>
                            <td><?php echo htmlspecialchars($disciplina['semestre_2']); ?></td>
                            <td><?php echo htmlspecialchars($disciplina['numero_faltas']); ?></td>
                            <td><?php echo number_format($media, 2, ',', '.'); ?></td> <!-- Exibindo a média formatada -->
                            <td><?php echo htmlspecialchars($disciplina['obs_parcial_1']); ?></td>
                            <td><?php echo htmlspecialchars($disciplina['obs_1_semestre']); ?></td>
                            <td><?php echo htmlspecialchars($disciplina['obs_parcial_2']); ?></td>
                            <td><?php echo htmlspecialchars($disciplina['obs_2_semestre']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            </div>
        <?php endforeach; ?>
    </div>

</body>
</html>
