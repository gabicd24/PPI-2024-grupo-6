<?php
// Conectar ao banco de dados
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'sisgna';

$conn = new mysqli($host, $user, $pass, $db);

// Verificar a conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Dados do aluno e notas
$aluno_id = 1; // Exemplo: ID do aluno
$disciplina = 'Matemática'; // Exemplo: disciplina
$nota_parcial_1 = 8.5; // Exemplo: nota da 1ª parcial
$semestre_1 = 9.0; // Exemplo: nota do 1º semestre
$nota_parcial_2 = 7.0; // Exemplo: nota da 2ª parcial
$semestre_2 = 8.0; // Exemplo: nota do 2º semestre
$numero_faltas = 5; // Exemplo: número de faltas
$obs_parcial_1 = 'Boa participação na 1ª parcial'; // Observação 1ª parcial
$obs_1_semestre = 'Bom desempenho no primeiro semestre'; // Observação 1º semestre
$obs_parcial_2 = 'Desempenho regular na 2ª parcial'; // Observação 2ª parcial
$obs_2_semestre = 'Precisa melhorar na segunda parte do semestre'; // Observação 2º semestre

// Inserir os dados na tabela
$sql = "INSERT INTO notas (aluno_id, disciplina, nota_parcial_1, semestre_1, nota_parcial_2, semestre_2, numero_faltas, obs_parcial_1, obs_1_semestre, obs_parcial_2, obs_2_semestre)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

// Ajuste na string de tipos para corresponder aos parâmetros:
$stmt = $conn->prepare($sql);
$stmt->bind_param('isdddsdssss', $aluno_id, $disciplina, $nota_parcial_1, $semestre_1, $nota_parcial_2, $semestre_2, $numero_faltas, $obs_parcial_1, $obs_1_semestre, $obs_parcial_2, $obs_2_semestre);

if ($stmt->execute()) {
    echo "Nota registrada com sucesso!";
} else {
    echo "Erro ao registrar a nota: " . $stmt->error;
}

// Fechar a conexão
$stmt->close();
$conn->close();
?>
