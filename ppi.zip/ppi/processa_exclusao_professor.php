<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verifica se o ID do professor foi passado na URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Remove associações do professor com disciplinas
    $queryDeleteDisciplinas = "DELETE FROM professor_disciplinas WHERE professor_id = ?";
    $stmtDeleteDisciplinas = $conn->prepare($queryDeleteDisciplinas);
    $stmtDeleteDisciplinas->bind_param("i", $id);
    $stmtDeleteDisciplinas->execute();

    // Remove o professor
    $queryDeleteProfessor = "DELETE FROM professores WHERE id = ?";
    $stmtDeleteProfessor = $conn->prepare($queryDeleteProfessor);
    $stmtDeleteProfessor->bind_param("i", $id);

    if ($stmtDeleteProfessor->execute()) {
        // Redireciona de volta para a página de listagem após a exclusão
        header("Location: listar.php?mensagem=Professor excluído com sucesso");
        exit();
    } else {
        echo "Erro ao excluir o professor: " . $stmtDeleteProfessor->error;
    }
} else {
    echo "ID de professor não especificado.";
}

$conn->close();
?>
