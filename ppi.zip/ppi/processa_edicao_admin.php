<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se os dados foram enviados pelo formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['id']);
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $tipo = $conn->real_escape_string($_POST['tipo']);

    // Atualizar os dados do administrador
    $query = "UPDATE usuarios SET username = '$username', email = '$email', tipo = '$tipo' WHERE id = $id";

    if ($conn->query($query) === TRUE) {
        echo "Administrador atualizado com sucesso.";
    } else {
        echo "Erro ao atualizar administrador: " . $conn->error;
    }
}

// Redirecionar para a lista de administradores após um breve momento
header("Refresh: 2; url=listar.php"); // Redireciona após 2 segundos
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Resultado da Edição</title>
</head>
<body>
    <h1>Resultado da Edição</h1>
    <p>Redirecionando para a lista de administradores...</p>
</body>
</html>

<?php
// Fechar conexão
$conn->close();
?>
