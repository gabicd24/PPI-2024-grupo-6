<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se os dados foram enviados pelo formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = intval($_POST['id']);
    $username = $conn->real_escape_string($_POST['username']);
    $email = $conn->real_escape_string($_POST['email']);
    $tipo = $conn->real_escape_string($_POST['tipo']);

    // Atualizar os dados do administrador
    $query = "UPDATE usuarios SET username = '$username', email = '$email', tipo = '$tipo' WHERE id = $id";

    if ($conn->query($query) === TRUE) {
        
    } else {
        echo "Erro ao atualizar administrador: " . $conn->error;
    }
}

// Redirecionar para a lista de administradores após um breve momento
header("Refresh: 0; url=listar.php?lista=administradores"); // Redireciona após 2 segundos
?>


<?php
// Fechar conexão
$conn->close();
?>
