<?php
// Incluir a conexão com o banco de dados
session_start(); // Iniciar a sessão para armazenar mensagens

// Verificar se o usuário está autenticado e se o papel é 'admin'
if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Configurações do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    $_SESSION['error'] = "Falha na conexão: " . $conn->connect_error;
    header('Location: admin.php');
    exit();
}

// Variáveis para mensagens de erro e sucesso
$mensagem = '';
$usuarios = [];

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recuperar os dados do formulário
    $mensagem_texto = $_POST['mensagem'];
    $tipo_usuario = $_POST['tipo_usuario'];  // Tipo de usuário escolhido

    // Verificar se os campos não estão vazios
    if (!empty($mensagem_texto) && !empty($tipo_usuario)) {
        // Obter a lista de usuários com base no tipo escolhido (admin, setor ou professor)
        $queryUsuarios = "SELECT id, username FROM usuarios WHERE tipo = ?";
        $stmt = $conn->prepare($queryUsuarios);
        $stmt->bind_param("s", $tipo_usuario);
        $stmt->execute();
        $resultUsuarios = $stmt->get_result();
        $usuarios = $resultUsuarios->fetch_all(MYSQLI_ASSOC);
        $stmt->close();

        // Enviar notificações para todos os usuários do tipo selecionado
        foreach ($usuarios as $usuario) {
            // Preparar a consulta para inserir a notificação no banco de dados
            $query = "INSERT INTO notificacoes (usuario_id, mensagem, status) VALUES (?, ?, 'não lida')";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("is", $usuario['id'], $mensagem_texto);

            // Executar a consulta
            if ($stmt->execute()) {
                $_SESSION['success'] = "Notificação enviada com sucesso para o tipo de usuário: $tipo_usuario!";
            } else {
                $_SESSION['error'] = "Erro ao enviar notificação. Tente novamente.";
            }

            // Fechar a declaração
            $stmt->close();
        }

        // Redirecionar após o envio
        header('Location: notificar.php');
        exit();
    } else {
        $_SESSION['error'] = "Por favor, preencha todos os campos!";
        header('Location: notificar.php');
        exit();
    }
}

// Fechar a conexão
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificar Usuário</title>
    <!-- Link do Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Estilos personalizados */
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f7fc;
            margin: 0;
            display: flex;
        }

        .sidebar {
            width: 250px;
            background-color: #28a745;
            color: green;
            padding-top: 20px;
            height: 100vh;
            position: fixed;
        }

        .sidebar .btn-back {
            background-color: #008000;
            color: white;
            border: none;
            font-size: 16px;
            padding: 8px 20px;
            border-radius: 5px;
            margin-bottom: 20px;
            margin-left: 20px;
        }

        .sidebar .btn-back:hover {
            background-color: #218838;
        }

        .main-content {
            margin-left: 250px; /* Deixa o conteúdo para a direita da barra lateral */
            width: 100%;
            padding: 30px;
        }

        .form-container {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .message {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 5px;
            font-weight: bold;
        }

        .success {
            background-color: #d4edda;
            color: #155724;
        }

        .error {
            background-color: #f8d7da;
            color: #721c24;
        }

        .form-container form {
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        .form-label {
            color: #28a745;
        }

        .form-select, .form-control {
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .form-select:focus, .form-control:focus {
            border-color: #28a745;
            box-shadow: 0 0 5px rgba(40, 167, 69, 0.5);
        }

        button[type="submit"] {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }

        button[type="submit"]:hover {
            background-color: #218838;
        }

    </style>
</head>
<body>

<div class="sidebar">
        <button class="btn-back" onclick="window.location.href='admin.php'">Voltar</button>
    </div>

    <!-- Conteúdo principal -->
    <div class="main-content">
        <h1>Notificar Usuário</h1>

        <!-- Mensagem de sucesso ou erro -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="message success">
                <?php echo $_SESSION['success']; ?>
            </div>
            <?php unset($_SESSION['success']); ?>
        <?php elseif (isset($_SESSION['error'])): ?>
            <div class="message error">
                <?php echo $_SESSION['error']; ?>
            </div>
            <?php unset($_SESSION['error']); ?>
        <?php endif; ?>

        <!-- Formulário de notificação -->
        <div class="form-container">
            <form method="POST" action="notificar.php">
                <!-- Selecione o tipo de usuário -->
                <div class="mb-3">
                    <label for="tipo_usuario" class="form-label">Selecionar Tipo de Usuário:</label>
                    <select name="tipo_usuario" id="tipo_usuario" class="form-select" required>
                        <option value="">Escolha um tipo de usuário</option>
                        <option value="admin">Admin</option>
                        <option value="setor">Setor</option>
                        <option value="professor">Professor</option>
                    </select>
                </div>

                <!-- Mensagem da notificação -->
                <div class="mb-3">
                    <label for="mensagem" class="form-label">Mensagem:</label>
                    <textarea name="mensagem" id="mensagem" class="form-control" rows="4" required></textarea>
                </div>

                <button type="submit" class="btn">Enviar Notificação</button>
            </form>
        </div>
    </div>

    <!-- Script do Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
