<?php
// Incluir a conexão com o banco de dados
session_start(); // Iniciar a sessão para armazenar mensagens

// Verificar se o usuário está autenticado e se o papel é 'admin'
if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Configurações do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    $_SESSION['error'] = "Falha na conexão: " . $conn->connect_error;
    header('Location: admin.php');
    exit();
}

// Variáveis para mensagens de erro e sucesso
$mensagem = '';

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Recuperar os dados do formulário
    $usuario_id = $_POST['usuario_id'];
    $mensagem_texto = $_POST['mensagem'];

    // Verificar se os campos não estão vazios
    if (!empty($usuario_id) && !empty($mensagem_texto)) {
        // Preparar a consulta para inserir a notificação no banco de dados
        $query = "INSERT INTO notificacoes (usuario_id, mensagem, status) VALUES (?, ?, 'não lida')";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("is", $usuario_id, $mensagem_texto);

        // Executar a consulta
        if ($stmt->execute()) {
            $mensagem = "Notificação enviada com sucesso!";
        } else {
            $mensagem = "Erro ao enviar notificação. Tente novamente.";
        }

        // Fechar a declaração
        $stmt->close();
    } else {
        $mensagem = "Por favor, preencha todos os campos!";
    }
}

// Obter a lista de usuários para exibir no dropdown
$queryUsuarios = "SELECT id, username FROM usuarios";
$resultUsuarios = $conn->query($queryUsuarios);

// Fechar a conexão
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificar Usuário</title>
    <style>
        /* Estilos básicos para a página */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .form-container {
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 8px;
            background-color: #f9f9f9;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input, select, textarea {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        button {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #45a049;
        }
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        .success {
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
            color: #155724;
        }
        .error {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            color: #721c24;
        }
    </style>
</head>
<body>
    <h1>Notificar Usuário</h1>

    <!-- Mensagem de sucesso ou erro -->
    <?php if ($mensagem): ?>
        <div class="message <?php echo (strpos($mensagem, 'sucesso') !== false) ? 'success' : 'error'; ?>">
            <?php echo $mensagem; ?>
        </div>
    <?php endif; ?>

    <!-- Formulário de notificação -->
    <div class="form-container">
        <form method="POST" action="notificar.php">
            <!-- Selecione o usuário -->
            <label for="usuario_id">Selecionar Usuário:</label>
            <select name="usuario_id" id="usuario_id" required>
                <option value="">Escolha um usuário</option>
                <?php while ($usuario = $resultUsuarios->fetch_assoc()): ?>
                    <option value="<?php echo $usuario['id']; ?>">
                        <?php echo htmlspecialchars($usuario['username']); ?>
                    </option>
                <?php endwhile; ?>
            </select>

            <!-- Mensagem da notificação -->
            <label for="mensagem">Mensagem:</label>
            <textarea name="mensagem" id="mensagem" rows="4" required></textarea>

            <button type="submit">Enviar Notificação</button>
        </form>
    </div>

</body>
</html>
