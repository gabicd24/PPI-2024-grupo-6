<?php
session_start(); // Iniciar a sessão para armazenar mensagens

// Configurações do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    $_SESSION['error'] = "Falha na conexão: " . $conn->connect_error;
    header("Location: admin.php");
    exit();
}

// Processa o formulário
$nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
$curso_id = isset($_POST['curso_id']) ? intval($_POST['curso_id']) : '';

if (empty($nome) || empty($curso_id)) {
    $_SESSION['error'] = "Nome e curso são obrigatórios.";
    header("Location: admin.php");
    exit();
}

// Prepara a instrução SQL
$sql = "INSERT INTO turmas (nome, curso_id) VALUES (?, ?)";
$stmt = $conn->prepare($sql);
if ($stmt === false) {
    $_SESSION['error'] = "Erro na preparação da declaração: " . $conn->error;
    header("Location: admin.php");
    exit();
}

// Vincula os parâmetros e executa a instrução SQL
$stmt->bind_param("si", $nome, $curso_id);
if ($stmt->execute()) {
    $_SESSION['success'] = 'Cadastro realizado.';
} else {
    $_SESSION['error'] = "Erro ao cadastrar a turma: " . $stmt->error;
}

// Fecha a instrução e a conexão
$stmt->close();
$conn->close();

// Redireciona para a página admin.php
header("Location: admin.php");
exit();
?>
