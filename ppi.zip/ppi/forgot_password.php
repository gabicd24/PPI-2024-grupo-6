<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
require 'conexao.php'; // Arquivo de conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';

    // Verifica se o e-mail está preenchido
    if (empty($email)) {
        $error = "O e-mail é obrigatório.";
    } else {
        try {
            // Verifica se o e-mail existe na tabela de usuários
            $query = "SELECT * FROM usuarios WHERE email = :email";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Gerar token e inserir na tabela password_resets
                $token = bin2hex(random_bytes(50)); // Gerar um token seguro
                $expires = date('Y-m-d H:i:s', strtotime('+1 hour')); // Define a expiração do token para 1 hora a partir de agora

                $query = "INSERT INTO password_resets (email, token, expires) VALUES (:email, :token, :expires)";
                $stmt = $pdo->prepare($query);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':token', $token);
                $stmt->bindParam(':expires', $expires);
                $stmt->execute();

                // Envia o e-mail com o link para redefinição de senha
                $mail = new PHPMailer(true);

                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.office365.com'; // Usando o servidor SMTP do Outlook
                    $mail->SMTPAuth = true;
                    $mail->Username = 'lorenzorpiovesan@hotmail.com'; // Seu e-mail
                    $mail->Password = 'xngfnxqowkrwywbd'; // Senha de aplicativo gerada
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    $mail->setFrom('lorenzorpiovesan@hotmail.com', 'SISGNA');
                    $mail->addAddress($email);

                    $mail->isHTML(true);
                    $mail->CharSet = 'UTF-8'; // Define o charset para UTF-8
                    $mail->Subject = 'Redefinição de Senha';

                    $resetLink = 'http://localhost/ppi/reset_password.php?token=' . urlencode($token);
                    $mail->Body = '
                    <html>
                    <head>
                        <meta charset="UTF-8">
                    </head>
                    <body>
                        <h2>Redefinição de Senha</h2>
                        <p>Você solicitou a redefinição de sua senha. Clique no link abaixo para criar uma nova senha:</p>
                        <p><a href="' . $resetLink . '">' . $resetLink . '</a></p>
                        <p>Se você não solicitou a redefinição de senha, ignore este e-mail.</p>
                        <p>Atenciosamente,<br>Equipe SISGNA</p>
                    </body>
                    </html>
                    ';
                    $mail->AltBody = 'Você solicitou a redefinição de sua senha. Clique no seguinte link para criar uma nova senha: ' . $resetLink;

                    $mail->send();
                    header("Location: login.php?msg=email_enviado");
                    exit();
                } catch (Exception $e) {
                    echo 'Erro ao enviar e-mail: ', $mail->ErrorInfo;
                }
            } else {
                $error = "E-mail não encontrado.";
            }
        } catch (PDOException $e) {
            echo 'Erro ao buscar usuário: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <style>
        .btn-home {
        display: inline-block;
        color: black; /* Cor do ícone (azul) */
        font-size: 32px; /* Tamanho maior do ícone */
        
    }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperação de Senha</title>
    <!-- Bootstrap CSS -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>

<body class="bg-light d-flex justify-content-center align-items-center vh-100">
    
    <div class="container">
        
        <div class="row justify-content-center">
            <div class="col-md-6 col-lg-4">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h3 class="text-center mb-4">Recuperação de Senha</h3>
                        <?php if (isset($_GET['msg']) && $_GET['msg'] == 'email_enviado'): ?>
                            <div class="alert alert-success">Um e-mail com instruções para redefinir sua senha foi enviado.</div>
                        <?php endif; ?>
                        <?php if (isset($error)): ?>
                            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
                        <?php endif; ?>
                        <form method="post">
                            <div class="form-group">
                                <label for="email">Digite seu e-mail:</label>
                                <input type="email" class="form-control" id="email" name="email" required>
                            </div>
                            <button type="submit" class="btn btn-success btn-block">Enviar Link de Redefinição</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
