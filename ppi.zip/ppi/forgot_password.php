<?php
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'vendor/autoload.php';
require 'conexao.php'; // Arquivo de conexão com o banco de dados

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'] ?? '';

    // Verifica se o e-mail está preenchido
    if (empty($email)) {
        $error = "O e-mail é obrigatório.";
    } else {
        try {
            // Verifica se o e-mail existe na tabela de usuários
            $query = "SELECT * FROM usuarios WHERE email = :email";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':email', $email);
            $stmt->execute();
            $user = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($user) {
                // Gerar token e inserir na tabela password_resets
                $token = bin2hex(random_bytes(50)); // Gerar um token seguro
                $expires = date('Y-m-d H:i:s', strtotime('+1 hour')); // Define a expiração do token para 1 hora a partir de agora

                $query = "INSERT INTO password_resets (email, token, expires) VALUES (:email, :token, :expires)";
                $stmt = $pdo->prepare($query);
                $stmt->bindParam(':email', $email);
                $stmt->bindParam(':token', $token);
                $stmt->bindParam(':expires', $expires);
                $stmt->execute();

                // Envia o e-mail com o link para redefinição de senha
                $mail = new PHPMailer(true);

                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.office365.com'; // Usando o servidor SMTP do Outlook
                    $mail->SMTPAuth = true;
                    $mail->Username = 'lorenzorpiovesan@hotmail.com'; // Seu e-mail
                    $mail->Password = 'xngfnxqowkrwywbd'; // Senha de aplicativo gerada
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    $mail->setFrom('lorenzorpiovesan@hotmail.com', 'SISGNA');
                    $mail->addAddress($email);

                    $mail->isHTML(true);
                    $mail->CharSet = 'UTF-8'; // Define o charset para UTF-8
                    $mail->Subject = 'Redefinição de Senha';

                    $resetLink = 'http://localhost/ppi/reset_password.php?token=' . urlencode($token);
                    $mail->Body = '
                    <html>
                    <head>
                        <meta charset="UTF-8">
                    </head>
                    <body>
                        <h2>Redefinição de Senha</h2>
                        <p>Você solicitou a redefinição de sua senha. Clique no link abaixo para criar uma nova senha:</p>
                        <p><a href="' . $resetLink . '">' . $resetLink . '</a></p>
                        <p>Se você não solicitou a redefinição de senha, ignore este e-mail.</p>
                        <p>Atenciosamente,<br>Equipe SISGNA</p>
                    </body>
                    </html>
                    ';
                    $mail->AltBody = 'Você solicitou a redefinição de sua senha. Clique no seguinte link para criar uma nova senha: ' . $resetLink;

                    $mail->send();
                    echo 'E-mail de recuperação enviado com sucesso.';
                } catch (Exception $e) {
                    echo 'Erro ao enviar e-mail: ', $mail->ErrorInfo;
                }
            } else {
                $error = "E-mail não encontrado.";
            }
        } catch (PDOException $e) {
            echo 'Erro ao buscar usuário: ' . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperação de Senha</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f0f0;
        }
        .container {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            width: 300px;
        }
        h2 {
            margin-top: 0;
        }
        label {
            display: block;
            margin-bottom: 5px;
        }
        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        button {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .error {
            color: red;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Recuperação de Senha</h2>
        <form method="post">
            <label>Digite seu e-mail:</label>
            <input type="email" name="email" required>
            <button type="submit">Enviar Link de Redefinição</button>
        </form>
        <?php if (isset($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
