<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Sisgna</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Estilos das turmas */
        .turmas-lista {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 20px;
            margin-top: 30px;
        }

        .turma {
            background-color: #4CAF50;
            color: white;
            padding: 15px 30px;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 200px;
            font-size: 1.1rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }

        .turma img {
            width: 100%;
            height: auto;
            margin-bottom: 10px;
            border-radius: 5px;
        }

        .turma:hover {
            background-color: #45a049;
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }

        .turma h3 {
            margin: 0;
        }

        /* Estilo do formulário de seleção de turma */
        
        
        .form2 {
            margin: 30px auto;
            width: 80%;
            max-width: 600px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 8px;
            background-color: #f9f9f9;
        }

        .form2 h2 {
            text-align: center;
            margin-bottom: 20px;
        }

        .form2 label {
            font-size: 1rem;
            margin-bottom: 10px;
        }

        .form2 select {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .form2 button {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 1rem;
            transition: background-color 0.3s;
        }

        .form2 button:hover {
            background-color: #45a049;
        }

        /* Estilo para os checkboxes */
        .checkbox-group {
            margin-bottom: 20px;
        }
        

    </style>
</head>
<body>
<div class="sidebar">
    <a href="admin.php" class="btn-home">Início</a>
    <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>

    <div id="dropdownMenu" class="dropdown-content" style="display: none;">
        <button onclick="showForm('aluno')">Cadastrar Aluno</button>
        <button onclick="showForm('turma')">Cadastrar Turma</button>
        <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
        <button onclick="showForm('professor')">Cadastrar Professor</button>
        <button onclick="showForm('setor')">Cadastrar Setor</button>
        <button onclick="showForm('curso')">Cadastrar Curso</button>
        <button onclick="showForm('add_admin')">Cadastrar Admin</button>
    </div>
    <button onclick="location.href='turmas.php'">Turmas</button>
    <button onclick="location.href='listar.php'">Listar</button>
    <button onclick="location.href='notificar.php'">Notificar</button>
    <button onclick="location.href='selecionar_turma.php'">Slides</button>
    <button onclick="location.href='gerar_boletim.php'">Boletim</button>
    <button onclick="location.href='setoradmin.php'">Setor</button>
</div>

<div class="main-content">
    <div class="header">
        <img src="iffarpng.png" alt="Logo da Empresa" class="logo">
        <h1>Bem-vindo ao Painel de Administração</h1>
        <form method="POST" action="logout.php">
            <button type="submit" name="logout" class="logout-button">Sair</button>
        </form>


    </div>

    

    <h2>Selecione a Turma</h2>
    <div class = "form2">
        <form action="gerar_slides.php" method="GET">
            <label for="id_turma">Escolha a turma:</label>
            <select name="id_turma" id="id_turma">
                <?php
                // Conectar ao banco de dados e obter as turmas
                $conn = new mysqli('localhost', 'root', '', 'sisgna');
                if ($conn->connect_error) {
                    die("Conexão falhou: " . $conn->connect_error);
                }

                // Consultar as turmas disponíveis
                $result = $conn->query("SELECT id, nome FROM turmas");

                // Mostrar as turmas no menu suspenso
                if ($result->num_rows > 0) {
                    while ($row = $result->fetch_assoc()) {
                        echo "<option value='" . $row['id'] . "'>" . utf8_decode($row['nome']) . "</option>";
                    }
                } else {
                    echo "<option value=''>Nenhuma turma encontrada</option>";
                }

                // Fechar a conexão
                $conn->close();
                ?>
            </select>

            <div class="checkbox-group">
                <h3>Selecione as notas que deseja incluir:</h3>
                <label>
                    <input type="checkbox" name="notas[]" value="nota_parcial_1"> Nota Parcial 1
                </label><br>
                <label>
                    <input type="checkbox" name="notas[]" value="nota_parcial_2"> Nota Parcial 2
                </label><br>
                <label>
                    <input type="checkbox" name="notas[]" value="semestre_1"> Semestre 1
                </label><br>
                <label>
                    <input type="checkbox" name="notas[]" value="semestre_2"> Semestre 2
                </label><br>
            </div>

            <button type="submit">Gerar Slides</button>
        </form>
    </div>
   

</div>

<!-- Importação dos scripts do Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
