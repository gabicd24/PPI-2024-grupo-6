<?php
// Iniciar a sessão
session_start();

// Incluir a conexão com o banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Obter todas as turmas
$queryTurmas = "SELECT id, nome FROM turmas";
$resultTurmas = $conn->query($queryTurmas);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Sisgna</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<div class="sidebar">
    <a href="admin.php" class="btn-home">
        <i class="fas fa-home"></i>
    </a>
    <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>

    <div id="dropdownMenu" class="dropdown-content" style="display: none;">
        <button onclick="showForm('aluno')">Cadastrar Aluno</button>
        <button onclick="showForm('turma')">Cadastrar Turma</button>
        <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
        <button onclick="showForm('professor')">Cadastrar Professor</button>
        <button onclick="showForm('setor')">Cadastrar Setor</button>
        <button onclick="showForm('curso')">Cadastrar Curso</button>
        <button onclick="showForm('add_admin')">Cadastrar Admin</button>
    </div>
    <button onclick="location.href='turmas.php'">Turmas</button>
    <button onclick="location.href='listar.php'">Listar</button>
    <button onclick="location.href='notificar.php'">Notificar</button>
    <button onclick="location.href='selecionar_turma.php'">Slides</button>
    <button onclick="location.href='gerar_boletim.php'">Boletim</button>
    <button onclick="location.href='setoradmin.php'">Setor</button>
</div>

<div class="main-content">
    <div class="header">
        <img src="iffarpng.png" alt="Logo da Empresa" class="logo">
        <h1>Bem-vindo ao Painel de Administração</h1>
        <form method="POST" action="logout.php" style="margin: 0;">
            <button type="submit" name="logout" class="logout-button btn btn-danger">Sair</button>
        </form>
    </div>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Gerar Boletim Escolar</h2>

        <form action="gerar_boletim_pdf.php" method="GET" class="form-group">
            <div class="form-row mb-3">
                <div class="col-md-6">
                    <label for="turma">Escolha a Turma:</label>
                    <select name="id_turma" id="turma" class="form-control">
                        <?php while ($turma = $resultTurmas->fetch_assoc()): ?>
                            <option value="<?php echo $turma['id']; ?>"><?php echo $turma['nome']; ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="tipo_nota">Escolha o Tipo de Nota:</label>
                    <select name="tipo_nota" id="tipo_nota" class="form-control">
                        <option value="nota_parcial_1">Nota Parcial 1</option>
                        <option value="semestre_1">Semestre 1</option>
                        <option value="nota_parcial_2">Nota Parcial 2</option>
                    </select>
                </div>
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-success btn-lg">Gerar Boletim</button>
            </div>
        </form>
    </div>

    <!-- Formulário para listar -->
    <!-- Barra de pesquisa -->
    <?php if (isset($_GET['lista'])): ?>
        <div class="mb-3">
            <input type="text" id="searchInput" class="form-control" placeholder="Pesquisar..." onkeyup="searchTable()">
        </div>
    <?php endif; ?>

    <!-- Exibir lista com base no botão clicado -->
    <!-- O conteúdo da lista será gerado dinamicamente aqui -->
</div>

<!-- Importação dos scripts do Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    // Função de busca na tabela
    function searchTable() {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        table = document.getElementById("dataTable");
        tr = table.getElementsByTagName("tr");

        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td");
            if (td.length > 0) {
                txtValue = "";
                for (var j = 0; j < td.length - 1; j++) { // Exclude action column
                    txtValue += td[j].textContent || td[j].innerText;
                }
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    }
</script>

</body>
</html>

<?php
// Fechar a conexão
$conn->close();
?>
