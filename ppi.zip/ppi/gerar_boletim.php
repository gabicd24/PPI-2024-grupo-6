<?php
// Iniciar a sessão
session_start();

// Incluir a conexão com o banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Obter todas as turmas
$queryTurmas = "SELECT id, nome FROM turmas";
$resultTurmas = $conn->query($queryTurmas);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerar Boletim Escolar</title>
    <!-- Link para o Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <!-- Link para FontAwesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- Link para o CSS personalizado -->
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar">
    <a href="admin.php" class="btn-home">
        <i class="fas fa-home"></i>
    </a>
    <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>

    <div id="dropdownMenu" class="dropdown-content" style="display: none;">
        <button onclick="showForm('aluno')">Cadastrar Aluno</button>
        <button onclick="showForm('turma')">Cadastrar Turma</button>
        <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
        <button onclick="showForm('professor')">Cadastrar Professor</button>
        <button onclick="showForm('setor')">Cadastrar Setor</button>
        <button onclick="showForm('curso')">Cadastrar Curso</button>
        <button onclick="showForm('add_admin')">Cadastrar Admin</button>
    </div>
    <button onclick="location.href='turmas.php'">Turmas</button>
    <button onclick="location.href='listar.php'">Listar</button>
    <button onclick="location.href='notificar.php'">Notificar</button>
    <button onclick="location.href='selecionar_turma.php'">Slides</button>
    <button onclick="location.href='gerar_boletim.php'">Boletim</button>
    <button onclick="location.href='setoradmin.php'">Setor</button>
</div>

<!-- Main content -->
<div class="main-content">
    <div class="header">
        <img src="iffarpng.png" alt="Logo da Empresa" class="logo">
        <h1>Gerar Boletim Escolar</h1>
        <form method="POST" action="logout.php" style="margin: 0;">
            <button type="submit" name="logout" class="logout-button">Sair</button>
        </form>
    </div>

    <div class="container mt-4">
        <h3>Selecione a Turma e os Tipos de Nota</h3>

        <!-- Formulário para selecionar turma e tipo de nota -->
        <form action="gerar_boletim_pdf.php" method="GET">
            <div class="form-group">
                <label for="turma">Escolha a Turma:</label>
                <select name="id_turma" id="turma" class="form-control">
                    <?php while ($turma = $resultTurmas->fetch_assoc()): ?>
                        <option value="<?php echo $turma['id']; ?>"><?php echo $turma['nome']; ?></option>
                    <?php endwhile; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="tipo_nota">Escolha o Tipo de Nota:</label><br>
                <input type="checkbox" name="tipo_nota[]" value="nota_parcial_1"> Nota Parcial 1<br>
                <input type="checkbox" name="tipo_nota[]" value="semestre_1"> Semestre 1<br>
                <input type="checkbox" name="tipo_nota[]" value="nota_parcial_2"> Nota Parcial 2<br>
                <input type="checkbox" name="tipo_nota[]" value="semestre_2"> Semestre 2<br>
            </div>

            <button type="submit" class="btn btn-primary">Gerar Boletim</button>
        </form>
    </div>
</div>

<!-- Importação dos scripts do Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>

<?php
// Fechar a conexão
$conn->close();
?>
