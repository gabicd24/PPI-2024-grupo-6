<?php
// Iniciar a sessão
session_start();

// Incluir a conexão com o banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Obter todas as turmas
$queryTurmas = "SELECT id, nome FROM turmas";
$resultTurmas = $conn->query($queryTurmas);

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerar Boletim Escolar</title>
</head>
<body>
    <h1>Selecione a Turma e o Tipo de Nota</h1>

    <form action="gerar_boletim_pdf.php" method="GET">
        <label for="turma">Escolha a Turma:</label>
        <select name="id_turma" id="turma">
            <?php while ($turma = $resultTurmas->fetch_assoc()): ?>
                <option value="<?php echo $turma['id']; ?>"><?php echo $turma['nome']; ?></option>
            <?php endwhile; ?>
        </select>

        <br><br>

        <label for="tipo_nota">Escolha o Tipo de Nota:</label>
        <select name="tipo_nota" id="tipo_nota">
            <option value="nota_parcial_1">Nota Parcial 1</option>
            <option value="semestre_1">Semestre 1</option>
            <option value="nota_parcial_2">Nota Parcial 2</option>
        </select>

        <br><br>

        <button type="submit">Gerar Boletim</button>
    </form>
</body>
</html>

<?php
// Fechar a conexão
$conn->close();
?>
