<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);
include 'conexao.php';

// Verifica se o ID do professor foi passado na URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Busca os dados do professor pelo ID
    $query = "SELECT * FROM professores WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $professor = $result->fetch_assoc();
    } else {
        echo "Professor não encontrado.";
        exit();
    }
} else {
    echo "ID de professor não especificado.";
    exit();
}

// Verifica se o formulário foi enviado para salvar a edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
 

    // Atualiza os dados do professor
    $query = "UPDATE professores SET nome = ?, email = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssi", $nome, $email, $id);

    if ($stmt->execute()) {
        // Atualiza as disciplinas
        $disciplinasSelecionadas = isset($_POST['disciplinas']) ? $_POST['disciplinas'] : [];

        // Remove disciplinas que não estão mais selecionadas
        $queryDelete = "DELETE FROM professor_disciplinas WHERE professor_id = ?";
        $stmtDelete = $conn->prepare($queryDelete);
        $stmtDelete->bind_param("i", $id);
        $stmtDelete->execute();

        // Adiciona as disciplinas selecionadas
        foreach ($disciplinasSelecionadas as $disciplina_id) {
            $queryInsert = "INSERT INTO professor_disciplinas (professor_id, disciplina_id) VALUES (?, ?)";
            $stmtInsert = $conn->prepare($queryInsert);
            $stmtInsert->bind_param("ii", $id, $disciplina_id);
            $stmtInsert->execute();
        }

        // Redireciona de volta para a página de listagem após a atualização
        header("Location: listar.php?lista=professores");
        exit();
    } else {
        echo "Erro ao atualizar o professor: " . $stmt->error;
    }
}

// Busca todas as disciplinas e suas respectivas turmas
$queryDisciplinas = "
    SELECT d.id AS disciplina_id, d.nome AS disciplina_nome, t.nome AS turma_nome 
    FROM disciplinas d 
    JOIN turmas t ON d.turma_id = t.id
";
$disciplinasResult = $conn->query($queryDisciplinas);

// Busca as disciplinas que o professor leciona
$queryProfessorDisciplinas = "SELECT disciplina_id FROM professor_disciplinas WHERE professor_id = ?";
$stmt = $conn->prepare($queryProfessorDisciplinas);
$stmt->bind_param("i", $id);
$stmt->execute();
$professorDisciplinasResult = $stmt->get_result();
$disciplinasProfessor = [];
while ($row = $professorDisciplinasResult->fetch_assoc()) {
    $disciplinasProfessor[] = $row['disciplina_id'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Professor</title>
    <!-- Link para o Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e9ecef;
            margin: 0;
            display: flex;
            height: 100vh;
            overflow: hidden;
        }

        .sidebar {
            width: 250px;
            background-color: #28a745;
            color: white;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            flex-shrink: 0;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }

        .sidebar .btn-home {
            display: inline-block;
            color: white;
            font-size: 32px;
            margin-bottom: -2px;
        }

        .sidebar button {
            width: 100%;
            text-align: left;
            color: white;
            background: none;
            border: none;
            font-size: 16px;
            padding: 10px;
            cursor: pointer;
            transition: background 0.3s ease;
            margin-bottom: 0px;
        }

        .sidebar button:hover {
            background-color: #218838;
        }

        .main-content {
            flex: 1;
            padding: 20px;
            background-color: white;
            overflow-y: auto;
            margin-left: 270px;
            height: 100vh;
            overflow-y: scroll;
        }

        .header {
            display: flex;
            align-items: center;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .logo {
            height: 120px;
            object-fit: cover;
            margin-right: 20px;
            flex-shrink: 0;
        }

        .logout-button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            transition: background 0.3s ease;
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .logout-button:hover {
            background-color: #218838;
        }

        .form-container {
            grid-template-columns: 1fr;
            gap: 15px;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px white;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <a href="admin.php" class="btn-home">
            <i class="fas fa-home"></i>
        </a>
        <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>
        <div id="dropdownMenu" class="dropdown-content" style="display: none;">
            <button onclick="showForm('aluno')">Cadastrar Aluno</button>
            <button onclick="showForm('turma')">Cadastrar Turma</button>
            <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
            <button onclick="showForm('professor')">Cadastrar Professor</button>
            <button onclick="showForm('setor')">Cadastrar Setor</button>
            <button onclick="showForm('curso')">Cadastrar Curso</button>
            <button onclick="showForm('add_admin')">Cadastrar Admin</button>
        </div>
        <button onclick="location.href='turmas.php'">Turmas</button>
        <button onclick="location.href='listar.php'">Listar</button>
        <button onclick="location.href='notificar.php'">Notificar</button>
        <button onclick="location.href='slides.php'">Slides</button>
        <button onclick="location.href='gerar_boletim.php'">Boletim</button>
        <button onclick="location.href='setoradmin.php'">Setor</button>
    </div>

    <div class="main-content">
        <h1>Editar Professor</h1>

        <form method="post">
            <!-- Nome -->
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" class="form-control" value="<?php echo htmlspecialchars($professor['nome']); ?>" required>
            </div>
            
            <!-- Email -->
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" id="email" name="email" class="form-control" value="<?php echo htmlspecialchars($professor['email']); ?>" required>
            </div>

    
      

            <!-- Disciplinas -->
            <div class="form-group">
                <label>Disciplinas:</label><br>
                <?php while ($disciplina = $disciplinasResult->fetch_assoc()): ?>
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" name="disciplinas[]" value="<?php echo $disciplina['disciplina_id']; ?>" 
                        <?php echo in_array($disciplina['disciplina_id'], $disciplinasProfessor) ? 'checked' : ''; ?>>
                        <label class="form-check-label">
                            <?php echo htmlspecialchars($disciplina['disciplina_nome']); ?> (Turma: <?php echo htmlspecialchars($disciplina['turma_nome']); ?>)
                        </label>
                    </div>
                <?php endwhile; ?>
            </div>

            <!-- Botões de Ação -->
            <div class="form-group text-center">
                <button type="submit" class="btn btn-success">Salvar Alterações</button>
                <a href="listar.php?lista=professores" class="btn btn-secondary ml-2">Cancelar</a>
            </div>
        </form>
    </div>

    <!-- Script para alternar a visibilidade do menu de cadastro -->
    <script>
        document.getElementById('toggleButton').addEventListener('click', function() {
            var menu = document.getElementById('dropdownMenu');
            menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
        });
    </script>

    <!-- Link para o Bootstrap JS (se necessário) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
