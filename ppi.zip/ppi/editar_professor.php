<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verifica se o ID do professor foi passado na URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Busca os dados do professor pelo ID
    $query = "SELECT * FROM professores WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $professor = $result->fetch_assoc();
    } else {
        echo "Professor não encontrado.";
        exit();
    }
} else {
    echo "ID de professor não especificado.";
    exit();
}

// Verifica se o formulário foi enviado para salvar a edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $cpf = $_POST['cpf'];

    // Atualiza os dados do professor
    $query = "UPDATE professores SET nome = ?, email = ?, cpf = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssi", $nome, $email, $cpf, $id);

    if ($stmt->execute()) {
        // Atualiza as disciplinas
        $disciplinasSelecionadas = isset($_POST['disciplinas']) ? $_POST['disciplinas'] : [];

        // Remove disciplinas que não estão mais selecionadas
        $queryDelete = "DELETE FROM professor_disciplinas WHERE professor_id = ?";
        $stmtDelete = $conn->prepare($queryDelete);
        $stmtDelete->bind_param("i", $id);
        $stmtDelete->execute();

        // Adiciona as disciplinas selecionadas
        foreach ($disciplinasSelecionadas as $disciplina_id) {
            $queryInsert = "INSERT INTO professor_disciplinas (professor_id, disciplina_id) VALUES (?, ?)";
            $stmtInsert = $conn->prepare($queryInsert);
            $stmtInsert->bind_param("ii", $id, $disciplina_id);
            $stmtInsert->execute();
        }

        // Redireciona de volta para a página de listagem após a atualização
        header("Location: listar.php?mensagem=Professor atualizado com sucesso");
        exit();
    } else {
        echo "Erro ao atualizar o professor: " . $stmt->error;
    }
}

// Busca todas as disciplinas e suas respectivas turmas
$queryDisciplinas = "
    SELECT d.id AS disciplina_id, d.nome AS disciplina_nome, t.nome AS turma_nome 
    FROM disciplinas d 
    JOIN turmas t ON d.turma_id = t.id
";
$disciplinasResult = $conn->query($queryDisciplinas);

// Busca as disciplinas que o professor leciona
$queryProfessorDisciplinas = "SELECT disciplina_id FROM professor_disciplinas WHERE professor_id = ?";
$stmt = $conn->prepare($queryProfessorDisciplinas);
$stmt->bind_param("i", $id);
$stmt->execute();
$professorDisciplinasResult = $stmt->get_result();
$disciplinasProfessor = [];
while ($row = $professorDisciplinasResult->fetch_assoc()) {
    $disciplinasProfessor[] = $row['disciplina_id'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar Professor</title>
</head>
<body>
    <h2>Editar Professor</h2>
    <form action="" method="post">
        <label for="nome">Nome:</label><br>
        <input type="text" id="nome" name="nome" value="<?php echo htmlspecialchars($professor['nome']); ?>" required><br><br>
        
        <label for="email">Email:</label><br>
        <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($professor['email']); ?>" required><br><br>
        
        <label for="cpf">CPF:</label><br>
        <input type="text" id="cpf" name="cpf" value="<?php echo htmlspecialchars($professor['cpf']); ?>" required><br><br>
        
        <label>Disciplinas:</label><br>
        <?php while ($disciplina = $disciplinasResult->fetch_assoc()): ?>
            <input type="checkbox" name="disciplinas[]" value="<?php echo $disciplina['disciplina_id']; ?>" 
            <?php echo in_array($disciplina['disciplina_id'], $disciplinasProfessor) ? 'checked' : ''; ?>>
            <?php echo htmlspecialchars($disciplina['disciplina_nome']); ?> (Turma: <?php echo htmlspecialchars($disciplina['turma_nome']); ?>)<br>
        <?php endwhile; ?>
        <br>
        
        <input type="submit" value="Salvar">
        <button type="button" onclick="window.location.href='listar.php'">Cancelar</button>
    </form>
</body>
</html>
