<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se o ID da disciplina foi passado pela URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Primeiro, excluir as referências na tabela professor_disciplinas
    $queryExcluirReferencias = "DELETE FROM professor_disciplinas WHERE disciplina_id = $id";
    $conn->query($queryExcluirReferencias);

    // Agora, excluir a disciplina
    $queryExcluirDisciplina = "DELETE FROM disciplinas WHERE id = $id";

    if ($conn->query($queryExcluirDisciplina) === TRUE) {
        echo "Disciplina excluída com sucesso.";
    } else {
        echo "Erro ao excluir disciplina: " . $conn->error;
    }
} else {
    echo "ID da disciplina não fornecido.";
}

// Redirecionar para a lista de disciplinas após um breve momento
header("Refresh: 2; url=listar.php"); // Redireciona após 2 segundos
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir Disciplina</title>
</head>
<body>
    <h1>Resultado da Exclusão</h1>
    <p>
        <?php
        // Exibe a mensagem de resultado da exclusão
        if (isset($message)) {
            echo htmlspecialchars($message);
        }
        ?>
    </p>
    <p>Redirecionando para a lista de disciplinas...</p>
</body>
</html>

<?php
// Fechar conexão
$conn->close();
?>
