<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Sisgna</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
</head>
<body>
<div class="sidebar">
    <a href="admin.php" class="btn-home">
        <i class="fas fa-home"></i>
    </a>
    <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>

    <div id="dropdownMenu" class="dropdown-content" style="display: none;">
        <button onclick="showForm('aluno')">Cadastrar Aluno</button>
        <button onclick="showForm('turma')">Cadastrar Turma</button>
        <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
        <button onclick="showForm('professor')">Cadastrar Professor</button>
        <button onclick="showForm('setor')">Cadastrar Setor</button>
        <button onclick="showForm('curso')">Cadastrar Curso</button>
        <button onclick="showForm('add_admin')">Cadastrar Admin</button>
    </div>
    <button onclick="location.href='turmas.php'">Turmas</button>
    <button onclick="location.href='listar.php'">Listar</button>
    <button onclick="location.href='notificar.php'">Notificar</button>
    <button onclick="location.href='slides.php'">Slides</button>
    <button onclick="location.href='setoradmin.php'">Setor</button>
</div>

<div class="main-content">
    <div class="header">
        <img src="iffarpng.png" alt="Logo da Empresa" class="logo">
        <h1>Bem-vindo ao Painel de Administração</h1>
        <form method="POST" action="logout.php" style="margin: 0;">
            <button type="submit" name="logout" class="logout-button">Sair</button>
        </form>
    </div>

    <div class="container mt-4">

        <!-- Formulário para listar -->
        <div class="text-center mb-3">
            <form method="GET" action="">
                <button name="lista" value="alunos" class="btn btn-success">Lista de Alunos</button>
                <button name="lista" value="turmas" class="btn btn-success">Lista de Turmas</button>
                <button name="lista" value="professores" class="btn btn-success">Lista de Professores</button>
                <button name="lista" value="disciplinas" class="btn btn-success">Lista de Disciplinas</button>
                <button name="lista" value="setores" class="btn btn-success">Lista de Setores</button>
                <button name="lista" value="administradores" class="btn btn-success">Lista de Administradores</button>
            </form>
        </div>

        <!-- Barra de pesquisa -->
        <?php if (isset($_GET['lista'])): ?>
            <div class="mb-3">
                <input type="text" id="searchInput" class="form-control" placeholder="Pesquisar..." onkeyup="searchTable()">
            </div>
        <?php endif; ?>

        <!-- Exibir lista com base no botão clicado -->
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "";
        $dbname = "sisgna";
        
        // Criar conexão
        $conn = new mysqli($servername, $username, $password, $dbname);
        include 'conexao.php';

        if (isset($_GET['lista'])) {
            $lista = $_GET['lista'];

            switch ($lista) {
                case 'alunos':
                    $queryAlunos = "SELECT a.id, a.nome, a.email, a.matricula, COALESCE(t.nome, 'Não Atribuído') AS turma
                                    FROM alunos a
                                    LEFT JOIN turmas t ON a.turma_id = t.id";
                    
                    $tituloAlunos = "Lista de Alunos";
                    $colunasAlunos = ['ID', 'Nome', 'Email', 'Matricula', 'Turma'];
                    gerarTabela($conn, $queryAlunos, $tituloAlunos, $colunasAlunos);
                    break;

                case 'turmas':
                    $queryTurmas = "SELECT id, nome, 
                                            COALESCE(lider, 'Não Atribuído') AS lider, 
                                            COALESCE(regente, 'Não Atribuído') AS regente
                                    FROM turmas";
                    
                    $tituloTurmas = "Lista de Turmas";
                    $colunasTurmas = ['ID', 'Nome', 'Líder', 'Regente'];
                    gerarTabela($conn, $queryTurmas, $tituloTurmas, $colunasTurmas);
                    break;

                case 'professores':
                    $queryProfessores = "SELECT p.id, p.nome, p.email, p.foto,
                                         GROUP_CONCAT(DISTINCT CONCAT(d.nome, ' - (', t.nome, ')') SEPARATOR ', ') AS disciplinas
                                  FROM professores p
                                  LEFT JOIN professor_disciplinas pd ON p.id = pd.professor_id
                                  LEFT JOIN disciplinas d ON pd.disciplina_id = d.id
                                  LEFT JOIN turmas t ON d.turma_id = t.id
                                  GROUP BY p.id, p.nome, p.email, p.foto";

                    $tituloProfessores = "Lista de Professores";
                    $colunasProfessores = ['ID', 'Nome', 'Email', 'Foto', 'Disciplinas'];
                    gerarTabela($conn, $queryProfessores, $tituloProfessores, $colunasProfessores);
                    break;

                case 'disciplinas':
                    $queryDisciplinas = "SELECT d.id, d.nome AS disciplina, 
                                         COALESCE(t.nome, 'Não Atribuído') AS turma
                                  FROM disciplinas d
                                  LEFT JOIN turmas t ON d.turma_id = t.id";

                    $tituloDisciplinas = "Lista de Disciplinas";
                    $colunasDisciplinas = ['ID', 'Disciplina', 'Turma'];
                    gerarTabela($conn, $queryDisciplinas, $tituloDisciplinas, $colunasDisciplinas);
                    break;

                case 'setores':
                    $querySetores = "SELECT id, nome, email, tipo
                                     FROM setores";

                    $tituloSetores = "Lista de Setores";
                    $colunasSetores = ['ID', 'Nome', 'Email', 'Tipo'];
                    gerarTabela($conn, $querySetores, $tituloSetores, $colunasSetores);
                    break;

                case 'administradores':
                    $queryAdmins = "SELECT id, username, email, tipo
                                    FROM usuarios
                                    WHERE tipo = 'admin'";

                    $tituloAdmins = "Lista de Administradores";
                    $colunasAdmins = ['ID', 'Username', 'Email', 'Tipo'];
                    gerarTabela($conn, $queryAdmins, $tituloAdmins, $colunasAdmins);
                    break;

                default:
                    echo "<p>Selecione uma lista para visualizar.</p>";
                    break;
            }
        }

        // Função para gerar a tabela
        function gerarTabela($conn, $query, $titulo, $colunas) {
            echo "<h2>$titulo</h2>";
            $result = $conn->query($query);

            if (!$result) {
                die("Erro na consulta: " . $conn->error);
            }

            if ($result->num_rows > 0) {
                echo "<table id='dataTable' class='table table-striped'><thead><tr>";
                foreach ($colunas as $coluna) {
                    echo "<th>$coluna</th>";
                }
                echo "<th>Ações</th>"; // Coluna para ações
                echo "</tr></thead><tbody>";

                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";

                    foreach ($colunas as $coluna) {
                        $colunaLower = strtolower(str_replace(' ', '_', $coluna));
                        echo "<td>" . htmlspecialchars($row[$colunaLower] ?? 'Não Atribuído') . "</td>";
                    }

                    // Botões de Ação
                    echo "<td>";
                    // Adiciona botão de Editar conforme o tipo da tabela
                    if ($titulo === 'Lista de Professores') {
                        echo "<a href='editar_professor.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Editar</a> ";
                        echo "<a href='processa_exclusao_professor.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Tem certeza que deseja excluir este professor?\")'>Excluir</a>";
                    } elseif ($titulo === 'Lista de Alunos') {
                        echo "<a href='editar_aluno.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Editar</a> ";
                        echo "<a href='processa_exclusao_aluno.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Tem certeza que deseja excluir este aluno?\")'>Excluir</a>";
                    } elseif ($titulo === 'Lista de Turmas') {
                        echo "<a href='editar_turma.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Editar</a> ";
                        echo "<a href='processa_exclusao_turma.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Tem certeza que deseja excluir esta turma?\")'>Excluir</a>";
                    } elseif ($titulo === 'Lista de Disciplinas') {
                        echo "<a href='editar_disciplinas.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Editar</a> ";
                        echo "<a href='processa_exclusao_disciplina.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Tem certeza que deseja excluir esta disciplina?\")'>Excluir</a>";
                    } elseif ($titulo === 'Lista de Setores') {
                        echo "<a href='editar_setor.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Editar</a> ";
                        echo "<a href='processa_exclusao_setor.php?id=" . $row['id'] . "' class='btn btn-danger btn-sm' onclick='return confirm(\"Tem certeza que deseja excluir este setor?\")'>Excluir</a>";
                    } elseif ($titulo === 'Lista de Administradores') {
                        echo "<a href='editar_admin.php?id=" . $row['id'] . "' class='btn btn-warning btn-sm'>Editar</a> ";
                        // No "Excluir" button for Administradores as per your request
                    }
                    echo "</td>";

                    echo "</tr>";
                }

                echo "</tbody></table>";
            } else {
                echo "<p>Nenhum registro encontrado.</p>";
            }
        }
        ?>
    </div>

</div>

<!-- Importação dos scripts do Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

<script>
    // Função de busca na tabela
    function searchTable() {
        var input, filter, table, tr, td, i, txtValue;
        input = document.getElementById("searchInput");
        filter = input.value.toUpperCase();
        table = document.getElementById("dataTable");
        tr = table.getElementsByTagName("tr");

        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td");
            if (td.length > 0) {
                txtValue = "";
                for (var j = 0; j < td.length - 1; j++) { // Exclude action column
                    txtValue += td[j].textContent || td[j].innerText;
                }
                if (txtValue.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    }
</script>

</body>
</html>
