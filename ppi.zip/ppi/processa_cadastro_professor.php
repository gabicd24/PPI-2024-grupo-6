<?php
// Incluir o arquivo de configuração ou conexão com o banco de dados
include 'conexao.php'; // Substitua pelo caminho correto para sua configuração de banco de dados

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Receber dados do formulário
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $cpf = trim($_POST['cpf']);
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT); // Criptografar a senha
    $disciplinas = isset($_POST['disciplinas']) ? $_POST['disciplinas'] : []; // Disciplinas selecionadas

    // Processamento de foto
    $foto = null; // Inicializa a variável
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $foto = $_FILES['foto']['name'];
        $fotoTmp = $_FILES['foto']['tmp_name'];
        $fotoDir = 'professorfoto'; // Caminho do diretório
        $fotoDest = $fotoDir . '/' . $foto; // Caminho completo para salvar a foto

        // Verifica se a pasta existe, se não, cria a pasta
        if (!is_dir($fotoDir)) {
            if (!mkdir($fotoDir, 0755, true)) {
                header("Location: admin.php?error=" . urlencode("Erro ao criar o diretório para as fotos."));
                exit();
            }
        }

        // Tenta mover o arquivo para o diretório especificado
        if (!move_uploaded_file($fotoTmp, $fotoDest)) {
            header("Location: admin.php?error=" . urlencode("Erro ao fazer upload da foto. Verifique as permissões da pasta e o caminho do diretório."));
            exit();
        }
    } elseif (isset($_FILES['foto']) && $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE) {
        // Verifica se ocorreu um erro de upload
        $uploadError = $_FILES['foto']['error'];
        header("Location: admin.php?error=" . urlencode("Erro ao fazer upload da foto. Código do erro: $uploadError."));
        exit();
    }

    try {
        // Verificar se o CPF já está registrado
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM professores WHERE cpf = ?");
        $stmt->execute([$cpf]);
        if ($stmt->fetchColumn() > 0) {
            throw new Exception("CPF já cadastrado.");
        }

        // Verificar se o e-mail já está registrado
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM professores WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetchColumn() > 0) {
            throw new Exception("E-mail já cadastrado.");
        }

        // Inserir professor no banco de dados
        $stmt = $pdo->prepare("INSERT INTO professores (nome, email, cpf, senha, foto) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$nome, $email, $cpf, $senha, $foto]);

        // Obter o ID do professor inserido
        $professor_id = $pdo->lastInsertId();

        // Inserir o professor na tabela de usuários com a role apropriada
        $stmt_usuario = $pdo->prepare("INSERT INTO usuarios (username, email, password_hash, tipo) VALUES (?, ?, ?, ?)");
        $tipo = 'professor'; // Definindo o tipo como professor
        $stmt_usuario->execute([$nome, $email, $senha, $tipo]);

        // Associar disciplinas ao professor
        if (!empty($disciplinas)) {
            $stmt_disciplinas = $pdo->prepare("INSERT INTO professor_disciplinas (professor_id, disciplina_id) VALUES (?, ?)");
            foreach ($disciplinas as $disciplina_id) {
                $stmt_disciplinas->execute([$professor_id, $disciplina_id]);
            }
        }

        // Redirecionar com sucesso
        header('Location: admin.php?success=' . urlencode('Cadastro realizado com sucesso.'));
        exit();

    } catch (PDOException $e) {
        // Mensagem de erro detalhada para PDOException
        $errorMsg = "Erro na base de dados: " . $e->getMessage();
        header("Location: admin.php?error=" . urlencode($errorMsg));
        exit();
    } catch (Exception $e) {
        // Mensagem de erro detalhada para Exception
        $errorMsg = "Erro: " . $e->getMessage();
        header("Location: admin.php?error=" . urlencode($errorMsg));
        exit();
    }
} else {
    // Redirecionar para a página de cadastro se a solicitação não for POST
    header('Location: admin.php');
    exit();
}
?>
