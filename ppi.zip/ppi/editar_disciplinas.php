<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);
include 'conexao.php';

// Verificar se o ID da disciplina foi passado pela URL
if (!isset($_GET['id'])) {
    die("ID da disciplina não fornecido.");
}

$id = $_GET['id'];
$mensagem = "";

// Processar o formulário se ele for enviado
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nomeDisciplina = $_POST['nome'];
    $professorId = $_POST['professor_id'] !== '' ? $_POST['professor_id'] : null;

    // Atualizar o nome da disciplina
    $queryUpdateDisciplina = "UPDATE disciplinas SET nome = ? WHERE id = ?";
    $stmtUpdateDisciplina = $conn->prepare($queryUpdateDisciplina);
    $stmtUpdateDisciplina->bind_param("si", $nomeDisciplina, $id);
    $stmtUpdateDisciplina->execute();

    // Atualizar ou remover a associação do professor à disciplina
    $queryUpdateProfessor = $professorId 
        ? "REPLACE INTO professor_disciplinas (disciplina_id, professor_id) VALUES (?, ?)"
        : "DELETE FROM professor_disciplinas WHERE disciplina_id = ?";
    $stmtUpdateProfessor = $conn->prepare($queryUpdateProfessor);
    
    if ($professorId) {
        $stmtUpdateProfessor->bind_param("ii", $id, $professorId);
    } else {
        $stmtUpdateProfessor->bind_param("i", $id);
    }
    $stmtUpdateProfessor->execute();

    // Redirecionar para a página de listagem com a mensagem de sucesso
    header("Location: listar.php?lista=disciplinas");
    exit;
}

// Consultar dados atuais da disciplina
$queryDisciplina = "SELECT d.id, d.nome AS disciplina, t.nome AS turma_nome, COALESCE(p.id, '') AS professor_id
                    FROM disciplinas d
                    LEFT JOIN professor_disciplinas pd ON d.id = pd.disciplina_id
                    LEFT JOIN professores p ON pd.professor_id = p.id
                    LEFT JOIN turmas t ON d.turma_id = t.id
                    WHERE d.id = ?";
$stmtDisciplina = $conn->prepare($queryDisciplina);
$stmtDisciplina->bind_param("i", $id);
$stmtDisciplina->execute();
$resultDisciplina = $stmtDisciplina->get_result();
$disciplina = $resultDisciplina->fetch_assoc();

if (!$disciplina) {
    die("Disciplina não encontrada.");
}

// Obter a lista de professores para exibir no dropdown
$queryProfessores = "SELECT id, nome FROM professores";
$resultProfessores = $conn->query($queryProfessores);

// Fechar consulta da disciplina
$stmtDisciplina->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Disciplina</title>
    <!-- Link do Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e9ecef;
            margin: 0;
            display: flex;
            height: 100vh;
            overflow: hidden;
        }

        .sidebar {
            width: 250px;
            background-color: #28a745;
            color: white;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            bottom: 0;
            left: 0;
            flex-shrink: 0;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
        }

        .sidebar .btn-home {
            display: inline-block;
            color: white;
            font-size: 32px;
            margin-bottom: -2px;
        }

        .sidebar button {
            width: 100%;
            text-align: left;
            color: white;
            background: none;
            border: none;
            font-size: 16px;
            padding: 10px;
            cursor: pointer;
            transition: background 0.3s ease;
            margin-bottom: 0px;
        }

        .sidebar button:hover {
            background-color: #218838;
        }

        .main-content {
            flex: 1;
            padding: 20px;
            background-color: white;
            overflow-y: auto;
            margin-left: 270px;
            height: 100vh;
            overflow-y: scroll;
        }

        .header {
            display: flex;
            align-items: center;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .logo {
            height: 120px;
            object-fit: cover;
            margin-right: 20px;
            flex-shrink: 0;
        }

        .logout-button {
            background-color: #28a745;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            transition: background 0.3s ease;
            position: absolute;
            top: 20px;
            right: 20px;
        }

        .logout-button:hover {
            background-color: #218838;
        }

        .form-container {
            grid-template-columns: 1fr;
            gap: 15px;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px white;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <a href="admin.php" class="btn-home">
            <i class="fas fa-home"></i>
        </a>
        <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>
        <div id="dropdownMenu" class="dropdown-content" style="display: none;">
            <button onclick="showForm('aluno')">Cadastrar Aluno</button>
            <button onclick="showForm('turma')">Cadastrar Turma</button>
            <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
            <button onclick="showForm('professor')">Cadastrar Professor</button>
            <button onclick="showForm('setor')">Cadastrar Setor</button>
            <button onclick="showForm('curso')">Cadastrar Curso</button>
            <button onclick="showForm('add_admin')">Cadastrar Admin</button>
        </div>
        <button onclick="location.href='turmas.php'">Turmas</button>
        <button onclick="location.href='listar.php'">Listar</button>
        <button onclick="location.href='notificar.php'">Notificar</button>
        <button onclick="location.href='slides.php'">Slides</button>
        <button onclick="location.href='setoradmin.php'">Setor</button>
    </div>

    <div class="main-content">
        <h1>Editar Disciplina</h1>
        
        <form method="post">
            <div class="form-group">
                <label for="nome">Nome da Disciplina:</label>
                <input type="text" name="nome" id="nome" class="form-control" value="<?php echo htmlspecialchars($disciplina['disciplina']); ?>" required>
            </div>

            <div class="form-group">
                <label for="turma">Turma:</label>
                <input type="text" id="turma" class="form-control" value="<?php echo htmlspecialchars($disciplina['turma_nome']); ?>" readonly>
            </div>

            <div class="form-group">
                <label for="professor">Professor:</label>
                <select name="professor_id" id="professor" class="form-control">
                    <option value="">Nenhum professor atribuído</option>
                    <?php while ($professor = $resultProfessores->fetch_assoc()) { ?>
                        <option value="<?php echo $professor['id']; ?>" <?php echo ($professor['id'] == $disciplina['professor_id']) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($professor['nome']); ?>
                        </option>
                    <?php } ?>
                </select>
            </div>
                        <p>
                    </p>
            <div class="form-group text-center">
                <button type="submit" class="btn btn-success">Salvar Alterações</button>
                <a href="listar.php" class="btn btn-secondary ml-2">Cancelar</a>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Fechar a conexão com o banco de dados
$conn->close();
?>
