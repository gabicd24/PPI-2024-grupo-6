<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);
include 'conexao.php';

// Verificar se o ID da disciplina foi passado pela URL
if (!isset($_GET['id'])) {
    die("ID da disciplina não fornecido.");
}

$id = $_GET['id'];
$mensagem = "";

// Processar o formulário se ele for enviado
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nomeDisciplina = $_POST['nome'];
    $professorId = $_POST['professor_id'] !== '' ? $_POST['professor_id'] : null;

    // Atualizar o nome da disciplina
    $queryUpdateDisciplina = "UPDATE disciplinas SET nome = ? WHERE id = ?";
    $stmtUpdateDisciplina = $conn->prepare($queryUpdateDisciplina);
    $stmtUpdateDisciplina->bind_param("si", $nomeDisciplina, $id);
    $stmtUpdateDisciplina->execute();

    // Atualizar ou remover a associação do professor à disciplina
    $queryUpdateProfessor = $professorId 
        ? "REPLACE INTO professor_disciplinas (disciplina_id, professor_id) VALUES (?, ?)"
        : "DELETE FROM professor_disciplinas WHERE disciplina_id = ?";
    $stmtUpdateProfessor = $conn->prepare($queryUpdateProfessor);
    
    if ($professorId) {
        $stmtUpdateProfessor->bind_param("ii", $id, $professorId);
    } else {
        $stmtUpdateProfessor->bind_param("i", $id);
    }
    $stmtUpdateProfessor->execute();

    // Redirecionar para a página de listagem com a mensagem de sucesso
    header("Location: listar.php?mensagem=Disciplina atualizada com sucesso!");
    exit;
}

// Consultar dados atuais da disciplina
$queryDisciplina = "SELECT d.id, d.nome AS disciplina, t.nome AS turma_nome, COALESCE(p.id, '') AS professor_id
                    FROM disciplinas d
                    LEFT JOIN professor_disciplinas pd ON d.id = pd.disciplina_id
                    LEFT JOIN professores p ON pd.professor_id = p.id
                    LEFT JOIN turmas t ON d.turma_id = t.id
                    WHERE d.id = ?";
$stmtDisciplina = $conn->prepare($queryDisciplina);
$stmtDisciplina->bind_param("i", $id);
$stmtDisciplina->execute();
$resultDisciplina = $stmtDisciplina->get_result();
$disciplina = $resultDisciplina->fetch_assoc();

if (!$disciplina) {
    die("Disciplina não encontrada.");
}

// Obter a lista de professores para exibir no dropdown
$queryProfessores = "SELECT id, nome FROM professores";
$resultProfessores = $conn->query($queryProfessores);

// Fechar consulta da disciplina
$stmtDisciplina->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Editar Disciplina</title>
</head>
<body>
    <h2>Editar Disciplina</h2>
    <form method="post">
        <!-- Nome da Disciplina -->
        <label for="nome">Nome da Disciplina:</label>
        <input type="text" name="nome" id="nome" value="<?php echo htmlspecialchars($disciplina['disciplina']); ?>" required>

        <!-- Nome da Turma (Somente Leitura) -->
        <label for="turma">Turma:</label>
        <input type="text" id="turma" value="<?php echo htmlspecialchars($disciplina['turma_nome']); ?>" readonly>

        <!-- Seleção de Professor -->
        <label for="professor">Professor:</label>
        <select name="professor_id" id="professor">
            <option value="">Nenhum professor atribuído</option>
            <?php while ($professor = $resultProfessores->fetch_assoc()) { ?>
                <option value="<?php echo $professor['id']; ?>" <?php echo ($professor['id'] == $disciplina['professor_id']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($professor['nome']); ?>
                </option>
            <?php } ?>
        </select>

        <button type="submit">Salvar Alterações</button>
        <a href="listar.php"><button type="button">Cancelar</button></a>
    </form>
</body>
</html>

<?php
// Fechar conexão
$conn->close();
?>
