<?php
// Configurações do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Dados do formulário
    $nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
    $descricao = isset($_POST['descricao']) ? trim($_POST['descricao']) : ''; // Pode ser vazio

    // Verifica se o campo nome está preenchido
    if (empty($nome)) {
        $errorMsg = "Nome é obrigatório.";
        header("Location: admin.php?error=" . urlencode($errorMsg));
        exit();
    }

    // Prepara a declaração SQL
    $sql = "INSERT INTO cursos (nome, descricao) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        $errorMsg = "Erro na preparação da declaração: " . $conn->error;
        header("Location: admin.php?error=" . urlencode($errorMsg));
        exit();
    }

    // Vincula os parâmetros e executa a declaração
    $stmt->bind_param("ss", $nome, $descricao); // Descrição pode ser vazia

    if ($stmt->execute()) {
        $successMsg = "Curso cadastrado com sucesso.";
        header("Location: admin.php?success=" . urlencode($successMsg));
    } else {
        $errorMsg = "Erro ao cadastrar o curso: " . $stmt->error;
        header("Location: admin.php?error=" . urlencode($errorMsg));
    }

    // Fecha a declaração e a conexão
    $stmt->close();
} else {
    $errorMsg = "Método de solicitação inválido.";
    header("Location: admin.php?error=" . urlencode($errorMsg));
}

$conn->close();
?>
