<?php
session_start(); // Iniciar a sessão para armazenar mensagens

// Configurações do banco de dados
$host = 'localhost';
$user = 'root';
$pass = '';
$db   = 'sisgna';

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
    $descricao = isset($_POST['descricao']) ? trim($_POST['descricao']) : '';

    // Verifica se o campo nome está preenchido
    if (empty($nome)) {
        $_SESSION['error'] = "Nome é obrigatório.";
        header("Location: admin.php");
        exit();
    }

    // Prepara a declaração SQL
    $sql = "INSERT INTO cursos (nome, descricao) VALUES (?, ?)";
    $stmt = $conn->prepare($sql);

    if ($stmt === false) {
        $_SESSION['error'] = "Erro na preparação da declaração: " . $conn->error;
        header("Location: admin.php");
        exit();
    }

    // Vincula os parâmetros e executa a declaração
    $stmt->bind_param("ss", $nome, $descricao);

    if ($stmt->execute()) {
        $_SESSION['success'] = "Cadastrado realizado.";
    } else {
        $_SESSION['error'] = "Erro ao cadastrar o curso: " . $stmt->error;
    }

    // Fecha a declaração e a conexão
    $stmt->close();
    $conn->close();

    header("Location: admin.php");
    exit();
}
?>
