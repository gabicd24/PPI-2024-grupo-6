<?php
// Incluir a biblioteca FPDF
require('fpdf/fpdf.php');

// Iniciar a sessão
session_start();

// Incluir a conexão com o banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Obter o id da turma e o tipo de nota a ser exibida
$id_turma = isset($_GET['id_turma']) ? intval($_GET['id_turma']) : 0;
$tipo_nota = isset($_GET['tipo_nota']) ? $_GET['tipo_nota'] : 'semestre_1';  // Default 'semestre_1'

// Verificar se o id da turma é válido
if ($id_turma <= 0) {
    die("ID da turma inválido.");
}

// Obter os alunos dessa turma, suas disciplinas, notas e observações
$queryAlunos = "
    SELECT a.id AS aluno_id, a.nome AS aluno_nome, d.nome AS disciplina, 
           n.nota_parcial_1, n.semestre_1, n.nota_parcial_2, n.semestre_2, 
           n.numero_faltas, n.obs_parcial_1, n.obs_1_semestre, n.obs_parcial_2, n.obs_2_semestre,
           n.ais, n.aia, n.amostra
    FROM alunos a
    LEFT JOIN notas n ON a.id = n.aluno_id
    LEFT JOIN disciplinas d ON n.disciplina_id = d.id
    WHERE a.turma_id = ?
";

// Preparar a consulta
$stmt = $conn->prepare($queryAlunos);
if (!$stmt) {
    die("Erro ao preparar a consulta: " . $conn->error);
}
$stmt->bind_param('i', $id_turma);
$stmt->execute();
$resultAlunos = $stmt->get_result();

// Obter o nome da turma
$queryTurma = "SELECT nome FROM turmas WHERE id = ?";
$stmt = $conn->prepare($queryTurma);
if (!$stmt) {
    die("Erro ao preparar a consulta: " . $conn->error);
}
$stmt->bind_param('i', $id_turma);
$stmt->execute();
$stmt->bind_result($nome_turma);
$stmt->fetch();

// Verificar se há alunos
if ($resultAlunos->num_rows > 0) {
    // Agrupar as notas por aluno
    $alunos = [];
    while ($aluno = $resultAlunos->fetch_assoc()) {
        $alunos[$aluno['aluno_id']]['nome'] = $aluno['aluno_nome'];
        $alunos[$aluno['aluno_id']]['disciplinas'][] = [
            'disciplina'      => $aluno['disciplina'],
            'nota_parcial_1'  => $aluno['nota_parcial_1'],
            'semestre_1'      => $aluno['semestre_1'],
            'nota_parcial_2'  => $aluno['nota_parcial_2'],
            'semestre_2'      => $aluno['semestre_2'],
            'numero_faltas'   => $aluno['numero_faltas'],
            'obs_parcial_1'   => $aluno['obs_parcial_1'] ?? '',  // Verificando se a chave existe
            'obs_1_semestre'  => $aluno['obs_1_semestre'],
            'obs_parcial_2'   => $aluno['obs_parcial_2'],
            'obs_2_semestre'  => $aluno['obs_2_semestre'],
            'ais'             => $aluno['ais'],
            'aia'             => $aluno['aia'],
            'amostra'         => $aluno['amostra']
        ];
    }
} else {
    die("Nenhum aluno encontrado para esta turma.");
}

// Fechar a conexão
$stmt->close();
$conn->close();

// Criar o PDF
$pdf = new FPDF();
$pdf->SetFont('Arial', 'B', 16);

// Configurar o PDF para UTF-8 (necessário para suportar acentuação)
$pdf->SetAutoPageBreak(true, 10); // Definir margem de 10 para quebra de página

// Criar o PDF para cada aluno
foreach ($alunos as $aluno) {
    // Criar uma nova página para cada aluno
    $pdf->AddPage();

    // Título da página de notas e observações
    $pdf->Cell(200, 10, "Boletim do Aluno: " . utf8_decode($aluno['nome']), 0, 1, 'C');
    $pdf->Ln(10); // Espaço extra

    // Definir a largura das colunas para a tabela
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(60, 10, 'Disciplina', 1, 0, 'C');
    $pdf->Cell(30, 10, 'Nota', 1, 0, 'C');
    $pdf->Cell(60, 10, utf8_decode('Observação'), 1, 0, 'C');

    $pdf->Cell(30, 10, 'Faltas', 1, 1, 'C');
    
    // Listar as disciplinas e suas notas
    foreach ($aluno['disciplinas'] as $disciplina) {
        $pdf->SetFont('Arial', '', 12);
        
        // Nome da disciplina
        $pdf->Cell(60, 10, utf8_decode($disciplina['disciplina']), 1, 0, 'L');
        
        // Exibir notas com base no tipo de nota selecionado
        if ($tipo_nota == 'nota_parcial_1') {
            $pdf->Cell(30, 10, utf8_decode($disciplina['nota_parcial_1']), 1, 0, 'C');
            $pdf->Cell(60, 10, utf8_decode($disciplina['obs_parcial_1']), 1, 0, 'L');
        } elseif ($tipo_nota == 'semestre_1') {
            $pdf->Cell(30, 10, utf8_decode($disciplina['semestre_1']), 1, 0, 'C');
            $pdf->Cell(60, 10, utf8_decode($disciplina['obs_1_semestre']), 1, 0, 'L');
        } elseif ($tipo_nota == 'nota_parcial_2') {
            $pdf->Cell(30, 10, utf8_decode($disciplina['nota_parcial_2']), 1, 0, 'C');
            $pdf->Cell(60, 10, utf8_decode($disciplina['obs_parcial_2']), 1, 0, 'L');
        } elseif ($tipo_nota == 'semestre_2') {
            $pdf->Cell(30, 10, utf8_decode($disciplina['semestre_2']), 1, 0, 'C');
            $pdf->Cell(60, 10, utf8_decode($disciplina['obs_2_semestre']), 1, 0, 'L');
        }
        
        // Exibir o número de faltas
        $pdf->Cell(30, 10, utf8_decode($disciplina['numero_faltas']), 1, 1, 'C');
    }

    $pdf->Ln(10); // Espaço extra antes da próxima página
}

// Gerar o PDF
$pdf->Output('I', 'Boletins.pdf');
?>
