<?php
// Incluir a biblioteca FPDF
require('fpdf/fpdf.php');

// Iniciar a sessão
session_start();

// Incluir a conexão com o banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Obter o id da turma e os tipos de notas selecionados
$id_turma = isset($_GET['id_turma']) ? intval($_GET['id_turma']) : 0;
$tipos_nota = isset($_GET['tipo_nota']) ? $_GET['tipo_nota'] : [];

// Verificar se o id da turma é válido
if ($id_turma <= 0) {
    die("ID da turma inválido.");
}

// Obter os alunos dessa turma e suas disciplinas, além das notas
$queryAlunos = "
    SELECT a.id AS aluno_id, a.nome AS aluno_nome, d.nome AS disciplina, 
           n.nota_parcial_1, n.semestre_1, n.nota_parcial_2, n.semestre_2, 
           n.numero_faltas, n.obs_parcial_1, n.obs_1_semestre, n.obs_parcial_2, n.obs_2_semestre,
           n.ais, n.aia, n.amostra
    FROM alunos a
    LEFT JOIN notas n ON a.id = n.aluno_id
    LEFT JOIN disciplinas d ON n.disciplina_id = d.id
    WHERE a.turma_id = ?
";

// Preparar a consulta
$stmt = $conn->prepare($queryAlunos);
if (!$stmt) {
    die("Erro ao preparar a consulta: " . $conn->error);
}
$stmt->bind_param('i', $id_turma);
$stmt->execute();
$resultAlunos = $stmt->get_result();

// Obter o nome da turma
$queryTurma = "SELECT nome FROM turmas WHERE id = ?";
$stmt = $conn->prepare($queryTurma);
if (!$stmt) {
    die("Erro ao preparar a consulta: " . $conn->error);
}
$stmt->bind_param('i', $id_turma);
$stmt->execute();
$stmt->bind_result($nome_turma);
$stmt->fetch();

// Verificar se há alunos
if ($resultAlunos->num_rows > 0) {
    // Agrupar as notas por aluno
    $alunos = [];
    while ($aluno = $resultAlunos->fetch_assoc()) {
        $alunos[$aluno['aluno_id']]['nome'] = $aluno['aluno_nome'];
        $alunos[$aluno['aluno_id']]['disciplinas'][] = [
            'disciplina'      => $aluno['disciplina'],
            'nota_parcial_1'  => $aluno['nota_parcial_1'],
            'semestre_1'      => $aluno['semestre_1'],
            'nota_parcial_2'  => $aluno['nota_parcial_2'],
            'semestre_2'      => $aluno['semestre_2'],
            'numero_faltas'   => $aluno['numero_faltas'],
            'obs_parcial_1'   => $aluno['obs_parcial_1'] ?? '',  // Verificando se a chave existe
            'obs_1_semestre'  => $aluno['obs_1_semestre'],
            'obs_parcial_2'   => $aluno['obs_parcial_2'],
            'obs_2_semestre'  => $aluno['obs_2_semestre'],
            'ais'             => $aluno['ais'],
            'aia'             => $aluno['aia'],
            'amostra'         => $aluno['amostra']
        ];
    }
} else {
    die("Nenhum aluno encontrado para esta turma.");
}

// Fechar a conexão
$stmt->close();
$conn->close();

// Criar o PDF
$pdf = new FPDF();
$pdf->SetFont('Arial', 'B', 12); // Alterado para tamanho 12

// Configurar o PDF para UTF-8 (necessário para suportar acentuação)
$pdf->SetAutoPageBreak(true, 10); // Definir margem de 10 para quebra de página

// Gerar boletim para cada aluno
foreach ($alunos as $aluno) {
    // Adicionar uma nova página para cada aluno
    $pdf->AddPage();
    
    // Título do boletim
    $pdf->Cell(200, 10, "Boletim da Turma: " . utf8_decode($nome_turma), 0, 1, 'C');
    $pdf->Ln(10); // Espaço extra
    
    $pdf->SetFont('Arial', 'B', 12);
    $pdf->Cell(200, 10, "Aluno: " . utf8_decode($aluno['nome']), 0, 1, 'L');
    
    $pdf->SetFont('Arial', '', 12); // Alterado para tamanho 12
    
    // Cabeçalho da tabela
    $pdf->Cell(40, 10, "Disciplina", 1, 0, 'C');
    
    // Cabeçalhos dependendo das notas selecionadas
    if (in_array('nota_parcial_1', $tipos_nota)) {
        $pdf->Cell(30, 10, "Nota Parcial 1", 1, 0, 'C');
    }
    if (in_array('semestre_1', $tipos_nota)) {
        $pdf->Cell(30, 10, "Semestre 1", 1, 0, 'C');
    }
    if (in_array('nota_parcial_2', $tipos_nota)) {
        $pdf->Cell(30, 10, "Nota Parcial 2", 1, 0, 'C');
    }
    if (in_array('semestre_2', $tipos_nota)) {
        $pdf->Cell(30, 10, "Semestre 2", 1, 0, 'C');
    }
    
    $pdf->Cell(20, 10, "Faltas", 1, 1, 'C'); // Coluna Faltas
    
    // Detalhes das disciplinas do aluno
    foreach ($aluno['disciplinas'] as $disciplina) {
        $pdf->Cell(40, 10, utf8_decode($disciplina['disciplina']), 1, 0, 'L');
        
        if (in_array('nota_parcial_1', $tipos_nota)) {
            $pdf->Cell(30, 10, $disciplina['nota_parcial_1'], 1, 0, 'C');
        }
        if (in_array('semestre_1', $tipos_nota)) {
            $pdf->Cell(30, 10, $disciplina['semestre_1'], 1, 0, 'C');
        }
        if (in_array('nota_parcial_2', $tipos_nota)) {
            $pdf->Cell(30, 10, $disciplina['nota_parcial_2'], 1, 0, 'C');
        }
        if (in_array('semestre_2', $tipos_nota)) {
            $pdf->Cell(30, 10, $disciplina['semestre_2'], 1, 0, 'C');
        }

        $pdf->Cell(20, 10, $disciplina['numero_faltas'], 1, 1, 'C');
    }
    
    // Adicionar observações
    if (!empty($aluno['obs_parcial_1'])) {
        $pdf->Ln(5); 
        $pdf->SetFont('Arial', 'I', 12); // Alterado para tamanho 12
        $pdf->Cell(200, 10, "Observação Parcial 1: " . utf8_decode($aluno['obs_parcial_1']), 0, 1, 'L');
    }
    if (!empty($aluno['obs_parcial_2'])) {
        $pdf->Ln(5); 
        $pdf->SetFont('Arial', 'I', 12); // Alterado para tamanho 12
        $pdf->Cell(200, 10, "Observação Parcial 2: " . utf8_decode($aluno['obs_parcial_2']), 0, 1, 'L');
    }
    if (!empty($aluno['obs_1_semestre'])) {
        $pdf->Ln(5); 
        $pdf->SetFont('Arial', 'I', 12); // Alterado para tamanho 12
        $pdf->Cell(200, 10, "Observação Semestre 1: " . utf8_decode($aluno['obs_1_semestre']), 0, 1, 'L');
    }
    if (!empty($aluno['obs_2_semestre'])) {
        $pdf->Ln(5); 
        $pdf->SetFont('Arial', 'I', 12); // Alterado para tamanho 12
        $pdf->Cell(200, 10, "Observação Semestre 2: " . utf8_decode($aluno['obs_2_semestre']), 0, 1, 'L');
    }
    
    $pdf->Ln(10); // Espaço extra após as observações
}

// Gerar o PDF
$pdf->Output();
?>
