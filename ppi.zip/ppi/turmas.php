<?php
// Iniciar a sessão
session_start();

// Incluir a conexão com o banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Obter todas as turmas
$queryTurmas = "SELECT * FROM turmas";
$resultTurmas = $conn->query($queryTurmas);

// Fechar a conexão
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Turmas</title>
    <style>
        /* Estilos gerais */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }

        /* Estilos da barra lateral */
        .sidebar {
            width: 210px;
            background-color: #28a745;
            color: white;
            padding: 20px;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            overflow-y: auto;
            flex-shrink: 0;
        }

        .sidebar h1 {
            margin-bottom: 20px;
            text-align: center;
        }

        .btn-back {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            text-align: center;
            margin-bottom: 20px;
        }

        .btn-back:hover {
            background-color: #45a049;
        }

        /* Estilos da lista de turmas */
        .turmas-lista {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 20px;
            margin-left: 280px; /* Espaço para a barra lateral */
        }

        /* Estilos individuais para cada turma */
        .turma {
            width: 200px;
            padding: 20px;
            text-align: center;
            border: 1px solid #ddd;
            border-radius: 8px;
            cursor: pointer;
            background-color: #ffffff;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .turma img {
            width: 100%;
            height: auto;
            border-radius: 8px;
            margin-bottom: 10px;
        }

        .turma h3 {
            font-size: 1.1rem;
            color: #333;
            margin: 0;
        }

        .turma:hover {
            background-color: #e9f7e9;
            transform: translateY(-5px);
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

    </style>
</head>
<body>

    <!-- Barra Lateral -->
    <div class="sidebar">
        <h1>Turmas</h1>
        <!-- Botão de Voltar -->
        <a href="admin.php" class="btn-back">Voltar</a>
    </div>

    <!-- Exibição das turmas -->
    <div class="turmas-lista">
        <?php while ($turma = $resultTurmas->fetch_assoc()): ?>
            <div class="turma" onclick="window.location.href='turma.php?id=<?php echo $turma['id']; ?>'">
                <!-- Logo ou imagem da turma -->
                <img src="logo_turma.jpg" alt="Logo da Turma">
                <h3><?php echo htmlspecialchars($turma['nome']); ?></h3>
            </div>
        <?php endwhile; ?>
    </div>

</body>
</html>
