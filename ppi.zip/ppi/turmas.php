<?php
// Iniciar a sessão
session_start();

// Incluir a conexão com o banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Obter todas as turmas
$queryTurmas = "SELECT * FROM turmas";
$resultTurmas = $conn->query($queryTurmas);

// Fechar a conexão
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Sisgna</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">
    <style>
        /* Estilos das turmas */
        .turmas-lista {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            justify-content: center;
            padding: 20px;
            margin-top: 30px;
        }

        .turma {
            background-color: #4CAF50;
            color: white;
            padding: 15px 30px;
            text-align: center;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 200px;
            font-size: 1.1rem;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            transition: all 0.3s ease;
        }

        .turma img {
            width: 100%;
            height: auto;
            margin-bottom: 10px;
            border-radius: 5px;
        }

        .turma:hover {
            background-color: #45a049;
            transform: translateY(-5px);
            box-shadow: 0 6px 12px rgba(0, 0, 0, 0.2);
        }

        .turma h3 {
            margin: 0;
        }

    </style>
</head>
<body>
<div class="sidebar">
    <a href="admin.php" class="btn-home">
        <i class="fas fa-home"></i>
    </a>
    <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>

    <div id="dropdownMenu" class="dropdown-content" style="display: none;">
        <button onclick="showForm('aluno')">Cadastrar Aluno</button>
        <button onclick="showForm('turma')">Cadastrar Turma</button>
        <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
        <button onclick="showForm('professor')">Cadastrar Professor</button>
        <button onclick="showForm('setor')">Cadastrar Setor</button>
        <button onclick="showForm('curso')">Cadastrar Curso</button>
        <button onclick="showForm('add_admin')">Cadastrar Admin</button>
    </div>
    <button onclick="location.href='turmas.php'">Turmas</button>
    <button onclick="location.href='listar.php'">Listar</button>
    <button onclick="location.href='notificar.php'">Notificar</button>
    <button onclick="location.href='selecionar_turma.php'">Slides</button>
    <button onclick="location.href='gerar_boletim.php'">Boletim</button>
    <button onclick="location.href='setoradmin.php'">Setor</button>
</div>

<div class="main-content">
    <div class="header">
        <img src="iffarpng.png" alt="Logo da Empresa" class="logo">
        <h1>Bem-vindo ao Painel de Administração</h1>
        <form method="POST" action="logout.php" style="margin: 0;">
            <button type="submit" name="logout" class="logout-button">Sair</button>
        </form>
    </div>

    <h2></h2>
    <div class="turmas-lista">
        <?php while ($turma = $resultTurmas->fetch_assoc()): ?>
            <div class="turma" onclick="window.location.href='turma.php?id=<?php echo $turma['id']; ?>'">
                <!-- Logo ou imagem da turma -->
                <img src="logo_turma.jpg" alt="Logo da Turma">
                <h3><?php echo htmlspecialchars($turma['nome']); ?></h3>
            </div>
        <?php endwhile; ?>
    </div>

</div>

<!-- Importação dos scripts do Bootstrap -->
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>
