<?php
session_start();

// Conexão com o banco de dados
$host = 'localhost';
$user = 'root'; 
$pass = ''; 
$db   = 'sisgna'; 

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'admin') {
    // Se não estiver autenticado ou não for do tipo setor, redirecionar para a página de login
    header('Location: login.php');
    exit();
}

// Função para listar os alunos e suas informações de setor
$sql = "SELECT a.id, a.nome, a.email, a.matricula, a.foto, 
        i.alergia, i.ja_reprovou, i.interno, i.orientador_amostra_ciencias
        FROM alunos a
        LEFT JOIN informacoes_adicionais i ON a.id = i.aluno_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Alunos - Setor</title>
    <!-- Link do Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Link para o seu arquivo CSS -->
    <link rel="stylesheet" href="css/styles.css"> <!-- Arquivo de estilo externo -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<body>

    <!-- Barra Lateral -->
    <div class="sidebar">
        <a href="admin.php" class="btn-home">
            <i class="fas fa-home"></i>
        </a>
        <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>
        <div id="dropdownMenu" class="dropdown-content" style="display: none;">
            <button onclick="showForm('aluno')">Cadastrar Aluno</button>
            <button onclick="showForm('turma')">Cadastrar Turma</button>
            <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
            <button onclick="showForm('professor')">Cadastrar Professor</button>
            <button onclick="showForm('setor')">Cadastrar Setor</button>
            <button onclick="showForm('curso')">Cadastrar Curso</button>
            <button onclick="showForm('add_admin')">Cadastrar Admin</button>
        </div>
        <button onclick="location.href='turmas.php'">Turmas</button>
        <button onclick="location.href='listar.php'">Listar</button>
        <button onclick="location.href='notificar.php'">Notificar</button>
        <button onclick="location.href='slides.php'">Slides</button>
        <button onclick="location.href='setoradmin.php'">Setor</button>
    </div>

    <!-- Conteúdo Principal -->
    <div class="main-content">
        <h1>Lista de Alunos e Informações de Setor</h1>

        <!-- Barra de Pesquisa -->
        <?php if (isset($_GET['lista'])): ?>
            <div class="mb-3">
                <input type="text" id="searchInput" class="form-control" placeholder="Pesquisar..." onkeyup="searchTable()">
            </div>
        <?php endif; ?>

        <!-- Mensagem de Sucesso ou Erro -->
        <?php
        if (isset($_SESSION['mensagem_sucesso'])) {
            echo "<p class='mensagem-sucesso'>" . $_SESSION['mensagem_sucesso'] . "</p>";
            unset($_SESSION['mensagem_sucesso']);
        }
        if (isset($_SESSION['mensagem_erro'])) {
            echo "<p class='mensagem-erro'>" . $_SESSION['mensagem_erro'] . "</p>";
            unset($_SESSION['mensagem_erro']);
        }
        ?>

        <!-- Tabela de Alunos -->
        <div class="card">
            <div class="card-header">
                <h4>Lista de Alunos e Informações de Setor</h4>
            </div>
            <div class="card-body">
                <table class="table table-striped table-bordered" id="alunosTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Email</th>
                            <th>Matricula</th>
                            <th>Foto</th>
                            <th>Alergia</th>
                            <th>Já Reprovou?</th>
                            <th>Interno?</th>
                            <th>Orientador Amostra Ciências</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = $result->fetch_assoc()) { ?>
                            <tr>
                                <td><?php echo $row['id']; ?></td>
                                <td><?php echo $row['nome']; ?></td>
                                <td><?php echo $row['email']; ?></td>
                                <td><?php echo $row['matricula']; ?></td>
                                <td>
                                    <?php if ($row['foto']) { ?>
                                        <img src="uploads/<?php echo $row['foto']; ?>" class="foto-aluno" alt="Foto do Aluno">
                                    <?php } else { ?>
                                        <img src="uploads/default-avatar.jpg" class="foto-aluno" alt="Foto Padrão">
                                    <?php } ?>
                                </td>
                                <td><?php echo $row['alergia'] ? $row['alergia'] : 'Não informado'; ?></td>
                                <td><?php echo $row['ja_reprovou'] ? $row['ja_reprovou'] : 'Não informado'; ?></td>
                                <td><?php echo $row['interno'] ? $row['interno'] : 'Não informado'; ?></td>
                                <td><?php echo $row['orientador_amostra_ciencias'] ? $row['orientador_amostra_ciencias'] : 'Não informado'; ?></td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Link do Bootstrap JS e dependências -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>

    <!-- Script de busca -->
    <script>
        function searchTable() {
            var input = document.getElementById("searchInput");
            var filter = input.value.toLowerCase();
            var table = document.getElementById("alunosTable");
            var tr = table.getElementsByTagName("tr");

            // Loop por todas as linhas da tabela
            for (var i = 1; i < tr.length; i++) {  // começa em 1 para ignorar o cabeçalho
                var td = tr[i].getElementsByTagName("td");
                var found = false;

                // Loop por todas as colunas de cada linha
                for (var j = 0; j < td.length; j++) {
                    if (td[j]) {
                        var txtValue = td[j].textContent || td[j].innerText;
                        if (txtValue.toLowerCase().indexOf(filter) > -1) {
                            found = true;
                            break;
                        }
                    }
                }

                // Mostrar ou esconder a linha dependendo se o texto foi encontrado
                if (found) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    </script>

</body>
</html>

<?php
$conn->close();
?>
