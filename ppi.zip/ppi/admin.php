<?php
session_start();

// Verificar se o usuário está autenticado e se o papel é 'admin'
if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'admin') {
    header('Location: login.php');
    exit();
}

// Configurações do banco de dados
$host = 'localhost';
$db = 'sisgna';
$user = 'root';
$pass = '';

// Conectar ao banco de dados
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Erro ao conectar ao banco de dados: " . $e->getMessage());
}

// Atualiza o papel do usuário para 'admin'
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_admin'])) {
    $userId = filter_input(INPUT_POST, 'user_id', FILTER_SANITIZE_NUMBER_INT);
    
    // Atualiza o papel do usuário para 'admin'
    $stmt = $pdo->prepare("UPDATE usuarios SET tipo = 'admin' WHERE id = ?");
    $stmt->execute([$userId]);
    
    $_SESSION['success'] = "Usuário atualizado para admin com sucesso.";
    header('Location: admin.php');
    exit();
}

// Obter todos os usuários
$stmt = $pdo->query("SELECT id, username, email, tipo AS role FROM usuarios");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Verificar se há uma mensagem de sucesso ou erro
$successMsg = isset($_SESSION['success']) ? $_SESSION['success'] : '';
$errorMsg = isset($_SESSION['error']) ? $_SESSION['error'] : '';

// Limpar a mensagem da sessão após exibir
unset($_SESSION['success']);
unset($_SESSION['error']);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Sisgna</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">

</head>
<body>

<?php if ($successMsg): ?>
        <div id="message" class="message show">
            <?php echo htmlspecialchars($successMsg); ?>
        </div>
    <?php endif; ?>
    
    <?php if ($errorMsg): ?>
        <div id="message" class="message error show">
            <?php echo htmlspecialchars($errorMsg); ?>
        </div>
    <?php endif; ?>
    
    
    
    


    
    <div class="sidebar">
        <a href="admin.php" class="btn-home">
        <i class="fas fa-home"></i>
        </a>
        <button id="toggleButton">Cadastrar</button>
        <div id="dropdownMenu" class="dropdown-content" style="display: none;">
            <button onclick="showForm('aluno')">Cadastrar Aluno</button>
            <button onclick="showForm('turma')">Cadastrar Turma</button>
            <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
            <button onclick="showForm('professor')">Cadastrar Professor</button>
            <button onclick="showForm('setor')">Cadastrar Setor</button>
            <button onclick="showForm('curso')">Cadastrar Curso</button>
            <button onclick="showForm('add_admin')">Cadastrar Admin</button>
        </div>
        <button onclick="location.href='turmas.php'">Turmas</button>
        <button onclick="location.href='listar.php'">Listar</button>
        <button onclick="location.href='notificar.php'">Notificar</button>
        <button onclick="location.href='slides.php'">Slides</button>
    </div>
    
    
    <div class="main-content">
        <div class="header">
            <img src="iffarpng.png" alt="Logo da Empresa" class="logo">
            <h1>Bem-vindo ao Painel de Administração</h1>
            <form method="POST" action="logout.php" style="margin: 0;">
                <button type="submit" name="logout" class="logout-button">Sair</button>
            </form>
        </div>
        
        <div id="formContainer" class="form-container">
            <!-- Formulários serão carregados aqui via JavaScript -->
        </div>
    
    
    

    <script>
        // Toggle the display of the dropdown menu
        document.getElementById('toggleButton').addEventListener('click', function() {
            const dropdownMenu = document.getElementById('dropdownMenu');
            dropdownMenu.style.display = dropdownMenu.style.display === 'none' || dropdownMenu.style.display === '' ? 'block' : 'none';
        });

        // Show the appropriate form
        function showForm(formType) {
            const formContainer = document.getElementById('formContainer');
            let formHtml = '';
            let actionUrl = '';

            switch (formType) {
                case 'aluno':
                    actionUrl = 'processa_cadastro_aluno.php';
                    formHtml = `
                        <div class="form-container active">
                            <h2>Cadastrar Aluno</h2>
                            <form method="POST" action="${actionUrl}" enctype="multipart/form-data">
                                <input type="hidden" name="form_type" value="aluno">
                                <label>Nome:</label>
                                <input type="text" name="nome" required><br>
                                <label>Email:</label>
                                <input type="email" name="email" required><br>
                                <label>CPF:</label>
                                <input type="text" name="cpf" maxlength="11" required><br>
                                <label>Matrícula:</label>
                                <input type="text" name="matricula" required><br>
                                <label>Turma:</label>
                                <select name="turma_id" id="turmaDropdown" required>
                                    <!-- Turmas serão carregadas aqui -->
                                </select><br>
                                <label>Foto:</label>
                                <input type="file" name="foto" accept="image/*" required><br>
                                <br>
                                <button type="submit" class="btn btn-success">Cadastrar Aluno</button>
                            </form>
                        </div>
                    `;
                    formContainer.innerHTML = formHtml; // Atualiza o formulário no container
                    loadTurmas(); // Carregar turmas
                    break;

                case 'turma':
                    actionUrl = 'processa_cadastro_turma.php';
                    formHtml = `
                        <div class="form-container active">
                            <h2>Cadastrar Turma</h2>
                            <form method="POST" action="${actionUrl}">
                                <input type="hidden" name="form_type" value="turma">
                                <label>Nome:</label>
                                <input type="text" name="nome" required><br>
                                <label>Curso:</label>
                                <select name="curso_id" id="cursoDropdown" required>
                                    <!-- Cursos serão carregados aqui -->
                                </select>
                                <br>
                                <br>
                                <button type="submit" class="btn btn-success">Cadastrar Turma</button>
                            </form>
                        </div>
                    `;
                    formContainer.innerHTML = formHtml; // Atualiza o formulário no container
                    loadCursos(); // Carregar cursos
                    break;

                case 'disciplina':
                    actionUrl = 'processa_cadastro_disciplina.php';
                    formHtml = `
                        <div class="form-container active">
                            <h2>Cadastrar Disciplina</h2>
                            <form method="POST" action="${actionUrl}">
                                <input type="hidden" name="form_type" value="disciplina">
                                <label>Nome:</label>
                                <input type="text" name="nome" required><br>
                                <label>Turma:</label>
                                <select name="turma_id" id="turmaDropdownDisciplina" required>
                                    <!-- Turmas serão carregadas aqui -->
                                </select>
                                <br> <br>
                                <button type="submit" class="btn btn-success">Cadastrar Disciplina</button>
                            </form>
                        </div>
                    `;
                    formContainer.innerHTML = formHtml; // Atualiza o formulário no container
                    loadTurmasForDisciplina(); // Carregar turmas para disciplinas
                    break;

                case 'professor':
                        actionUrl = 'processa_cadastro_professor.php';
                        formHtml = `
                            <div class="form-container active">
                                <h2>Cadastrar Professor</h2>
                                <form id="professorForm" method="POST" action="${actionUrl}" enctype="multipart/form-data">
                                    <input type="hidden" name="form_type" value="professor">
                                    <label>Nome:</label>
                                    <input type="text" name="nome" required><br>
                                    <label>Email:</label>
                                    <input type="email" name="email" required><br>
                                    <label>CPF:</label>
                                    <input type="text" name="cpf" maxlength="11" required><br>
                                    
                                    <label>Senha:</label>
                                    <input type="password" name="senha" required><br>
                                    <label>Foto:</label>
                                    <input type="file" id="foto" name="foto"><br>
                                    <label for="turmas">Selecionar Turmas:</label>
                                    <div id="turmasContainer">
                                        <!-- Turmas serão carregadas aqui -->
                                    </div><br>
                                    <button type="submit" class="btn btn-success">Cadastrar Professor</button>
                                </form>
                            </div>
                        `;
                        formContainer.innerHTML = formHtml; // Atualiza o formulário no container
                        loadTurmasForProfessor(); // Carregar turmas para professores
                        break;

                case 'setor':
                    actionUrl = 'processa_cadastro_setor.php';
                    formHtml = `
                        <div class="form-container active">
                            <h2>Cadastrar Setor</h2>
                            <form method="POST" action="${actionUrl}" enctype="multipart/form-data">
                                <input type="hidden" name="form_type" value="setor">
                                <label>Nome:</label>
                                <input type="text" name="nome" required><br>
                                <label>Email:</label>
                                <input type="email" name="email" required><br>
                                <label for="tipo">Tipo de Setor:</label>
                                <select id="tipo" name="tipo" required>
                                    <option value="">Selecione o tipo de setor</option>
                                    <option value="SETOR 1">SETOR 1</option>
                                    <option value="SETOR 2">SETOR 2</option>
                                    <option value="SETOR 3">SETOR 3</option>
                                </select><br>
                                <label>Senha:</label>
                                <input type="password" name="senha" required><br>
                                <label>Foto:</label>
                                <input type="file" name="foto" accept="image/*"><br>
                                <br>
                                <button type="submit" class="btn btn-success">Cadastrar Setor</button>
                            </form>
                        </div>
                    `;
                    formContainer.innerHTML = formHtml; // Atualiza o formulário no container
                    break;

                case 'curso':
                    actionUrl = 'processa_cadastro_curso.php';
                    formHtml = `
                        <div class="form-container active">
                            <h2>Cadastrar Curso</h2>
                            <form method="POST" action="${actionUrl}">
                                <input type="hidden" name="form_type" value="curso">
                                <label>Nome:</label>
                                <input type="text" name="nome" required><br>
                                <label></label>
                                <button type="submit" class="btn btn-success">Cadastrar Curso</button>
                            </form>
                        </div>
                    `;
                    formContainer.innerHTML = formHtml; // Atualiza o formulário no container
                    break;

                case 'add_admin':
                    actionUrl = 'processa_cadastro_admin.php';
                    formHtml = `
                        <div class="form-container active">
                            <h2>Cadastrar Admin</h2>
                            <form method="POST" action="${actionUrl}" enctype="multipart/form-data">
                                <input type="hidden" name="form_type" value="admin">
                                <label>Nome:</label>
                                <input type="text" name="nome" required><br>
                                <label>Email:</label>
                                <input type="email" name="email" required><br>
                                <label>Senha:</label>
                                <input type="password" name="senha" required><br>
                                <label>Foto:</label>
                                <input type="file" name="foto" accept="image/*"><br>
                                <br>
                                <button type="submit" class="btn btn-success">Cadastrar Admin</button>
                            </form>
                        </div>
                    `;
                    formContainer.innerHTML = formHtml; // Atualiza o formulário no container
                    break;

                default:
                    formContainer.innerHTML = '<p>Formulário não encontrado.</p>';
            }
        }
        





        document.addEventListener('DOMContentLoaded', (event) => {
            const message = document.getElementById('message');
            if (message) {
                setTimeout(() => {
                    message.classList.remove('show');
                    message.classList.add('hide');
                }, 3000); // Desaparecer após 3 segundos
            }
        });
        // Função para carregar turmas
        function loadTurmas() {
            fetch('get_turmas.php')
                .then(response => response.json())
                .then(data => {
                    const turmaDropdown = document.getElementById('turmaDropdown');
                    data.forEach(turma => {
                        const option = document.createElement('option');
                        option.value = turma.id;
                        option.textContent = turma.nome;
                        turmaDropdown.appendChild(option);
                    });
                })
                .catch(error => console.error('Erro ao carregar turmas:', error));
        }

        // Função para carregar cursos
        function loadCursos() {
            fetch('get_cursos.php')
                .then(response => response.json())
                .then(data => {
                    const cursoDropdown = document.getElementById('cursoDropdown');
                    data.forEach(curso => {
                        const option = document.createElement('option');
                        option.value = curso.id;
                        option.textContent = curso.nome;
                        cursoDropdown.appendChild(option);
                    });
                })
                .catch(error => console.error('Erro ao carregar cursos:', error));
        }

        // Função para carregar turmas para disciplinas
        function loadTurmasForDisciplina() {
            fetch('get_turmas.php')
                .then(response => response.json())
                .then(data => {
                    const turmaDropdown = document.getElementById('turmaDropdownDisciplina');
                    data.forEach(turma => {
                        const option = document.createElement('option');
                        option.value = turma.id;
                        option.textContent = turma.nome;
                        turmaDropdown.appendChild(option);
                    });
                })
                .catch(error => console.error('Erro ao carregar turmas:', error));
        }

        // Função para carregar turmas para professores
        function loadTurmasForProfessor() {
        fetch('get_turmas.php')
            .then(response => response.json())
            .then(turmas => {
                const turmasContainer = document.getElementById('turmasContainer');
                turmasContainer.innerHTML = ''; // Limpa o conteúdo existente

                turmas.forEach(turma => {
                    const collapsible = document.createElement('button');
                    collapsible.type = 'button'; // Garantir que o botão não envie o formulário
                    collapsible.classList.add('collapsible');
                    collapsible.textContent = turma.nome;
                    collapsible.addEventListener('click', function() {
                        this.classList.toggle('active');
                        const content = this.nextElementSibling;
                        content.style.display = content.style.display === 'block' ? 'none' : 'block';
                    });

                    const content = document.createElement('div');
                    content.classList.add('content');

                    fetch(`get_disciplinas.php?turma_id=${turma.id}`)
                        .then(response => response.json())
                        .then(disciplinas => {
                            disciplinas.forEach(disciplina => {
                                const label = document.createElement('label');
                                const checkbox = document.createElement('input');
                                checkbox.type = 'checkbox';
                                checkbox.name = 'disciplinas[]';
                                checkbox.value = disciplina.id;
                                label.appendChild(checkbox);
                                label.appendChild(document.createTextNode(disciplina.nome));
                                content.appendChild(label);
                            });
                        })
                        .catch(error => console.error('Erro ao carregar disciplinas:', error));

                    turmasContainer.appendChild(collapsible);
                    turmasContainer.appendChild(content);
                });
            })
            .catch(error => console.error('Erro ao carregar turmas:', error));
    }
    


</script>
</body>
</html>

