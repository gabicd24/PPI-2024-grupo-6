<?php
// Conectar ao banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Verificar se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $aluno_id = $_POST['aluno_id'];

    // Iterar por todas as disciplinas e salvar as notas
    foreach ($_POST as $key => $value) {
        if (strpos($key, 'nota_') === 0) {
            $disciplina_id = str_replace('nota_', '', $key);
            $nota = floatval($value);

            // Inserir ou atualizar a nota na tabela de notas
            $query = "INSERT INTO notas (aluno_id, disciplina_id, nota) 
                      VALUES (?, ?, ?)
                      ON DUPLICATE KEY UPDATE nota = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("iiid", $aluno_id, $disciplina_id, $nota, $nota);
            $stmt->execute();
            $stmt->close();
        }
    }
}

// Fechar a conexão
$conn->close();

// Redirecionar de volta
header('Location: turma.php?id=' . $_GET['id']);
exit;
?>
