<?php
session_start();

// Conexão com o banco de dados
$host = 'localhost';
$user = 'root'; 
$pass = ''; 
$db   = 'sisgna'; 

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'setor') {
    // Se não estiver autenticado ou não for do tipo setor, redirecionar para a página de login
    header('Location: login.php');
    exit();
}

// Função para atualizar as informações do setor do aluno via POST
if (isset($_POST['update_setor'])) {
    if (isset($_POST['id'])) {
        foreach ($_POST['id'] as $index => $id) {
            $alergia = $_POST['alergia'][$id];
            $ja_reprovou = $_POST['ja_reprovou'][$id];
            $interno = $_POST['interno'][$id];
            $orientador_amostra_ciencias = $_POST['orientador_amostra_ciencias'][$id];
            $numero = $_POST['numero'][$id];

            $sql_check = "SELECT * FROM informacoes_adicionais WHERE aluno_id = ?";
            $stmt_check = $conn->prepare($sql_check);
            $stmt_check->bind_param("i", $id);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();

            if ($result_check->num_rows > 0) {
                $row_check = $result_check->fetch_assoc();
                if ($row_check['alergia'] !== $alergia || $row_check['ja_reprovou'] !== $ja_reprovou || $row_check['interno'] !== $interno || $row_check['orientador_amostra_ciencias'] !== $orientador_amostra_ciencias || $row_check['numero'] !== $numero) {
                    $sql_info = "UPDATE informacoes_adicionais 
                                 SET alergia = ?, ja_reprovou = ?, interno = ?, orientador_amostra_ciencias = ?, numero = ?
                                 WHERE aluno_id = ?";
                    $stmt_info = $conn->prepare($sql_info);
                    $stmt_info->bind_param("sssssi", $alergia, $ja_reprovou, $interno, $orientador_amostra_ciencias, $numero, $id);

                    if ($stmt_info->execute()) {
                        $_SESSION['mensagem_sucesso'] = "Informações do setor salvas com sucesso!";
                    } else {
                        $_SESSION['mensagem_erro'] = "Erro ao atualizar informações adicionais!";
                    }
                }
            } else {
                $sql_info = "INSERT INTO informacoes_adicionais (aluno_id, alergia, ja_reprovou, interno, orientador_amostra_ciencias, numero) 
                             VALUES (?, ?, ?, ?, ?, ?)";
                $stmt_info = $conn->prepare($sql_info);
                $stmt_info->bind_param("isssss", $id, $alergia, $ja_reprovou, $interno, $orientador_amostra_ciencias, $numero);

                if ($stmt_info->execute()) {
                    $_SESSION['mensagem_sucesso'] = "Informações do setor salvas com sucesso!";
                } else {
                    $_SESSION['mensagem_erro'] = "Erro ao inserir informações adicionais!";
                }
            }
        }
    } else {
        $_SESSION['mensagem_erro'] = "ID do aluno não encontrado!";
    }
}

$sql = "SELECT a.id, a.nome, a.email, a.matricula, a.foto, 
               t.nome AS turma_nome,
               i.alergia, i.ja_reprovou, i.interno, i.orientador_amostra_ciencias, i.numero
        FROM alunos a
        LEFT JOIN informacoes_adicionais i ON a.id = i.aluno_id
        LEFT JOIN turmas t ON a.turma_id = t.id
        ORDER BY t.nome ASC, a.nome ASC"; 
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Alunos - Setor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        #searchBar {
            margin-bottom: 20px;
        }
        .header {
            display: flex;
            align-items: center;
            padding: 20px;
            background-color: #ffffff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .logo {
            height: 120px;
            object-fit: cover;
            margin-right: 20px;
            flex-shrink: 0;
        }
        .header h1 {
            font-size: 28px;
            margin: 0;
        }
        .logout-button {
            background-color: #dc3545;
            color: white;
            border: none;
            padding: 10px 15px;
            cursor: pointer;
        }
        .logout-button:hover {
            background-color: #c82333;
        }
        .table-green thead {
            background-color: #28a745; /* Cor de fundo verde */
            color: white; /* Cor do texto branco */
        }
        .btn-green {
            background-color: #28a745;
            color: white;
            border: none;
        }
        .btn-green:hover {
            background-color: #218838;
        }
    </style>
</head>
<body class="bg-light">

    <!-- Header com logo e título -->
    <div class="header">
        <img src="iffarpng.png" alt="Logo da Empresa" class="logo">
        <h1>Bem-vindo ao Painel do Setor</h1>
        <form method="POST" action="logout.php" style="margin: 0; margin-left: auto;">
            <button type="submit" name="logout" class="logout-button">Sair</button>
        </form>
    </div>

    <div class="container mt-5">
        <h1 class="text-center mb-4">Lista de Alunos e Informações de Setor</h1>

        <!-- Barra de pesquisa -->
        <input type="text" id="searchBar" class="form-control" placeholder="Pesquisar alunos..." onkeyup="filterTable()">

        <?php if (isset($_SESSION['mensagem_sucesso'])) { ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['mensagem_sucesso']; unset($_SESSION['mensagem_sucesso']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php } ?>
        <?php if (isset($_SESSION['mensagem_erro'])) { ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['mensagem_erro']; unset($_SESSION['mensagem_erro']); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php } ?>

        <form method="POST">
            <table class="table table-bordered table-green" id="alunosTable">
                <thead class="table-green">
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Matrícula</th>
                        <th>Foto</th>
                        <th>Alergia</th>
                        <th>Já Reprovou?</th>
                        <th>Interno?</th>
                        <th>Orientador A.C.</th>
                        <th>Contato Familiar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $current_turma = ''; // Variável para controlar a turma atual
                    while ($row = $result->fetch_assoc()) { 
                        // Exibir o título da turma quando houver uma mudança
                        if ($current_turma != $row['turma_nome']) {
                            $current_turma = $row['turma_nome'];
                            echo "<tr><td colspan='10' class='table-secondary'><strong>Turma: " . $current_turma . "</strong></td></tr>";
                        }
                    ?>
                        <tr>
                            <td colspan="10" style="display: none;" class="turma-info"><?php echo $row['turma_nome']; ?></td>
                            <td><?php echo $row['id']; ?></td>
                            <td><?php echo $row['nome']; ?></td>
                            <td><?php echo $row['email']; ?></td>
                            <td><?php echo $row['matricula']; ?></td>
                            <td>
                                <?php if ($row['foto']) { ?>
                                    <img src="uploads/<?php echo $row['foto']; ?>" class="img-thumbnail" style="width: 50px; height: 50px;">
                                <?php } else { ?>
                                    N/A
                                <?php } ?>
                            </td>
                            <td><input type="text" class="form-control" name="alergia[<?php echo $row['id']; ?>]" value="<?php echo $row['alergia']; ?>"></td>
                            <td><input type="text" class="form-control" name="ja_reprovou[<?php echo $row['id']; ?>]" value="<?php echo $row['ja_reprovou']; ?>"></td>
                            <td><input type="text" class="form-control" name="interno[<?php echo $row['id']; ?>]" value="<?php echo $row['interno']; ?>"></td>
                            <td><input type="text" class="form-control" name="orientador_amostra_ciencias[<?php echo $row['id']; ?>]" value="<?php echo $row['orientador_amostra_ciencias']; ?>"></td>
                            <td><input type="text" class="form-control" name="numero[<?php echo $row['id']; ?>]" value="<?php echo $row['numero']; ?>"></td>
                            <input type="hidden" name="id[<?php echo $row['id']; ?>]" value="<?php echo $row['id']; ?>">
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
            <button type="submit" name="update_setor" class="btn btn-green btn-block">Salvar Informações</button>
        </form>
    </div>

    <script>
        // Função de filtragem da tabela
        function filterTable() {
            let input = document.getElementById('searchBar');  // Campo de pesquisa
            let filter = input.value.toUpperCase();  // Valor digitado
            let table = document.getElementById('alunosTable');  // A tabela
            let rows = table.getElementsByTagName('tr');  // Todas as linhas da tabela

            // Itera pelas linhas da tabela e esconde as que não correspondem à pesquisa
            for (let i = 1; i < rows.length; i++) {  // Ignora a primeira linha (cabeçalho)
                let cells = rows[i].getElementsByTagName('td');  // Células da linha
                let found = false;

                // Verifica se alguma célula da linha contém o valor da pesquisa
                for (let j = 0; j < cells.length; j++) {
                    let cell = cells[j];
                    if (cell) {
                        // Se encontrar o nome da turma no campo oculto
                        if (cell.classList.contains("turma-info") && cell.innerText.toUpperCase().indexOf(filter) > -1) {
                            found = true;
                        }
                        // Verifica se a célula contém o valor da pesquisa
                        if (cell.innerText.toUpperCase().indexOf(filter) > -1) {
                            found = true;
                            break;  // Se encontrar, não precisa verificar as outras células
                        }
                    }
                }

                // Exibe ou esconde a linha com base no filtro
                if (found) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
