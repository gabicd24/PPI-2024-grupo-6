<?php
session_start();

// Conexão com o banco de dados
$host = 'localhost';
$user = 'root'; 
$pass = ''; 
$db   = 'sisgna'; 

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'setor') {
    // Se não estiver autenticado ou não for do tipo setor, redirecionar para a página de login
    header('Location: login.php');
    exit();
}

// Função para atualizar as informações do setor do aluno via POST
if (isset($_POST['update_setor'])) {
    if (isset($_POST['id'])) {
        foreach ($_POST['id'] as $index => $id) {
            $alergia = $_POST['alergia'][$id];
            $ja_reprovou = $_POST['ja_reprovou'][$id];
            $interno = $_POST['interno'][$id];
            $orientador_amostra_ciencias = $_POST['orientador_amostra_ciencias'][$id];
            $numero = $_POST['numero'][$id];

            $sql_check = "SELECT * FROM informacoes_adicionais WHERE aluno_id = ?";
            $stmt_check = $conn->prepare($sql_check);
            $stmt_check->bind_param("i", $id);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();

            if ($result_check->num_rows > 0) {
                $row_check = $result_check->fetch_assoc();
                if ($row_check['alergia'] !== $alergia || $row_check['ja_reprovou'] !== $ja_reprovou || $row_check['interno'] !== $interno || $row_check['orientador_amostra_ciencias'] !== $orientador_amostra_ciencias || $row_check['numero'] !== $numero) {
                    $sql_info = "UPDATE informacoes_adicionais 
                                 SET alergia = ?, ja_reprovou = ?, interno = ?, orientador_amostra_ciencias = ?, numero = ?
                                 WHERE aluno_id = ?";
                    $stmt_info = $conn->prepare($sql_info);
                    $stmt_info->bind_param("sssssi", $alergia, $ja_reprovou, $interno, $orientador_amostra_ciencias, $numero, $id);

                    if ($stmt_info->execute()) {
                        $_SESSION['mensagem_sucesso'] = "Informações do setor salvas com sucesso!";
                    } else {
                        $_SESSION['mensagem_erro'] = "Erro ao atualizar informações adicionais!";
                    }
                }
            } else {
                $sql_info = "INSERT INTO informacoes_adicionais (aluno_id, alergia, ja_reprovou, interno, orientador_amostra_ciencias, numero) 
                             VALUES (?, ?, ?, ?, ?, ?)";
                $stmt_info = $conn->prepare($sql_info);
                $stmt_info->bind_param("isssss", $id, $alergia, $ja_reprovou, $interno, $orientador_amostra_ciencias, $numero);

                if ($stmt_info->execute()) {
                    $_SESSION['mensagem_sucesso'] = "Informações do setor salvas com sucesso!";
                } else {
                    $_SESSION['mensagem_erro'] = "Erro ao inserir informações adicionais!";
                }
            }
        }
    } else {
        $_SESSION['mensagem_erro'] = "ID do aluno não encontrado!";
    }
}

$sql = "SELECT a.id, a.nome, a.email, a.matricula, a.foto, 
        i.alergia, i.ja_reprovou, i.interno, i.orientador_amostra_ciencias, i.numero
        FROM alunos a
        LEFT JOIN informacoes_adicionais i ON a.id = i.aluno_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Alunos - Setor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5">
    <h1 class="text-center mb-4">Lista de Alunos e Informações de Setor</h1>

    <?php if (isset($_SESSION['mensagem_sucesso'])) { ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['mensagem_sucesso']; unset($_SESSION['mensagem_sucesso']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php } ?>
    <?php if (isset($_SESSION['mensagem_erro'])) { ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <?php echo $_SESSION['mensagem_erro']; unset($_SESSION['mensagem_erro']); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    <?php } ?>

    <form method="POST">
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Matrícula</th>
                    <th>Foto</th>
                    <th>Alergia</th>
                    <th>Já Reprovou?</th>
                    <th>Interno?</th>
                    <th>Orientador Amostra Ciências</th>
                    <th>Contato Familiar</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><?php echo $row['nome']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['matricula']; ?></td>
                        <td>
                            <?php if ($row['foto']) { ?>
                                <img src="uploads/<?php echo $row['foto']; ?>" class="img-thumbnail" style="width: 50px; height: 50px;">
                            <?php } else { ?>
                                N/A
                            <?php } ?>
                        </td>
                        <td><input type="text" class="form-control" name="alergia[<?php echo $row['id']; ?>]" value="<?php echo $row['alergia']; ?>"></td>
                        <td><input type="text" class="form-control" name="ja_reprovou[<?php echo $row['id']; ?>]" value="<?php echo $row['ja_reprovou']; ?>"></td>
                        <td><input type="text" class="form-control" name="interno[<?php echo $row['id']; ?>]" value="<?php echo $row['interno']; ?>"></td>
                        <td><input type="text" class="form-control" name="orientador_amostra_ciencias[<?php echo $row['id']; ?>]" value="<?php echo $row['orientador_amostra_ciencias']; ?>"></td>
                        <td><input type="text" class="form-control" name="numero[<?php echo $row['id']; ?>]" value="<?php echo $row['numero']; ?>"></td>
                        <input type="hidden" name="id[<?php echo $row['id']; ?>]" value="<?php echo $row['id']; ?>">
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <button type="submit" name="update_setor" class="
        btn btn-primary">Salvar Alterações</button>
    </form>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
