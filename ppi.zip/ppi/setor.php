<?php
// Inicia a sessão
session_start();

// Verificar se o usuário está autenticado e se o papel é 'setor'
if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'setor') {
    // Se não estiver autenticado ou não for do tipo setor, redirecionar para a página de login
    header('Location: login.php');
    exit();
}

// Configurações do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// O restante do código da página setor.php vai aqui
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Página do Setor</title>
    <!-- Inclua seus estilos e scripts aqui -->
</head>
<body>
    <h1>Bem-vindo à Página do Setor</h1>
    <!-- O conteúdo da página vai aqui -->
</body>
</html>


