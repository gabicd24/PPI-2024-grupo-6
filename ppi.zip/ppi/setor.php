<?php
session_start();

// Conexão com o banco de dados
$host = 'localhost';
$user = 'root'; 
$pass = ''; 
$db   = 'sisgna'; 

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}


if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'setor') {
    // Se não estiver autenticado ou não for do tipo setor, redirecionar para a página de login
    header('Location: login.php');
    exit();
}




// Função para atualizar as informações do setor do aluno via POST
if (isset($_POST['update_setor'])) {
    // Verifica se os dados estão no POST
    if (isset($_POST['id'])) {
        foreach ($_POST['id'] as $index => $id) {
            $alergia = $_POST['alergia'][$id]; // alergia do aluno
            $ja_reprovou = $_POST['ja_reprovou'][$id]; // Já reprovou
            $interno = $_POST['interno'][$id]; // Se é interno
            $orientador_amostra_ciencias = $_POST['orientador_amostra_ciencias'][$id]; // Nome do orientador

            // Verifica se os dados realmente mudaram antes de tentar atualizar ou inserir
            $sql_check = "SELECT * FROM informacoes_adicionais WHERE aluno_id = ?";
            $stmt_check = $conn->prepare($sql_check);
            $stmt_check->bind_param("i", $id);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();

            if ($result_check->num_rows > 0) {
                $row_check = $result_check->fetch_assoc();
                // Verifica se os dados realmente mudaram
                if ($row_check['alergia'] !== $alergia || $row_check['ja_reprovou'] !== $ja_reprovou || $row_check['interno'] !== $interno || $row_check['orientador_amostra_ciencias'] !== $orientador_amostra_ciencias) {
                    // Atualiza as informações do setor na tabela 'informacoes_adicionais'
                    $sql_info = "UPDATE informacoes_adicionais 
                                 SET alergia = ?, ja_reprovou = ?, interno = ?, orientador_amostra_ciencias = ?
                                 WHERE aluno_id = ?";
                    $stmt_info = $conn->prepare($sql_info);
                    $stmt_info->bind_param("sssss", $alergia, $ja_reprovou, $interno, $orientador_amostra_ciencias, $id);

                    // Executa a atualização das informações adicionais
                    if ($stmt_info->execute()) {
                        $_SESSION['mensagem_sucesso'] = "Informações do setor salvas com sucesso!";
                    } else {
                        $_SESSION['mensagem_erro'] = "Erro ao atualizar informações adicionais!";
                    }
                }
            } else {
                // Se não encontrar o aluno, faz a inserção
                $sql_info = "INSERT INTO informacoes_adicionais (aluno_id, alergia, ja_reprovou, interno, orientador_amostra_ciencias) 
                             VALUES (?, ?, ?, ?, ?)";
                $stmt_info = $conn->prepare($sql_info);
                $stmt_info->bind_param("issss", $id, $alergia, $ja_reprovou, $interno, $orientador_amostra_ciencias);

                // Executa a inserção
                if ($stmt_info->execute()) {
                    $_SESSION['mensagem_sucesso'] = "Informações do setor salvas com sucesso!";
                } else {
                    $_SESSION['mensagem_erro'] = "Erro ao inserir informações adicionais!";
                }
            }
        }
    } else {
        $_SESSION['mensagem_erro'] = "ID do aluno não encontrado!";
    }
}

// Função para listar os alunos e suas informações de setor
$sql = "SELECT a.id, a.nome, a.email, a.matricula, a.foto, 
        i.alergia, i.ja_reprovou, i.interno, i.orientador_amostra_ciencias
        FROM alunos a
        LEFT JOIN informacoes_adicionais i ON a.id = i.aluno_id";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Lista de Alunos - Setor</title>
</head>
<body>
    <h1>Lista de Alunos e Informações de Setor</h1>

    <?php
    // Exibe mensagem de sucesso ou erro, se houver
    if (isset($_SESSION['mensagem_sucesso'])) {
        echo "<p style='color: green;'>" . $_SESSION['mensagem_sucesso'] . "</p>";
        unset($_SESSION['mensagem_sucesso']);
    }
    if (isset($_SESSION['mensagem_erro'])) {
        echo "<p style='color: red;'>" . $_SESSION['mensagem_erro'] . "</p>";
        unset($_SESSION['mensagem_erro']);
    }
    ?>

    <form method="POST">
        <table border="1">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Email</th>
                    <th>Matricula</th>
                    <th>Foto</th>
                    <th>Alergia</th>
                    <th>Já Reprovou?</th>
                    <th>Interno?</th>
                    <th>Orientador Amostra Ciências</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td>
                        <td><input type="text" name="nome[]" value="<?php echo $row['nome']; ?>" disabled></td>
                        <td><input type="email" name="email[]" value="<?php echo $row['email']; ?>" disabled></td>
                        <td><input type="text" name="matricula[]" value="<?php echo $row['matricula']; ?>" disabled></td>
                        <td>
                            <input type="text" name="foto[]" value="<?php echo $row['foto']; ?>" disabled><br>
                            <?php if ($row['foto']) { ?>
                                <img src="uploads/<?php echo $row['foto']; ?>" width="50" height="50">
                            <?php } ?>
                        </td>
                        <td><input type="text" name="alergia[<?php echo $row['id']; ?>]" value="<?php echo $row['alergia']; ?>"></td>
                        <td><input type="text" name="ja_reprovou[<?php echo $row['id']; ?>]" value="<?php echo $row['ja_reprovou']; ?>"></td>
                        <td><input type="text" name="interno[<?php echo $row['id']; ?>]" value="<?php echo $row['interno']; ?>"></td>
                        <td><input type="text" name="orientador_amostra_ciencias[<?php echo $row['id']; ?>]" value="<?php echo $row['orientador_amostra_ciencias']; ?>"></td>
                        <!-- Campo oculto para passar o ID -->
                        <input type="hidden" name="id[<?php echo $row['id']; ?>]" value="<?php echo $row['id']; ?>">
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        <button type="submit" name="update_setor">Salvar Todos</button>
    </form>
</body>
</html>

<?php
$conn->close();
?>
