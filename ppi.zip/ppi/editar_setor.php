<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>

<?php
// editar_setor.php
include 'conexao.php';

// Verificar se o ID do setor foi passado pela URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Consulta para obter os dados do setor
    $query = "SELECT * FROM setores WHERE id = $id";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        $setor = $result->fetch_assoc();
    } else {
        echo "Setor não encontrado.";
        exit;
    }
} else {
    echo "ID do setor não fornecido.";
    exit;
}

// Processar o envio do formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $conn->real_escape_string($_POST['nome']);
    $email = $conn->real_escape_string($_POST['email']);
    $tipo = $conn->real_escape_string($_POST['tipo']);

    // Atualizar dados do setor
    $updateQuery = "UPDATE setores SET nome='$nome', email='$email', tipo='$tipo' WHERE id=$id";
    
    if ($conn->query($updateQuery) === TRUE) {
        // Redirecionar após a atualização
        header("Location: listar.php?lista=setores"); // Redirecionar para a lista após a atualização
        exit;
    } else {
        echo "Erro ao atualizar setor: " . $conn->error;
    }
}

// Definir todos os tipos possíveis de setor
$tiposSetor = ['Setor 1', 'Setor 2', 'Setor 3']; // Adicione todos os tipos conforme necessário

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Setor</title>
    <!-- Link para o Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <!-- Link para o seu arquivo CSS -->
    <link rel="stylesheet" href="css/styles.css"> <!-- Aqui importamos o CSS da pasta css -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <a href="admin.php" class="btn-home">
            <i class="fas fa-home"></i>
        </a>
        <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>
        <div id="dropdownMenu" class="dropdown-content" style="display: none;">
            <button onclick="showForm('aluno')">Cadastrar Aluno</button>
            <button onclick="showForm('turma')">Cadastrar Turma</button>
            <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
            <button onclick="showForm('professor')">Cadastrar Professor</button>
            <button onclick="showForm('setor')">Cadastrar Setor</button>
            <button onclick="showForm('curso')">Cadastrar Curso</button>
            <button onclick="showForm('add_admin')">Cadastrar Admin</button>
        </div>
        <button onclick="location.href='turmas.php'">Turmas</button>
        <button onclick="location.href='listar.php'">Listar</button>
        <button onclick="location.href='notificar.php'">Notificar</button>
        <button onclick="location.href='slides.php'">Slides</button>
        <button onclick="location.href='gerar_boletim.php'">Boletim</button>
        <button onclick="location.href='setoradmin.php'">Setor</button>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h1>Editar Setor</h1>

        <form method="post" action="">
            <div class="form-group">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" class="form-control" value="<?php echo htmlspecialchars($setor['nome']); ?>" required>
            </div>

            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($setor['email']); ?>" required>
            </div>

            <div class="form-group">
                <label for="tipo">Tipo:</label>
                <select name="tipo" id="tipo" class="form-control" required>
                    <?php foreach ($tiposSetor as $tipoSetor): ?>
                        <option value="<?php echo htmlspecialchars($tipoSetor); ?>" <?php echo ($setor['tipo'] === $tipoSetor) ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($tipoSetor); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group text-center">
                <button type="submit" class="btn btn-success">Salvar</button>
                <a href="listar.php?lista=setores" class="btn btn-secondary ml-2">Cancelar</a>
            </div>
        </form>
    </div>

    <!-- Link para o Bootstrap JS (se necessário) -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
// Fechar conexão
$conn->close();
?>
