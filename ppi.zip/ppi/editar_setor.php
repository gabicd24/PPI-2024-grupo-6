<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>

<?php
// editar_setor.php
include 'conexao.php';

// Verificar se o ID do setor foi passado pela URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Consulta para obter os dados do setor
    $query = "SELECT * FROM setores WHERE id = $id";
    $result = $conn->query($query);

    if ($result->num_rows == 1) {
        $setor = $result->fetch_assoc();
    } else {
        echo "Setor não encontrado.";
        exit;
    }
} else {
    echo "ID do setor não fornecido.";
    exit;
}

// Processar o envio do formulário
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nome = $conn->real_escape_string($_POST['nome']);
    $email = $conn->real_escape_string($_POST['email']);
    $tipo = $conn->real_escape_string($_POST['tipo']);

    // Atualizar dados do setor
    $updateQuery = "UPDATE setores SET nome='$nome', email='$email', tipo='$tipo' WHERE id=$id";
    
    if ($conn->query($updateQuery) === TRUE) {
        echo "Setor atualizado com sucesso.";
        header("Location: listar.php"); // Redirecionar para a lista após a atualização
        exit;
    } else {
        echo "Erro ao atualizar setor: " . $conn->error;
    }
}

// Definir todos os tipos possíveis de setor
$tiposSetor = ['Setor 1', 'Setor 2', 'Setor 3']; // Adicione todos os tipos conforme necessário

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Setor</title>
    <link rel="stylesheet" href="estilos.css"> <!-- Link para seu arquivo CSS -->
</head>
<body>
    <h1>Editar Setor</h1>
    <form method="post" action="">
        <label for="nome">Nome:</label>
        <input type="text" name="nome" id="nome" value="<?php echo htmlspecialchars($setor['nome']); ?>" required>

        <label for="email">Email:</label>
        <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($setor['email']); ?>" required>

        <label for="tipo">Tipo:</label>
        <select name="tipo" id="tipo" required>
            <?php foreach ($tiposSetor as $tipoSetor): ?>
                <option value="<?php echo htmlspecialchars($tipoSetor); ?>" <?php echo ($setor['tipo'] === $tipoSetor) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($tipoSetor); ?>
                </option>
            <?php endforeach; ?>
        </select>

        <button type="submit">Salvar</button>
        <a href="listar.php">Cancelar</a>
    </form>
</body>
</html>

<?php
// Fechar conexão
$conn->close();
?>
