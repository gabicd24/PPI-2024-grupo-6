<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selecionar Turma</title>
    <link rel="stylesheet" href="styles.css"> <!-- Adicione seu estilo CSS, se necessário -->
</head>
<body>
    <h2>Selecione a Turma</h2>
    <form action="gerar_slides.php" method="GET">
        <label for="id_turma">Escolha a turma:</label>
        <select name="id_turma" id="id_turma">
            <?php
            // Conectar ao banco de dados e obter as turmas
            $conn = new mysqli('localhost', 'root', '', 'sisgna');
            if ($conn->connect_error) {
                die("Conexão falhou: " . $conn->connect_error);
            }

            // Consultar as turmas disponíveis
            $result = $conn->query("SELECT id, nome FROM turmas");

            // Mostrar as turmas no menu suspenso
            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<option value='" . $row['id'] . "'>" . utf8_decode($row['nome']) . "</option>";
                }
            } else {
                echo "<option value=''>Nenhuma turma encontrada</option>";
            }

            // Fechar a conexão
            $conn->close();
            ?>
        </select>
        
        <h3>Selecione as notas que deseja incluir:</h3>
        <label>
            <input type="checkbox" name="notas[]" value="nota_parcial_1"> Nota Parcial 1
        </label><br>
        <label>
            <input type="checkbox" name="notas[]" value="nota_parcial_2"> Nota Parcial 2
        </label><br>
        <label>
            <input type="checkbox" name="notas[]" value="semestre_1"> Semestre 1
        </label><br>
        <label>
            <input type="checkbox" name="notas[]" value="semestre_2"> Semestre 2
        </label><br>
        

        <button type="submit">Gerar Slides</button>
    </form>
</body>
</html>
