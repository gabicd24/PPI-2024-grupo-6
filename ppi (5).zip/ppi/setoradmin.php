<?php
session_start();

// Conexão com o banco de dados
$host = 'localhost';
$user = 'root'; 
$pass = ''; 
$db   = 'sisgna'; 

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

if (!isset($_SESSION['loggedin']) || $_SESSION['tipo'] !== 'admin') {
    // Se não estiver autenticado ou não for do tipo admin, redirecionar para a página de login
    header('Location: login.php');
    exit();
}

$sql = "SELECT a.id, a.nome, a.email, a.matricula, a.foto, 
               t.nome AS turma_nome,
               i.alergia, i.ja_reprovou, i.interno, i.orientador_amostra_ciencias, i.numero
        FROM alunos a
        LEFT JOIN informacoes_adicionais i ON a.id = i.aluno_id
        LEFT JOIN turmas t ON a.turma_id = t.id
        ORDER BY t.nome ASC, a.nome ASC"; 
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin - Sisgna</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="css/styles.css">

    <style>
        .logout-button:hover {
            background-color: #c82333;
        }

        .table-green thead {
            background-color: #28a745; /* Cor de fundo verde */
            color: white; /* Cor do texto branco */
        }

        .btn-green {
            background-color: #28a745;
            color: white;
            border: none;
        }

        .btn-green:hover {
            background-color: #218838;
        }

        /* Estilo para a linha que divide as turmas */
        .turma-divider {
            background-color: #28a745;
            color: white;
            font-weight: bold;
            padding: 10px;
            margin-top: 20px;
            text-align: left; /* Alinhar à esquerda */
            padding-left: 20px; /* Adiciona um pequeno espaçamento à esquerda */
        }
    </style>
</head>
<body class="bg-light">

    <?php if (isset($successMsg) && $successMsg): ?>
        <div id="message" class="message show">
            <?php echo htmlspecialchars($successMsg); ?>
        </div>
    <?php endif; ?>
    
    <?php if (isset($errorMsg) && $errorMsg): ?>
        <div id="message" class="message error show">
            <?php echo htmlspecialchars($errorMsg); ?>
        </div>
    <?php endif; ?>

    <!-- Sidebar -->
    <div class="sidebar">
        <a href="admin.php" class="btn-home">
            <i class="fas fa-home"></i>
        </a>
        <button id="toggleButton">Cadastrar</button>
        <div id="dropdownMenu" class="dropdown-content" style="display: none;">
            <button onclick="showForm('aluno')">Cadastrar Aluno</button>
            <button onclick="showForm('turma')">Cadastrar Turma</button>
            <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
            <button onclick="showForm('professor')">Cadastrar Professor</button>
            <button onclick="showForm('setor')">Cadastrar Setor</button>
            <button onclick="showForm('curso')">Cadastrar Curso</button>
            <button onclick="showForm('add_admin')">Cadastrar Admin</button>
        </div>
        <button onclick="location.href='turmas.php'">Turmas</button>
        <button onclick="location.href='listar.php'">Listar</button>
        <button onclick="location.href='notificar.php'">Notificar</button>
        <button onclick="location.href='selecionar_turma.php'">Slides</button>
        <button onclick="location.href='gerar_boletim.php'">Boletim</button>
        <button onclick="location.href='setoradmin.php'">Setor</button>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <img src="iffarpng.png" alt="Logo da Empresa" class="logo">
            <h1>Bem-vindo ao Painel do Admin</h1>
            <form method="POST" action="logout.php" style="margin: 0; margin-left: auto;">
                <button type="submit" name="logout" class="logout-button">Sair</button>
            </form>
        </div>
        <p></p>
        <!-- Barra de pesquisa -->
        <input type="text" id="searchBar" class="form-control mb-4" placeholder="Pesquisar alunos..." onkeyup="filterTable()" style="width: 50%;">


        <div class="container mt-5">
            <h3 class="text-center mb-4">Lista de Alunos e Informações de Setor</h3>
            <form method="POST">
                <table class="table table-bordered table-green" id="alunosTable">
                    <thead class="table-green">
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Email</th>
                            <th>Matrícula</th>
                            <th>Foto</th>
                            <th>Alergia</th>
                            <th>Já Reprovou?</th>
                            <th>Interno?</th>
                            <th>Orientador A.C.</th>
                            <th>Contato Familiar</th>
                            <th>Turma</th> <!-- Coluna para a turma -->
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        $alunos_por_turma = []; // Array para armazenar os alunos por turma

                        // Armazenar os alunos por turma
                        while ($row = $result->fetch_assoc()) { 
                            $alunos_por_turma[$row['turma_nome']][] = $row;
                        }

                        // Exibir os alunos por turma
                        foreach ($alunos_por_turma as $turma => $alunos) {
                            echo "<tr class='turma-divider'><td colspan='11'>Turma: " . $turma . "</td></tr>";  // Linha divisória com nome da turma

                            // Exibe os alunos da turma
                            foreach ($alunos as $aluno) {
                                ?>
                                <tr>
                                    <td><?php echo $aluno['id']; ?></td>
                                    <td><?php echo $aluno['nome']; ?></td>
                                    <td><?php echo $aluno['email']; ?></td>
                                    <td><?php echo $aluno['matricula']; ?></td>
                                    <td>
                                        <?php if ($aluno['foto']) { ?>
                                            <img src="alunosfotos/<?php echo $aluno['foto']; ?>" class="img-thumbnail" style="width: 50px; height: 50px;">
                                        <?php } else { ?>
                                            N/A
                                        <?php } ?>
                                    </td>
                                    <td><?php echo $aluno['alergia']; ?></td>
                                    <td><?php echo $aluno['ja_reprovou']; ?></td>
                                    <td><?php echo $aluno['interno']; ?></td>
                                    <td><?php echo $aluno['orientador_amostra_ciencias']; ?></td>
                                    <td><?php echo $aluno['numero']; ?></td>
                                    <!-- Campo oculto para a turma -->
                                    <td>
                                        <input type="hidden" name="turma" value="<?php echo $aluno['turma_nome']; ?>" />
                                        <?php echo $aluno['turma_nome']; ?>
                                    </td>
                                </tr>
                                <?php
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </form>
        </div>
    </div>

    <script>
        // Função de filtragem da tabela
        function filterTable() {
            let input = document.getElementById('searchBar');  // Campo de pesquisa
            let filter = input.value.toUpperCase();  // Valor digitado
            let table = document.getElementById('alunosTable');  // A tabela
            let rows = table.getElementsByTagName('tr');  // Todas as linhas da tabela

            for (let i = 1; i < rows.length; i++) {  // Ignora a primeira linha (cabeçalho)
                let cells = rows[i].getElementsByTagName('td');  // Células da linha
                let found = false;

                // Verifica se alguma célula da linha contém o valor da pesquisa
                for (let j = 0; j < cells.length; j++) {
                    let cell = cells[j];

                    if (cell) {
                        // Verifica o valor das células visíveis e do campo oculto da turma
                        if (cell.innerText.toUpperCase().indexOf(filter) > -1 || 
                            (cell.querySelector('input[name="turma"]') && 
                            cell.querySelector('input[name="turma"]').value.toUpperCase().indexOf(filter) > -1)) {
                            found = true;
                            break;  // Se encontrar, não precisa verificar as outras células
                        }
                    }
                }

                // Exibe ou esconde a linha com base no filtro
                if (found) {
                    rows[i].style.display = "";
                } else {
                    rows[i].style.display = "none";
                }
            }
        }
    </script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
