<?php
$host = 'localhost';
$db   = 'sisgna';
$user = 'root'; // ou o usuário que você criou
$pass = ''; // ou a senha que você configurou

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    echo "Conexão bem-sucedida!";
} catch (PDOException $e) {
    echo "Falha na conexão: " . $e->getMessage();
}
?>
