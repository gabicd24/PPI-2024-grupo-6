<?php
// Conexão com o banco de dados
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

session_start();
include 'conexao.php'; // Incluindo a conexão com o banco de dados

$id = isset($_GET['id']) ? intval($_GET['id']) : 0; // Validação do ID

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Processar a edição
    $nome = $_POST['nome'] ?? '';
    $email = $_POST['email'] ?? '';

    $matricula = $_POST['matricula'] ?? '';
    $turma_id = $_POST['turma_id'] ?? '';

    // Atualizar o aluno no banco de dados
    $stmt = $conn->prepare("UPDATE alunos SET nome = ?, email = ?, matricula = ?, turma_id = ? WHERE id = ?");
    $stmt->bind_param("sssii", $nome, $email, $matricula, $turma_id, $id);
    
    if ($stmt->execute()) {
        $_SESSION[''] = "";
    } else {
        $_SESSION['error'] = "Erro ao atualizar aluno: " . $stmt->error;
    }

    $stmt->close();
    header("Location: listar.php?lista=alunos");
    exit();
}

// Buscar os dados do aluno para edição
$query = "SELECT * FROM alunos WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $_SESSION['error'] = "Aluno não encontrado.";
    header("Location: listar.php?lista=alunos");
    exit();
}

$aluno = $result->fetch_assoc();
$stmt->close();

// Opcional: buscar turmas para selecionar
$turmas = $conn->query("SELECT id, nome FROM turmas");

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Aluno</title>
    <!-- Link do Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Link para o seu arquivo de CSS -->
    <link href="css/styles.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <a href="admin.php" class="btn-home">
            <i class="fas fa-home"></i>
        </a>

        <button onclick="location.href='admin.php'" id="toggleButton">Cadastrar</button>
        <div id="dropdownMenu" class="dropdown-content" style="display: none;">
            <button onclick="showForm('aluno')">Cadastrar Aluno</button>
            <button onclick="showForm('turma')">Cadastrar Turma</button>
            <button onclick="showForm('disciplina')">Cadastrar Disciplina</button>
            <button onclick="showForm('professor')">Cadastrar Professor</button>
            <button onclick="showForm('setor')">Cadastrar Setor</button>
            <button onclick="showForm('curso')">Cadastrar Curso</button>
            <button onclick="showForm('add_admin')">Cadastrar Admin</button>
        </div>

        <button onclick="location.href='turmas.php'">Turmas</button>
        <button onclick="location.href='listar.php'">Listar</button>
        <button onclick="location.href='notificar.php'">Notificar</button>
        <button onclick="location.href='slides.php'">Slides</button>
        <button onclick="location.href='setoradmin.php'">Setor</button>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h1>Editar Aluno</h1>

        <?php
        // Exibir mensagens de erro e sucesso
        if (isset($_SESSION['error'])) {
            echo "<div class='alert alert-danger'>" . $_SESSION['error'] . "</div>";
            unset($_SESSION['error']);
        }
        if (isset($_SESSION['success'])) {
            echo "<div class='alert alert-success'>" . $_SESSION['success'] . "</div>";
            unset($_SESSION['success']);
        }
        ?>

        <form method="POST">
            <div class="form-container">
                <!-- Nome -->
                <div class="mb-3">
                    <label for="nome" class="form-label">Nome:</label>
                    <input type="text" class="form-control" name="nome" value="<?php echo htmlspecialchars($aluno['nome']); ?>" required>
                </div>

                <!-- Email -->
                <div class="mb-3">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" class="form-control" name="email" value="<?php echo htmlspecialchars($aluno['email']); ?>" required>
                </div>

              

                <!-- Matrícula -->
                <div class="mb-3">
                    <label for="matricula" class="form-label">Matrícula:</label>
                    <input type="text" class="form-control" name="matricula" value="<?php echo htmlspecialchars($aluno['matricula']); ?>" required>
                </div>

                <!-- Turma -->
                <div class="mb-3">
                    <label for="turma_id" class="form-label">Turma:</label>
                    <select name="turma_id" class="form-control" required>
                        <?php while ($turma = $turmas->fetch_assoc()): ?>
                            <option value="<?php echo $turma['id']; ?>" <?php echo $turma['id'] == $aluno['turma_id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($turma['nome']); ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>

                <!-- Botões de Ação -->
                <div class="form-group text-center">
                    <button type="submit" class="btn btn-success">Atualizar Aluno</button>
                    <a href="listar.php" class="btn btn-secondary mt-3">Cancelar</a>
                </div>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
$conn->close(); // Fechar a conexão ao final
?>
