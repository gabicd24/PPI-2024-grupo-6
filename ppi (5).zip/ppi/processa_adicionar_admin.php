<?php
// processa_adicionar_admin.php

// Conectar ao banco de dados
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_admin'])) {
    $userId = $_POST['user_id'];
    
    // Atualiza o papel do usuário para admin
    $stmt = $pdo->prepare('UPDATE usuarios SET role = "admin" WHERE id = :id');
    $stmt->execute(['id' => $userId]);
    
    // Redirecionar ou mostrar uma mensagem de sucesso
    header('Location: admin.php?message=Usuário promovido com sucesso');
    exit;
}
?>
