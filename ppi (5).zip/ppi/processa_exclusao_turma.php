<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verifica se o ID da turma foi passado na URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Remove disciplinas associadas à turma
    $queryDeleteDisciplinas = "DELETE FROM disciplinas WHERE turma_id = ?";
    $stmtDeleteDisciplinas = $conn->prepare($queryDeleteDisciplinas);
    $stmtDeleteDisciplinas->bind_param("i", $id);
    $stmtDeleteDisciplinas->execute();

    // Remove a turma
    $queryDeleteTurma = "DELETE FROM turmas WHERE id = ?";
    $stmtDeleteTurma = $conn->prepare($queryDeleteTurma);
    $stmtDeleteTurma->bind_param("i", $id);

    if ($stmtDeleteTurma->execute()) {
        // Redireciona de volta para a página de listagem após a exclusão
        header("Location: listar.php?mensagem=Turma excluída com sucesso");
        exit();
    } else {
        echo "Erro ao excluir a turma: " . $stmtDeleteTurma->error;
    }
} else {
    echo "ID de turma não especificado.";
}

$conn->close();
?>
