<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

// Verificar se o ID do setor foi passado pela URL
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Preparar a consulta para exclusão
    $query = "DELETE FROM setores WHERE id = $id";

    if ($conn->query($query) === TRUE) {
        echo "Setor excluído com sucesso.";
    } else {
        echo "Erro ao excluir setor: " . $conn->error;
    }
} else {
    echo "ID do setor não fornecido.";
}

// Redirecionar para a lista de setores após um breve momento
header("Refresh: 2; url=listar.php"); // Redireciona após 2 segundos
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Excluir Setor</title>
</head>
<body>
    <h1>Resultado da Exclusão</h1>
    <p>
        <?php
        // Exibe a mensagem de resultado da exclusão
        if (isset($message)) {
            echo htmlspecialchars($message);
        }
        ?>
    </p>
    <p>Redirecionando para a lista de setores...</p>
</body>
</html>

<?php
// Fechar conexão
$conn->close();
?>
