<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}

session_start();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0; // Validação do ID

if ($id > 0) {
    // Preparar a consulta para excluir o aluno
    $stmt = $conn->prepare("DELETE FROM alunos WHERE id = ?");
    
    if ($stmt) {
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $_SESSION['success'] = "Aluno excluído com sucesso.";
        } else {
            $_SESSION['error'] = "Erro ao excluir aluno: " . $stmt->error;
        }

        $stmt->close();
    } else {
        $_SESSION['error'] = "Erro ao preparar a consulta: " . $conn->error;
    }
} else {
    $_SESSION['error'] = "ID inválido.";
}

// Redirecionar de volta para a lista de alunos
header("Location: listar.php");
exit();

$conn->close(); // Fechar a conexão ao final
?>
