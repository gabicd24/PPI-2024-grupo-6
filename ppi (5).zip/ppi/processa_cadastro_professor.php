<?php
session_start(); // Iniciar a sessão para armazenar mensagens

// Incluir o arquivo de configuração ou conexão com o banco de dados
include 'conexao.php'; // Substitua pelo caminho correto para sua configuração de banco de dados

// Verificar se o formulário foi enviado
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Receber dados do formulário
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
  
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT); // Criptografar a senha
    $disciplinas = isset($_POST['disciplinas']) ? $_POST['disciplinas'] : []; // Disciplinas selecionadas

    // Processamento de foto
    $fotoNome = null; // Inicializa a variável
    if (isset($_FILES['foto']) && $_FILES['foto']['error'] === UPLOAD_ERR_OK) {
        $fotoExt = pathinfo($_FILES['foto']['name'], PATHINFO_EXTENSION);
        $fotoNome = 'professor' . $nome . '.' . $fotoExt; // Nome do arquivo formatado
        $fotoTmp = $_FILES['foto']['tmp_name'];
        $fotoDir = 'professorfoto'; // Caminho do diretório
        $fotoDest = $fotoDir . '/' . $fotoNome; // Caminho completo para salvar a foto

        // Verifica se a pasta existe, se não, cria a pasta
        if (!is_dir($fotoDir)) {
            if (!mkdir($fotoDir, 0755, true)) {
                $_SESSION['error'] = "Erro ao criar o diretório para as fotos.";
                header("Location: admin.php");
                exit();
            }
        }

        // Tenta mover o arquivo para o diretório especificado
        if (!move_uploaded_file($fotoTmp, $fotoDest)) {
            $_SESSION['error'] = "Erro ao fazer upload da foto. Verifique as permissões da pasta e o caminho do diretório.";
            header("Location: admin.php");
            exit();
        }
    } elseif (isset($_FILES['foto']) && $_FILES['foto']['error'] !== UPLOAD_ERR_NO_FILE) {
        // Verifica se ocorreu um erro de upload
        $uploadError = $_FILES['foto']['error'];
        $_SESSION['error'] = "Erro ao fazer upload da foto. Código do erro: $uploadError.";
        header("Location: admin.php");
        exit();
    }

    try {
        // Verificar se o e-mail já está registrado
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetchColumn() > 0) {
            throw new Exception("E-mail já cadastrado.");
        }


     
        // Inserir o usuário na tabela 'usuarios' primeiro e pegar o id gerado
        $stmt_usuario = $pdo->prepare("INSERT INTO usuarios (username, email, password_hash, tipo) VALUES (?, ?, ?, ?)");
        $tipo = 'professor'; // Definindo o tipo como professor
        $stmt_usuario->execute([$nome, $email, $senha, $tipo]);

        // Pegar o id gerado para o usuário recém inserido
        $usuario_id = $pdo->lastInsertId();

        // Inserir o professor na tabela 'professores' com o mesmo id
        $stmt_professor = $pdo->prepare("INSERT INTO professores (id, nome, foto) VALUES (?, ?, ?)");
        $stmt_professor->execute([$usuario_id, $nome, $fotoNome]);

        // Associar disciplinas ao professor
        if (!empty($disciplinas)) {
            $stmt_disciplinas = $pdo->prepare("INSERT INTO professor_disciplinas (professor_id, disciplina_id) VALUES (?, ?)");
            foreach ($disciplinas as $disciplina_id) {
                $stmt_disciplinas->execute([$usuario_id, $disciplina_id]);
            }
        }

        // Redirecionar com sucesso
        $_SESSION['success'] = 'Cadastro realizado.';
        header('Location: admin.php');
        exit();

    } catch (PDOException $e) {
        // Mensagem de erro detalhada para PDOException
        $_SESSION['error'] = "Erro na base de dados: " . $e->getMessage();
        header("Location: admin.php");
        exit();
    } catch (Exception $e) {
        // Mensagem de erro detalhada para Exception
        $_SESSION['error'] = "Erro: " . $e->getMessage();
        header("Location: admin.php");
        exit();
    }
} else {
    // Redirecionar para a página de cadastro se a solicitação não for POST
    header('Location: admin.php');
    exit();
}

?>
