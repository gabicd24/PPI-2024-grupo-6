<?php
session_start(); // Iniciar a sessão para armazenar mensagens

// Configurações do banco de dados
$host = 'localhost';
$user = 'root'; // Substitua pelo nome de usuário do MySQL
$pass = ''; // Substitua pela senha do MySQL
$db   = 'sisgna'; // Nome do banco de dados

// Conectar ao banco de dados
$conn = new mysqli($host, $user, $pass, $db);

// Verifica a conexão
if ($conn->connect_error) {
    die("Falha na conexão: " . $conn->connect_error);
}

// Processa o formulário
$nome = isset($_POST['nome']) ? trim($_POST['nome']) : '';
$turma_id = isset($_POST['turma_id']) ? intval($_POST['turma_id']) : 0;

if (empty($nome) || empty($turma_id)) {
    $_SESSION['error'] = "Nome e turma são obrigatórios.";
    header("Location: admin.php");
    exit();
}

$sql = "INSERT INTO disciplinas (nome, turma_id) VALUES (?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt === false) {
    $_SESSION['error'] = "Erro na preparação da declaração: " . $conn->error;
    header("Location: admin.php");
    exit();
}

$stmt->bind_param("si", $nome, $turma_id);

if ($stmt->execute()) {
    $_SESSION['success'] = "Cadastro realizado.";
    header("Location: admin.php");
} else {
    $_SESSION['error'] = "Erro ao cadastrar a disciplina: " . $stmt->error;
    header("Location: admin.php");
}

$stmt->close();
$conn->close();
?>
