<?php
// conexao.php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "sisgna";

// Criar conexão
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexão
if ($conn->connect_error) {
    die("Conexão falhou: " . $conn->connect_error);
}
?>

<?php
// listar.php
include 'conexao.php';

// Função para gerar a tabela
function gerarTabela($conn, $query, $titulo, $colunas, $isAluno = false) {
    echo "<h2>$titulo</h2>";
    $result = $conn->query($query);

    if (!$result) {
        die("Erro na consulta: " . $conn->error);
    }

    if ($result->num_rows > 0) {
        echo "<table border='1'><tr>";
        foreach ($colunas as $coluna) {
            echo "<th>$coluna</th>";
        }
        echo "<th>Ações</th>"; // Coluna para ações
        echo "</tr>";

        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            foreach ($colunas as $coluna) {
                $colunaLower = strtolower(str_replace(' ', '_', $coluna));
                $valor = isset($row[$colunaLower]) ? htmlspecialchars($row[$colunaLower]) : 'N/A';
                echo "<td>$valor</td>";
            }
            $id = $row['id'];
            echo "<td>";
            if ($isAluno) {
                echo "<a href='editar_aluno.php?id=$id'>Editar</a> | ";
            }
            echo "<a href='processa_exclusao_aluno.php?id=$id' onclick='return confirm(\"Tem certeza que deseja excluir este registro?\")'>Excluir</a>";
            
            
            echo "</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "Nenhum registro encontrado.";
    }
}

// Consulta para listar alunos com nome da turma
$queryAlunos = "SELECT a.id, a.nome, a.email, a.cpf, a.matricula, COALESCE(t.nome, 'Não Atribuído') AS turma
                FROM alunos a
                LEFT JOIN turmas t ON a.turma_id = t.id";

$tituloAlunos = "Lista de Alunos";
$colunasAlunos = ['ID', 'Nome', 'Email', 'CPF', 'Matricula', 'Turma'];

// Gerar a tabela de alunos
gerarTabela($conn, $queryAlunos, $tituloAlunos, $colunasAlunos, true); // Passando true para indicar que é a tabela de alunos

// Consulta para listar turmas com líder e regente
$queryTurmas = "SELECT id, nome, 
                        COALESCE(lider, 'Não Atribuído') AS lider, 
                        COALESCE(regente, 'Não Atribuído') AS regente
                FROM turmas";

$tituloTurmas = "Lista de Turmas";
$colunasTurmas = ['ID', 'Nome', 'Líder', 'Regente'];

// Gerar a tabela de turmas
gerarTabela($conn, $queryTurmas, $tituloTurmas, $colunasTurmas);

// Consulta para listar professores e suas disciplinas
$queryProfessores = "SELECT p.id, p.nome, p.email, p.cpf, p.foto,
                             GROUP_CONCAT(DISTINCT CONCAT(d.nome, ' - (', t.nome, ')') SEPARATOR ', ') AS disciplinas
                      FROM professores p
                      LEFT JOIN professor_disciplinas pd ON p.id = pd.professor_id
                      LEFT JOIN disciplinas d ON pd.disciplina_id = d.id
                      LEFT JOIN turmas t ON d.turma_id = t.id
                      GROUP BY p.id, p.nome, p.email, p.cpf, p.foto";

$tituloProfessores = "Lista de Professores";
$colunasProfessores = ['ID', 'Nome', 'Email', 'CPF', 'Foto', 'Disciplinas'];

// Gerar a tabela de professores
gerarTabela($conn, $queryProfessores, $tituloProfessores, $colunasProfessores);

// Consulta para listar disciplinas com o nome da turma
$queryDisciplinas = "SELECT d.id, d.nome AS disciplina, 
                             COALESCE(t.nome, 'Não Atribuído') AS turma
                      FROM disciplinas d
                      LEFT JOIN turmas t ON d.turma_id = t.id";

$tituloDisciplinas = "Lista de Disciplinas";
$colunasDisciplinas = ['ID', 'Disciplina', 'Turma'];

// Gerar a tabela de disciplinas
gerarTabela($conn, $queryDisciplinas, $tituloDisciplinas, $colunasDisciplinas);

// Consulta para listar setores
$querySetores = "SELECT id, nome, email, tipo
                 FROM setores";

$tituloSetores = "Lista de Setores";
$colunasSetores = ['ID', 'Nome', 'Email', 'Tipo'];

// Gerar a tabela de setores
gerarTabela($conn, $querySetores, $tituloSetores, $colunasSetores);

// Consulta para listar administradores
$queryAdmins = "SELECT id, username, email, tipo
                FROM usuarios
                WHERE tipo = 'admin'";

$tituloAdmins = "Lista de Administradores";
$colunasAdmins = ['ID', 'Username', 'Email', 'Tipo'];

// Gerar a tabela de administradores
gerarTabela($conn, $queryAdmins, $tituloAdmins, $colunasAdmins);

// Fechar conexão
$conn->close();
?>
